import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const outputDir = path.resolve("outputs", "hr_action_item_dashboard_20260702");
const previewDir = path.join(outputDir, "previews");
const outputPath = path.join(outputDir, "HR_Action_Item_Dashboard.xlsx");
const dataDir = path.resolve("data");
const trackerJsonPath = path.join(dataDir, "incidents.json");

const DUMMY_RECORD_COUNT = 1500;
const WEEK_COUNT = 260;
const LAST_12_START_ROW = 270;
const DASHBOARD_MAIN_RANGE = "A1:Q90";
const START_DATE = new Date(2025, 0, 9);

function reportingDaysFromArgs() {
  const argument = process.argv.find((value) => value.startsWith("--reporting-days="));
  const days = Number(argument?.split("=")[1]);
  return Number.isFinite(days) ? Math.min(365, Math.max(30, Math.round(days))) : 90;
}

const REPORTING_DAYS = reportingDaysFromArgs();
const REPORTING_WINDOW_LABEL = `${REPORTING_DAYS}-Day`;

const categories = [
  "info request",
  "day force related",
  "benefit questions",
  "policy clarifications",
  "performance management",
  "health and safety incidents",
  "employee referrals",
  "employee grievances",
  "supplies/merchandise",
  "UKG related",
  "W-2 request",
  "food pantry",
  "escalation",
  "case management",
];

const supervisors = [
  "Avery Johnson",
  "Morgan Lee",
  "Casey Patel",
  "Jordan Smith",
  "Taylor Brooks",
  "Riley Nguyen",
  "Drew Campbell",
  "Sam Rivera",
  "Jamie Morgan",
  "Quinn Parker",
  "Cameron Ellis",
  "Reese Thompson",
];

const hrPeople = [
  "Pat Morgan",
  "Shawn Reed",
  "Leslie Carter",
  "Maria Torres",
  "Jordan Blake",
  "Ari Kim",
];

const firstNames = [
  "Alex",
  "Bailey",
  "Chris",
  "Dakota",
  "Emery",
  "Finley",
  "Harper",
  "Indigo",
  "Jules",
  "Kai",
  "Logan",
  "Micah",
  "Noel",
  "Parker",
  "Rowan",
  "Skyler",
  "Tatum",
  "Val",
  "Winter",
  "Zion",
];

const lastNames = [
  "Adams",
  "Bennett",
  "Carter",
  "Diaz",
  "Evans",
  "Foster",
  "Garcia",
  "Hayes",
  "Irwin",
  "Jackson",
  "Kim",
  "Lopez",
  "Miller",
  "Nelson",
  "Owens",
  "Price",
  "Quinn",
  "Reed",
  "Stone",
  "Turner",
  "Vega",
  "Wells",
];

const categoryWeights = [
  ["info request", 15],
  ["day force related", 10],
  ["benefit questions", 13],
  ["policy clarifications", 11],
  ["performance management", 8],
  ["health and safety incidents", 6],
  ["employee referrals", 5],
  ["employee grievances", 6],
  ["supplies/merchandise", 5],
  ["UKG related", 9],
  ["W-2 request", 3],
  ["food pantry", 3],
  ["escalation", 2],
  ["case management", 4],
];

const informationByCategory = {
  "info request": [
    "Asked for general HR guidance before shift start.",
    "Requested clarification on where to find employee resources.",
    "Stopped by for help understanding an HR notice.",
  ],
  "day force related": [
    "Needed help reviewing timecard details in Dayforce.",
    "Reported a missed punch and asked how to correct it.",
    "Asked for help with Dayforce access and password reset steps.",
  ],
  "benefit questions": [
    "Asked about benefit enrollment timing and next steps.",
    "Requested help understanding coverage options.",
    "Asked about dependent information and benefit documentation.",
  ],
  "policy clarifications": [
    "Asked for clarification on attendance policy expectations.",
    "Requested guidance on call-off procedure.",
    "Asked how a production-floor policy applies to their situation.",
  ],
  "performance management": [
    "Supervisor referred employee for coaching documentation support.",
    "Asked about expectations after a corrective conversation.",
    "Requested help understanding performance follow-up items.",
  ],
  "health and safety incidents": [
    "Reported a minor safety concern from the production floor.",
    "Asked about next steps after a near-miss report.",
    "Requested guidance after a workplace health and safety concern.",
  ],
  "employee referrals": [
    "Asked how to submit an employee referral.",
    "Requested status update on a referral bonus.",
    "Brought referral information for HR follow-up.",
  ],
  "employee grievances": [
    "Raised a concern about treatment on the production floor.",
    "Requested a private conversation about a team issue.",
    "Asked about grievance process and documentation.",
  ],
  "supplies/merchandise": [
    "Requested replacement badge holder and basic supplies.",
    "Asked about uniform or merchandise availability.",
    "Needed help with issued item replacement.",
  ],
  "UKG related": [
    "Asked for help navigating UKG self-service.",
    "Needed assistance updating personal information in UKG.",
    "Reported UKG login issue and requested reset guidance.",
  ],
  "W-2 request": [
    "Requested help accessing W-2 documents.",
    "Asked where to update tax document delivery settings.",
    "Needed a W-2 reprint or access instructions.",
  ],
  "food pantry": [
    "Asked about food pantry availability and hours.",
    "Requested information on employee support resources.",
    "Stopped by for pantry-related assistance.",
  ],
  "escalation": [
    "Issue escalated for HR manager review.",
    "Requested urgent follow-up on an unresolved concern.",
    "Needed additional HR review after initial walk-in.",
  ],
  "case management": [
    "Follow-up needed for ongoing HR case management.",
    "Asked for status update on an existing HR case.",
    "Provided documentation for active HR case follow-up.",
  ],
};

const colors = {
  navy: "#17324D",
  teal: "#1F7A8C",
  green: "#2F855A",
  amber: "#B7791F",
  red: "#B83232",
  ink: "#1F2933",
  muted: "#607080",
  lightBlue: "#E8F2F6",
  lightGreen: "#EAF6EF",
  lightAmber: "#FFF4DE",
  lightRed: "#FCEAEA",
  panel: "#F7FAFC",
  grid: "#D9E2EC",
  white: "#FFFFFF",
};

function setRangeValues(sheet, address, values) {
  sheet.getRange(address).values = values;
}

function setRangeFormulas(sheet, address, formulas) {
  sheet.getRange(address).formulas = formulas;
}

function mergeValue(sheet, address, value, format = {}) {
  const range = sheet.getRange(address);
  range.merge();
  range.values = [[value]];
  range.format = format;
  return range;
}

function mergeFormula(sheet, address, formula, format = {}) {
  const range = sheet.getRange(address);
  range.merge();
  range.formulas = [[formula]];
  range.format = format;
  return range;
}

function styleTitle(range, fill = colors.navy) {
  range.format = {
    fill,
    font: { bold: true, color: colors.white },
    wrapText: true,
  };
}

function styleHeader(range, fill = colors.navy) {
  range.format = {
    fill,
    font: { bold: true, color: colors.white },
    borders: { preset: "inside", style: "thin", color: colors.white },
    wrapText: true,
  };
}

function stylePanel(range, fill = colors.panel) {
  range.format = {
    fill,
    borders: { preset: "outside", style: "thin", color: colors.grid },
    wrapText: true,
  };
}

function applyNumberFormat(sheet, address, formatCode) {
  sheet.getRange(address).format.numberFormat = formatCode;
}

function setColumnWidth(sheet, col, width) {
  sheet.getRange(`${col}1:${col}120`).format.columnWidth = width;
}

function makeRng(seed = 5252026) {
  let state = seed >>> 0;
  return () => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return state / 0x100000000;
  };
}

function weightedPick(weightedItems, rng) {
  const total = weightedItems.reduce((sum, [, weight]) => sum + weight, 0);
  let roll = rng() * total;
  for (const [item, weight] of weightedItems) {
    roll -= weight;
    if (roll <= 0) return item;
  }
  return weightedItems[weightedItems.length - 1][0];
}

function makeDummyRows() {
  const rng = makeRng();
  const start = new Date(START_DATE);
  const asOf = new Date(2026, 6, 2);
  const weekCount = 78;
  const weeklyCounts = [];

  for (let week = 1; week <= weekCount; week += 1) {
    const seasonal = Math.round(Math.sin(week / 3) * 3 + Math.sin(week / 9) * 2);
    const trend = (week > 28 ? 3 : 0) + (week > 50 ? 3 : 0);
    const spike =
      [14, 31, 47, 63, 72].includes(week) ? 5 + Math.floor(rng() * 6) : 0;
    weeklyCounts.push(Math.max(9, 15 + seasonal + trend + spike));
  }

  let delta = DUMMY_RECORD_COUNT - weeklyCounts.reduce((sum, count) => sum + count, 0);
  let cursor = 0;
  while (delta !== 0) {
    const direction = delta > 0 ? 1 : -1;
    const next = weeklyCounts[cursor] + direction;
    if (next >= 8) {
      weeklyCounts[cursor] = next;
      delta -= direction;
    }
    cursor = (cursor + 1) % weeklyCounts.length;
  }

  const rows = [];
  for (let week = 1; week <= weekCount; week += 1) {
    const count = weeklyCounts[week - 1];
    for (let item = 0; item < count; item += 1) {
      const dayOffset =
        item % 11 === 0 ? 5 + Math.floor(rng() * 2) : Math.floor(rng() * 5);
      const date = new Date(start);
      date.setDate(start.getDate() + (week - 1) * 7 + dayOffset);
      if (date > asOf) {
        date.setTime(asOf.getTime());
      }

      const category = weightedPick(categoryWeights, rng);
      const templates = informationByCategory[category];
      const info = templates[Math.floor(rng() * templates.length)];
      const first = firstNames[Math.floor(rng() * firstNames.length)];
      const last = lastNames[Math.floor(rng() * lastNames.length)];
      const supervisor = supervisors[(week + item + Math.floor(rng() * 4)) % supervisors.length];
      const hrPerson = hrPeople[(week + item + Math.floor(rng() * 3)) % hrPeople.length];
      const batch = `EID-${String(10000 + ((week + item) % 9000)).padStart(5, "0")}`;
      const ageDays = Math.max(0, Math.round((asOf - date) / (24 * 60 * 60 * 1000)));
      let completeRate = ageDays <= 7 ? 0.42 : ageDays <= 14 ? 0.58 : ageDays <= 30 ? 0.74 : 0.9;
      if (["employee grievances", "performance management", "escalation", "case management"].includes(category)) {
        completeRate -= 0.12;
      }
      const completed = rng() < completeRate ? "X" : "";

      rows.push([
        date,
        `${first} ${last}`,
        batch,
        supervisor,
        hrPerson,
        completed ? "" : hrPerson,
        "",
        info,
        category,
        completed,
      ]);
    }
  }

  return rows.slice(0, DUMMY_RECORD_COUNT);
}

function toIsoDate(value) {
  if (value instanceof Date) {
    const year = value.getFullYear();
    const month = String(value.getMonth() + 1).padStart(2, "0");
    const day = String(value.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }
  return String(value ?? "").slice(0, 10);
}

function normalizeCompleted(value) {
  return String(value ?? "").trim().toUpperCase() === "X" ? "X" : "";
}

function rowToRecord(row, index) {
  return {
    id: index + 1,
    date: toIsoDate(row[0]),
    employeeName: row[1] ?? "",
    batchNumber: row[2] ?? "",
    supervisor: row[3] ?? "",
    hrPerson: row[4] ?? "",
    followUpOwner: row[5] ?? "",
    followUpDueDate: toIsoDate(row[6]),
    information: row[7] ?? "",
    summary: row[8] ?? "",
    completed: normalizeCompleted(row[9]),
  };
}

function normalizeRecord(record, index) {
  return {
    id: Number.isFinite(Number(record.id)) ? Number(record.id) : index + 1,
    date: toIsoDate(record.date),
    employeeName: String(record.employeeName ?? "").trim(),
    batchNumber: String(record.batchNumber ?? "").trim(),
    supervisor: String(record.supervisor ?? "").trim(),
    hrPerson: String(record.hrPerson ?? "").trim(),
    followUpOwner: String(record.followUpOwner ?? "").trim(),
    followUpDueDate: toIsoDate(record.followUpDueDate),
    information: String(record.information ?? "").trim(),
    summary: String(record.summary ?? "").trim(),
    completed: normalizeCompleted(record.completed),
  };
}

function recordToExcelRow(record) {
  const dateParts = String(record.date).split("-").map((part) => Number(part));
  const date =
    dateParts.length === 3 && dateParts.every((part) => Number.isFinite(part))
      ? new Date(dateParts[0], dateParts[1] - 1, dateParts[2])
      : "";
  return [
    date,
    record.employeeName,
    record.batchNumber,
    record.supervisor,
    record.hrPerson,
    record.followUpOwner,
    record.followUpDueDate ? new Date(`${record.followUpDueDate}T00:00:00`) : "",
    record.information,
    record.summary,
    record.completed,
  ];
}

async function loadTrackerRecords() {
  try {
    const text = await fs.readFile(trackerJsonPath, "utf8");
    const parsed = JSON.parse(text);
    if (Array.isArray(parsed)) {
      return parsed.map(normalizeRecord);
    }
  } catch {
    // A missing data file means the workbook should start empty.
  }
  return [];
}

const trackerRecords = await loadTrackerRecords();
const trackerRows = trackerRecords.map(recordToExcelRow);
const DATA_LAST_ROW = Math.max(1, trackerRecords.length) + 1;
const supervisorWatchlist = Array.from(
  new Set([
    ...trackerRecords.map((record) => record.supervisor).filter(Boolean),
    ...supervisors,
  ]),
).slice(0, 20);

const workbook = Workbook.create();
const dashboard = workbook.worksheets.add("Dashboard");
const incident = workbook.worksheets.add("Incident Tracker 4.0");
const analysis = workbook.worksheets.add("Analysis");
const setup = workbook.worksheets.add("Setup");

const dataSheet = "'Incident Tracker 4.0'";
const setupSheet = "'Setup'";
const analysisSheet = "'Analysis'";
const weekRange = `${dataSheet}!$A$2:$A$${DATA_LAST_ROW}`;
const dateRange = `${dataSheet}!$B$2:$B$${DATA_LAST_ROW}`;
const supervisorRange = `${dataSheet}!$E$2:$E$${DATA_LAST_ROW}`;
const hrPersonRange = `${dataSheet}!$F$2:$F$${DATA_LAST_ROW}`;
const followUpOwnerRange = `${dataSheet}!$G$2:$G$${DATA_LAST_ROW}`;
const followUpDueRange = `${dataSheet}!$H$2:$H$${DATA_LAST_ROW}`;
const summaryRange = `${dataSheet}!$J$2:$J$${DATA_LAST_ROW}`;
const completedRange = `${dataSheet}!$K$2:$K$${DATA_LAST_ROW}`;

// Setup
setup.showGridLines = false;
setRangeValues(setup, "A1:B1", [["HR Action Item Dashboard Setup", ""]]);
setup.getRange("A1:B1").merge();
styleTitle(setup.getRange("A1:B1"), colors.navy);

setRangeValues(setup, "A2:B5", [
  ["Start Date", new Date(2025, 0, 9)],
  ["Current Calendar Week", ""],
  ["Dashboard Window", "Last 12 weeks"],
  ["Data Capacity", `Rows 2:${DATA_LAST_ROW} (${trackerRecords.length} loaded)`],
]);
setRangeFormulas(setup, "B3:B3", [[`=MAX(1,INT((TODAY()-${setupSheet}!$B$2)/7)+1)`]]);
applyNumberFormat(setup, "B2:B2", "m/d/yyyy");
applyNumberFormat(setup, "B3:B3", "0");
styleHeader(setup.getRange("A2:A5"), colors.teal);
stylePanel(setup.getRange("B2:B5"), colors.white);

setRangeValues(setup, "A8:A8", [["Summary Categories"]]);
styleHeader(setup.getRange("A8:A8"), colors.navy);
setRangeValues(setup, `A9:A${8 + categories.length}`, categories.map((category) => [category]));
stylePanel(setup.getRange(`A9:A${8 + categories.length}`), colors.white);

setRangeValues(setup, "D8:H8", [[
  "Supervisor Watchlist",
  "Employee ID Watchlist",
  "Completion Mark",
  "Paste/Export Guidance",
  "",
]]);
styleHeader(setup.getRange("D8:H8"), colors.navy);
setRangeValues(setup, "D9:H13", [
  ["", "", "X", "Enter supervisor names in column D to track them on the dashboard.", ""],
  ["", "", "", "Paste rows into Incident Tracker 4.0. Leave Completed blank until closed.", ""],
  ["", "", "", "Summary should use one of the categories in column A when possible.", ""],
  ["", "", "", "", ""],
  ["", "", "", "", ""],
]);
setRangeValues(setup, `D9:D${8 + supervisorWatchlist.length}`, supervisorWatchlist.map((name) => [name]));
stylePanel(setup.getRange("D9:H28"), colors.white);
setup.getRange("D9:E9").format.wrapText = true;
setup.getRange("G9:H11").format.wrapText = true;
setup.freezePanes.freezeRows(8);
setColumnWidth(setup, "A", 28);
setColumnWidth(setup, "B", 18);
setColumnWidth(setup, "D", 26);
setColumnWidth(setup, "E", 22);
setColumnWidth(setup, "F", 16);
setColumnWidth(setup, "G", 34);
setColumnWidth(setup, "H", 20);

// Incident Tracker
incident.showGridLines = false;
setRangeValues(incident, "A1:K1", [[
  "Week",
  "Date",
  "Employee Name",
  "Employee ID",
  "Supervisor",
  "HR Person",
  "Follow-up Owner",
  "Follow-up Due",
  "Information",
  "Summary",
  "Completed",
]]);
styleHeader(incident.getRange("A1:K1"), colors.navy);

const weekFormulas = [];
for (let row = 2; row <= DATA_LAST_ROW; row += 1) {
  weekFormulas.push([`=IF(B${row}="","",IFERROR(MAX(1,INT((B${row}-${setupSheet}!$B$2)/7)+1),""))`]);
}
setRangeFormulas(incident, `A2:A${DATA_LAST_ROW}`, weekFormulas);
if (trackerRows.length > 0) {
  setRangeValues(incident, `B2:K${trackerRows.length + 1}`, trackerRows);
}

incident.getRange(`A1:K${DATA_LAST_ROW}`).format.borders = {
  preset: "inside",
  style: "thin",
  color: "#EEF2F6",
};
incident.getRange(`A2:K${DATA_LAST_ROW}`).format = {
  fill: colors.white,
  wrapText: true,
};
incident.getRange(`A2:A${DATA_LAST_ROW}`).format.fill = colors.lightBlue;
incident.getRange(`K2:K${DATA_LAST_ROW}`).format.fill = colors.lightGreen;
applyNumberFormat(incident, `A2:A${DATA_LAST_ROW}`, "0");
applyNumberFormat(incident, `B2:B${DATA_LAST_ROW}`, "m/d/yyyy");
applyNumberFormat(incident, `H2:H${DATA_LAST_ROW}`, "m/d/yyyy");

incident.getRange(`F2:F${DATA_LAST_ROW}`).dataValidation = {
  rule: { type: "list", values: hrPeople },
};
incident.getRange(`G2:G${DATA_LAST_ROW}`).dataValidation = {
  rule: { type: "list", values: Array.from(new Set([...supervisors, ...hrPeople])) },
};
incident.getRange(`J2:J${DATA_LAST_ROW}`).dataValidation = {
  rule: { type: "list", formula1: `${setupSheet}!$A$9:$A$22` },
};
incident.getRange(`K2:K${DATA_LAST_ROW}`).dataValidation = {
  rule: { type: "list", values: ["X"] },
};
incident.getRange(`K2:K${DATA_LAST_ROW}`).conditionalFormats.add("containsText", {
  text: "X",
  format: {
    fill: colors.lightGreen,
    font: { bold: true, color: colors.green },
  },
});

const incidentTable = incident.tables.add(`A1:K${DATA_LAST_ROW}`, true, "IncidentTable");
incidentTable.style = "TableStyleMedium2";
incidentTable.showFilterButton = true;
incident.freezePanes.freezeRows(1);
incident.getRange(`A1:A${DATA_LAST_ROW}`).format.columnWidth = 10;
incident.getRange(`B1:B${DATA_LAST_ROW}`).format.columnWidth = 13;
incident.getRange(`C1:C${DATA_LAST_ROW}`).format.columnWidth = 22;
incident.getRange(`D1:D${DATA_LAST_ROW}`).format.columnWidth = 16;
incident.getRange(`E1:E${DATA_LAST_ROW}`).format.columnWidth = 20;
incident.getRange(`F1:F${DATA_LAST_ROW}`).format.columnWidth = 18;
incident.getRange(`G1:G${DATA_LAST_ROW}`).format.columnWidth = 20;
incident.getRange(`H1:H${DATA_LAST_ROW}`).format.columnWidth = 14;
incident.getRange(`I1:I${DATA_LAST_ROW}`).format.columnWidth = 34;
incident.getRange(`J1:J${DATA_LAST_ROW}`).format.columnWidth = 28;
incident.getRange(`K1:K${DATA_LAST_ROW}`).format.columnWidth = 12;
incident.getRange(`A2:K${DATA_LAST_ROW}`).format.rowHeight = 24;

// Analysis
analysis.showGridLines = false;
setRangeValues(analysis, "A1:F1", [[
  "Week",
  "Week Start",
  "Total Walk-ins",
  "Completed",
  "Open",
  "WoW % Change",
]]);
styleHeader(analysis.getRange("A1:F1"), colors.navy);

const weekRows = [];
for (let i = 1; i <= WEEK_COUNT; i += 1) {
  const row = i + 1;
  weekRows.push([
    i,
    `=${setupSheet}!$B$2+(A${row}-1)*7`,
    `=COUNTIFS(${weekRange},A${row},${dateRange},"<>")`,
    `=COUNTIFS(${weekRange},A${row},${dateRange},"<>",${completedRange},"X")`,
    `=COUNTIFS(${weekRange},A${row},${dateRange},"<>",${completedRange},"<>X")`,
    row === 2 ? "=0" : `=IFERROR((C${row}-C${row - 1})/C${row - 1},0)`,
  ]);
}
analysis.getRange(`A2:A${WEEK_COUNT + 1}`).values = weekRows.map((r) => [r[0]]);
analysis.getRange(`B2:F${WEEK_COUNT + 1}`).formulas = weekRows.map((r) => r.slice(1));
applyNumberFormat(analysis, `B2:B${WEEK_COUNT + 1}`, "m/d/yyyy");
applyNumberFormat(analysis, `C2:E${WEEK_COUNT + 1}`, "#,##0");
applyNumberFormat(analysis, `F2:F${WEEK_COUNT + 1}`, "0.0%");
stylePanel(analysis.getRange(`A2:F${WEEK_COUNT + 1}`), colors.white);

setRangeValues(analysis, "H1:M1", [[
  "Summary Category",
  "Total",
  "Open",
  "Completed",
  "Completion Rate",
  "Share of Walk-ins",
]]);
styleHeader(analysis.getRange("H1:M1"), colors.navy);
setRangeValues(analysis, `H2:H${categories.length + 1}`, categories.map((category) => [category]));
const categoryFormulas = categories.map((_, index) => {
  const row = index + 2;
  return [
    `=COUNTIFS(${summaryRange},H${row},${dateRange},"<>")`,
    `=COUNTIFS(${summaryRange},H${row},${dateRange},"<>",${completedRange},"<>X")`,
    `=COUNTIFS(${summaryRange},H${row},${dateRange},"<>",${completedRange},"X")`,
    `=IFERROR(K${row}/I${row},0)`,
    `=IFERROR(I${row}/$S$4,0)`,
  ];
});
setRangeFormulas(analysis, `I2:M${categories.length + 1}`, categoryFormulas);
applyNumberFormat(analysis, `I2:K${categories.length + 1}`, "#,##0");
applyNumberFormat(analysis, `L2:M${categories.length + 1}`, "0.0%");
stylePanel(analysis.getRange(`H2:M${categories.length + 1}`), colors.white);

setRangeValues(analysis, "O1:T1", [["Metric", "Value", "", "KPI", "Value", ""]]);
styleHeader(analysis.getRange("O1:T1"), colors.teal);
setRangeValues(analysis, "O2:P9", [
  ["Missing Summary", ""],
  ["Missing Supervisor", ""],
  ["Open > 30 Days", ""],
  ["Oldest Open Days", ""],
  ["Active Weeks", ""],
  ["Peak Week", ""],
  ["Top Category", ""],
  ["Chart End Week", ""],
]);
setRangeFormulas(analysis, "P2:P9", [
  [`=COUNTIFS(${dateRange},"<>",${summaryRange},"")`],
  [`=COUNTIFS(${dateRange},"<>",${supervisorRange},"")`],
  [`=COUNTIFS(${dateRange},"<>",${completedRange},"<>X",${dateRange},"<"&TODAY()-30)`],
  [`=IF($S$8=0,0,IFERROR(TODAY()-MINIFS(${dateRange},${completedRange},"<>X",${dateRange},"<>"),0))`],
  [`=COUNTIF(C2:C${WEEK_COUNT + 1},">0")`],
  [`=IF($S$4=0,0,IFERROR(INDEX(A2:A${WEEK_COUNT + 1},MATCH(MAX(C2:C${WEEK_COUNT + 1}),C2:C${WEEK_COUNT + 1},0)),0))`],
  [`=IF($S$4=0,"-",IFERROR(INDEX(H2:H${categories.length + 1},MATCH(MAX(I2:I${categories.length + 1}),I2:I${categories.length + 1},0)),"-"))`],
  [`=MAX(IFERROR(MAX(${weekRange}),0))`],
]);

setRangeValues(analysis, "R2:S13", [
  ["Latest Data Week", ""],
  ["Current Week Walk-ins", ""],
  ["Total Walk-ins", ""],
  ["Prior Week Walk-ins", ""],
  ["WoW % Change", ""],
  ["Completed Items", ""],
  ["Open Walk-ins", ""],
  [`${REPORTING_WINDOW_LABEL} Completion`, ""],
  ["Avg Weekly Walk-ins", ""],
  ["Peak Week", ""],
  ["Top Category", ""],
  ["Oldest Open Days", ""],
]);
setRangeFormulas(analysis, "S2:S13", [
  [`=IFERROR(MAXIFS(${weekRange},${dateRange},">="&TODAY()-${REPORTING_DAYS},${dateRange},"<="&TODAY()),0)`],
  [`=IF(S2=0,0,COUNTIFS(${weekRange},S2,${dateRange},"<>"))`],
  [`=COUNTIFS(${dateRange},"<>")`],
  [`=IF(S2<=1,0,COUNTIFS(${weekRange},S2-1,${dateRange},"<>"))`],
  [`=IFERROR((S3-S5)/S5,0)`],
  [`=COUNTIFS(${dateRange},"<>",${completedRange},"X")`],
  [`=COUNTIFS(${dateRange},"<>",${completedRange},"<>X")`],
  [`=IFERROR(COUNTIFS(${dateRange},">="&TODAY()-${REPORTING_DAYS},${dateRange},"<="&TODAY(),${completedRange},"X")/COUNTIFS(${dateRange},">="&TODAY()-${REPORTING_DAYS},${dateRange},"<="&TODAY()),0)`],
  [`=IFERROR(S4/P6,0)`],
  [`=P7`],
  [`=P8`],
  [`=P5`],
]);
applyNumberFormat(analysis, "P2:P7", "#,##0");
applyNumberFormat(analysis, "P9:P9", "0");
applyNumberFormat(analysis, "S2:S5", "#,##0");
applyNumberFormat(analysis, "S6:S6", "0.0%");
applyNumberFormat(analysis, "S7:S9", "#,##0");
applyNumberFormat(analysis, "S10:S10", "0.0%");
applyNumberFormat(analysis, "S11:S13", "#,##0");
stylePanel(analysis.getRange("O2:T13"), colors.white);

setRangeValues(analysis, `A${LAST_12_START_ROW}:D${LAST_12_START_ROW}`, [[
  "Week",
  "Total",
  "Completed",
  "Open",
]]);
styleHeader(analysis.getRange(`A${LAST_12_START_ROW}:D${LAST_12_START_ROW}`), colors.teal);
const last12Formulas = [];
for (let i = 1; i <= 12; i += 1) {
  const row = LAST_12_START_ROW + i;
  if (i === 1) {
    last12Formulas.push([
      `=MAX(1,$P$9-11)`,
      `=COUNTIFS(${weekRange},A${row},${dateRange},"<>")`,
      `=COUNTIFS(${weekRange},A${row},${dateRange},"<>",${completedRange},"X")`,
      `=COUNTIFS(${weekRange},A${row},${dateRange},"<>",${completedRange},"<>X")`,
    ]);
  } else {
    last12Formulas.push([
      `=A${row - 1}+1`,
      `=COUNTIFS(${weekRange},A${row},${dateRange},"<>")`,
      `=COUNTIFS(${weekRange},A${row},${dateRange},"<>",${completedRange},"X")`,
      `=COUNTIFS(${weekRange},A${row},${dateRange},"<>",${completedRange},"<>X")`,
    ]);
  }
}
setRangeFormulas(analysis, `A${LAST_12_START_ROW + 1}:D${LAST_12_START_ROW + 12}`, last12Formulas);
applyNumberFormat(analysis, `A${LAST_12_START_ROW + 1}:D${LAST_12_START_ROW + 12}`, "#,##0");
stylePanel(analysis.getRange(`A${LAST_12_START_ROW + 1}:D${LAST_12_START_ROW + 12}`), colors.white);

const dayStart = LAST_12_START_ROW;
setRangeValues(analysis, `F${dayStart}:G${dayStart + 7}`, [
  ["Day", "Walk-ins"],
  ["Mon", ""],
  ["Tue", ""],
  ["Wed", ""],
  ["Thu", ""],
  ["Fri", ""],
  ["Sat", ""],
  ["Sun", ""],
]);
styleHeader(analysis.getRange(`F${dayStart}:G${dayStart}`), colors.teal);
const dayFormulas = [];
for (let i = 1; i <= 7; i += 1) {
  dayFormulas.push([`=SUMPRODUCT(--(${dateRange}<>""),--(IFERROR(MOD(${dateRange}-1,7)+1,0)=${i}))`]);
}
setRangeFormulas(analysis, `G${dayStart + 1}:G${dayStart + 7}`, dayFormulas);
applyNumberFormat(analysis, `G${dayStart + 1}:G${dayStart + 7}`, "#,##0");
stylePanel(analysis.getRange(`F${dayStart + 1}:G${dayStart + 7}`), colors.white);

setRangeValues(analysis, `I${dayStart}:J${dayStart + 4}`, [
  ["Open Age", "Open Walk-ins"],
  ["0-30 days", ""],
  ["31-60 days", ""],
  ["61-90 days", ""],
  ["90+ days", ""],
]);
styleHeader(analysis.getRange(`I${dayStart}:J${dayStart}`), colors.teal);
setRangeFormulas(analysis, `J${dayStart + 1}:J${dayStart + 4}`, [
  [`=COUNTIFS(${completedRange},"<>X",${dateRange},"<>",${dateRange},">="&TODAY()-30,${dateRange},"<="&TODAY())`],
  [`=COUNTIFS(${completedRange},"<>X",${dateRange},">="&TODAY()-60,${dateRange},"<"&TODAY()-30)`],
  [`=COUNTIFS(${completedRange},"<>X",${dateRange},">="&TODAY()-90,${dateRange},"<"&TODAY()-60)`],
  [`=COUNTIFS(${completedRange},"<>X",${dateRange},"<"&TODAY()-90,${dateRange},"<>")`],
]);
applyNumberFormat(analysis, `J${dayStart + 1}:J${dayStart + 4}`, "#,##0");
stylePanel(analysis.getRange(`I${dayStart + 1}:J${dayStart + 4}`), colors.white);

setRangeValues(analysis, `L${dayStart}:P${dayStart}`, [[
  "Supervisor",
  "Total",
  "Open",
  "Completed",
  "Completion Rate",
]]);
styleHeader(analysis.getRange(`L${dayStart}:P${dayStart}`), colors.teal);
const supervisorRows = [];
for (let i = 0; i < 20; i += 1) {
  const row = dayStart + 1 + i;
  const setupRow = 9 + i;
  supervisorRows.push([
    `=IF(${setupSheet}!D${setupRow}="","",${setupSheet}!D${setupRow})`,
    `=IF(L${row}="","",COUNTIFS(${supervisorRange},L${row},${dateRange},"<>"))`,
    `=IF(L${row}="","",COUNTIFS(${supervisorRange},L${row},${dateRange},"<>",${completedRange},"<>X"))`,
    `=IF(L${row}="","",COUNTIFS(${supervisorRange},L${row},${dateRange},"<>",${completedRange},"X"))`,
    `=IF(L${row}="","",IFERROR(O${row}/M${row},0))`,
  ]);
}
setRangeFormulas(analysis, `L${dayStart + 1}:P${dayStart + 20}`, supervisorRows);
applyNumberFormat(analysis, `M${dayStart + 1}:O${dayStart + 20}`, "#,##0");
applyNumberFormat(analysis, `P${dayStart + 1}:P${dayStart + 20}`, "0.0%");
stylePanel(analysis.getRange(`L${dayStart + 1}:P${dayStart + 20}`), colors.white);

analysis.freezePanes.freezeRows(1);
["A", "B", "C", "D", "E", "F", "H", "I", "J", "K", "L", "M", "O", "P", "R", "S"].forEach((col) => {
  setColumnWidth(analysis, col, 15);
});
setColumnWidth(analysis, "H", 30);
setColumnWidth(analysis, "O", 22);
setColumnWidth(analysis, "R", 24);

// Dashboard
dashboard.showGridLines = false;
mergeValue(dashboard, "A1:Q1", "HR Action Item Dashboard", {
  fill: colors.navy,
  font: { bold: true, color: colors.white },
  wrapText: true,
});
dashboard.getRange("A1:Q1").format.rowHeight = 32;
mergeFormula(
  dashboard,
  "A2:Q2",
  `=IF(${analysisSheet}!$S$4=0,"No walk-ins loaded yet - paste rows into Incident Tracker 4.0", "Dashboard updated from Incident Tracker 4.0 | Last 12 weeks shown")`,
  {
    fill: colors.lightBlue,
    font: { bold: true, color: colors.ink },
    wrapText: true,
  },
);
dashboard.getRange("A2:Q2").format.rowHeight = 24;

function addKpi(colStart, colEnd, label, formula, numberFormat, fill, accent = colors.navy) {
  const labelRange = `${colStart}4:${colEnd}4`;
  const valueRange = `${colStart}5:${colEnd}6`;
  const noteRange = `${colStart}7:${colEnd}7`;
  mergeValue(dashboard, labelRange, label, {
    fill: accent,
    font: { bold: true, color: colors.white },
    wrapText: true,
  });
  const value = mergeFormula(dashboard, valueRange, formula, {
    fill,
    font: { bold: true, color: colors.ink },
    wrapText: true,
  });
  value.format.numberFormat = numberFormat;
  mergeValue(dashboard, noteRange, "", {
    fill,
    font: { color: colors.muted },
    wrapText: true,
  });
  stylePanel(dashboard.getRange(`${colStart}4:${colEnd}7`), fill);
  dashboard.getRange(labelRange).format.fill = accent;
  dashboard.getRange(labelRange).format.font = { bold: true, color: colors.white };
}

addKpi("A", "C", "Total Walk-ins", `=${analysisSheet}!$S$4`, "#,##0", colors.lightBlue, colors.navy);
addKpi("D", "F", "Latest Week Total", `=${analysisSheet}!$S$3`, "#,##0", colors.lightGreen, colors.green);
addKpi("G", "I", `${REPORTING_WINDOW_LABEL} Week Change`, `=${analysisSheet}!$S$6`, "0.0%", colors.lightAmber, colors.amber);
addKpi("J", "L", `${REPORTING_WINDOW_LABEL} Completion`, `=${analysisSheet}!$S$9`, "0.0%", colors.lightGreen, colors.green);
addKpi("M", "O", "Open Walk-ins", `=${analysisSheet}!$S$8`, "#,##0", colors.lightRed, colors.red);
addKpi("P", "Q", "Avg Weekly", `=${analysisSheet}!$S$10`, "#,##0.0", colors.panel, colors.teal);
dashboard.getRange("A8:C8").merge();
dashboard.getRange("A8:C8").formulas = [[`="Peak week: "&${analysisSheet}!$S$11`]];
dashboard.getRange("D8:F8").merge();
dashboard.getRange("D8:F8").formulas = [[`="Top category: "&${analysisSheet}!$S$12`]];
dashboard.getRange("G8:I8").merge();
dashboard.getRange("G8:I8").formulas = [[`="Oldest open days: "&${analysisSheet}!$S$13`]];
dashboard.getRange("J8:Q8").merge();
dashboard.getRange("J8:Q8").formulas = [[`="Data quality - missing summary: "&${analysisSheet}!$P$2&" | missing supervisor: "&${analysisSheet}!$P$3`]];
dashboard.getRange("A8:Q8").format = {
  fill: colors.white,
  font: { color: colors.muted },
  wrapText: true,
  borders: { preset: "outside", style: "thin", color: colors.grid },
};

// Reserve chart panels with light fills before adding charts.
stylePanel(dashboard.getRange("A10:H25"), colors.white);
stylePanel(dashboard.getRange("J10:Q25"), colors.white);
stylePanel(dashboard.getRange("A27:H43"), colors.white);
stylePanel(dashboard.getRange("J27:Q43"), colors.white);

const weeklyTrend = dashboard.charts.add("line", analysis.getRange(`A${LAST_12_START_ROW}:B${LAST_12_START_ROW + 12}`));
weeklyTrend.title = "Weekly Walk-ins, Last 12 Weeks";
weeklyTrend.hasLegend = false;
weeklyTrend.xAxis = { axisType: "textAxis", textStyle: { fontSize: 9 } };
weeklyTrend.yAxis = { numberFormatCode: "#,##0" };
weeklyTrend.setPosition("A10", "H25");

const weeklyStatus = dashboard.charts.add("bar", analysis.getRange(`A${LAST_12_START_ROW}:D${LAST_12_START_ROW + 12}`));
weeklyStatus.title = "Total, Completed, and Open by Week";
weeklyStatus.hasLegend = true;
weeklyStatus.xAxis = { axisType: "textAxis", textStyle: { fontSize: 9 } };
weeklyStatus.yAxis = { numberFormatCode: "#,##0" };
weeklyStatus.setPosition("J10", "Q25");

const categoryMix = dashboard.charts.add("bar", analysis.getRange(`H1:I${categories.length + 1}`));
categoryMix.title = "Walk-ins by Summary Category";
categoryMix.hasLegend = false;
categoryMix.xAxis = { axisType: "textAxis", textStyle: { fontSize: 9 } };
categoryMix.yAxis = { numberFormatCode: "#,##0" };
categoryMix.setPosition("A27", "H43");

const openAge = dashboard.charts.add("bar", analysis.getRange(`I${dayStart}:J${dayStart + 4}`));
openAge.title = "Open Walk-ins by Age";
openAge.hasLegend = false;
openAge.xAxis = { axisType: "textAxis", textStyle: { fontSize: 9 } };
openAge.yAxis = { numberFormatCode: "#,##0" };
openAge.setPosition("J27", "Q43");

setRangeValues(dashboard, "A45:F45", [["Category Breakdown", "", "", "", "", ""]]);
dashboard.getRange("A45:F45").merge();
styleHeader(dashboard.getRange("A45:F45"), colors.navy);
setRangeValues(dashboard, "A46:F46", [["Category", "Total", "Open", "Completed", "Completion %", "Share"]]);
styleHeader(dashboard.getRange("A46:F46"), colors.teal);
const dashboardCategoryFormulas = categories.map((_, index) => {
  const sourceRow = index + 2;
  return [
    `=${analysisSheet}!H${sourceRow}`,
    `=${analysisSheet}!I${sourceRow}`,
    `=${analysisSheet}!J${sourceRow}`,
    `=${analysisSheet}!K${sourceRow}`,
    `=${analysisSheet}!L${sourceRow}`,
    `=${analysisSheet}!M${sourceRow}`,
  ];
});
setRangeFormulas(dashboard, `A47:F${46 + categories.length}`, dashboardCategoryFormulas);
applyNumberFormat(dashboard, `B47:D${46 + categories.length}`, "#,##0");
applyNumberFormat(dashboard, `E47:F${46 + categories.length}`, "0.0%");
stylePanel(dashboard.getRange(`A47:F${46 + categories.length}`), colors.white);

setRangeValues(dashboard, "J45:Q45", [["Supervisor Watchlist", "", "", "", "", "", "", ""]]);
dashboard.getRange("J45:Q45").merge();
styleHeader(dashboard.getRange("J45:Q45"), colors.navy);
setRangeValues(dashboard, "J46:N46", [["Supervisor", "Total", "Open", "Completed", "Completion %"]]);
styleHeader(dashboard.getRange("J46:N46"), colors.teal);
const supervisorDashboardRows = [];
for (let i = 0; i < 10; i += 1) {
  const sourceRow = dayStart + 1 + i;
  supervisorDashboardRows.push([
    `=IF(${analysisSheet}!L${sourceRow}="","",${analysisSheet}!L${sourceRow})`,
    `=IF(J${47 + i}="","",${analysisSheet}!M${sourceRow})`,
    `=IF(J${47 + i}="","",${analysisSheet}!N${sourceRow})`,
    `=IF(J${47 + i}="","",${analysisSheet}!O${sourceRow})`,
    `=IF(J${47 + i}="","",${analysisSheet}!P${sourceRow})`,
  ]);
}
setRangeFormulas(dashboard, "J47:N56", supervisorDashboardRows);
applyNumberFormat(dashboard, "K47:M56", "#,##0");
applyNumberFormat(dashboard, "N47:N56", "0.0%");
stylePanel(dashboard.getRange("J47:N56"), colors.white);

setRangeValues(dashboard, "P46:Q46", [["Floor Signals", "Value"]]);
styleHeader(dashboard.getRange("P46:Q46"), colors.teal);
setRangeValues(dashboard, "P47:P53", [
  ["Missing Summary"],
  ["Missing Supervisor"],
  ["Open > 30 Days"],
  ["Oldest Open Days"],
  ["Active Weeks"],
  ["Peak Week"],
  ["Top Category"],
]);
setRangeFormulas(dashboard, "Q47:Q53", [
  [`=${analysisSheet}!$P$2`],
  [`=${analysisSheet}!$P$3`],
  [`=${analysisSheet}!$P$4`],
  [`=${analysisSheet}!$P$5`],
  [`=${analysisSheet}!$P$6`],
  [`=${analysisSheet}!$P$7`],
  [`=${analysisSheet}!$P$8`],
]);
applyNumberFormat(dashboard, "Q47:Q52", "#,##0");
stylePanel(dashboard.getRange("P47:Q53"), colors.white);

// Executive Summary
mergeValue(dashboard, "A64:Q64", "Executive Summary", {
  fill: colors.navy,
  font: { bold: true, color: colors.white },
  wrapText: true,
});
mergeFormula(
  dashboard,
  "A65:Q65",
  `="All tracked walk-ins: "&${analysisSheet}!$S$4&" | Open: "&${analysisSheet}!$S$8&" | Closed: "&${analysisSheet}!$S$7`,
  {
    fill: colors.lightBlue,
    font: { bold: true, color: colors.ink },
    wrapText: true,
  },
);

function addExecutiveKpi(colStart, colEnd, label, formula, numberFormat, fill, accent) {
  mergeValue(dashboard, `${colStart}67:${colEnd}67`, label, {
    fill: accent,
    font: { bold: true, color: colors.white },
    wrapText: true,
  });
  const value = mergeFormula(dashboard, `${colStart}68:${colEnd}69`, formula, {
    fill,
    font: { bold: true, color: colors.ink },
    wrapText: true,
  });
  value.format.numberFormat = numberFormat;
  mergeValue(dashboard, `${colStart}70:${colEnd}70`, "", {
    fill,
    font: { color: colors.muted },
    wrapText: true,
  });
  stylePanel(dashboard.getRange(`${colStart}67:${colEnd}70`), fill);
  dashboard.getRange(`${colStart}67:${colEnd}67`).format.fill = accent;
  dashboard.getRange(`${colStart}67:${colEnd}67`).format.font = { bold: true, color: colors.white };
}

addExecutiveKpi("A", "D", "All Walk-ins", `=${analysisSheet}!$S$4`, "#,##0", colors.lightBlue, colors.navy);
addExecutiveKpi("E", "H", "Open Walk-ins", `=${analysisSheet}!$S$8`, "#,##0", colors.lightRed, colors.red);
addExecutiveKpi("I", "L", "Closed Walk-ins", `=${analysisSheet}!$S$7`, "#,##0", colors.lightGreen, colors.green);
addExecutiveKpi("M", "Q", "Overall Close Rate", `=IFERROR(${analysisSheet}!$S$7/${analysisSheet}!$S$4,0)`, "0.0%", colors.panel, colors.teal);

stylePanel(dashboard.getRange("A72:H90"), colors.white);
stylePanel(dashboard.getRange("J72:Q90"), colors.white);
const executiveTrend = dashboard.charts.add("line", analysis.getRange(`A${LAST_12_START_ROW}:D${LAST_12_START_ROW + 12}`));
executiveTrend.title = "Open, Closed, and Total Trend";
executiveTrend.hasLegend = true;
executiveTrend.xAxis = { axisType: "textAxis", textStyle: { fontSize: 9 } };
executiveTrend.yAxis = { numberFormatCode: "#,##0" };
executiveTrend.setPosition("A72", "H90");

mergeValue(dashboard, "J72:Q72", "Executive Readout", {
  fill: colors.teal,
  font: { bold: true, color: colors.white },
  wrapText: true,
});
setRangeValues(dashboard, "J73:K77", [
  ["Open Walk-ins", ""],
  ["Closed Walk-ins", ""],
  ["Overall Close Rate", ""],
  ["Latest Week", ""],
  ["Week Change", ""],
]);
styleHeader(dashboard.getRange("J73:K77"), colors.teal);
mergeFormula(dashboard, "L73:Q73", `=${analysisSheet}!$S$8`, { fill: colors.lightRed, font: { bold: true, color: colors.ink } }).format.numberFormat = "#,##0";
mergeFormula(dashboard, "L74:Q74", `=${analysisSheet}!$S$7`, { fill: colors.lightGreen, font: { bold: true, color: colors.ink } }).format.numberFormat = "#,##0";
mergeFormula(dashboard, "L75:Q75", `=IFERROR(${analysisSheet}!$S$7/${analysisSheet}!$S$4,0)`, { fill: colors.panel, font: { bold: true, color: colors.ink } }).format.numberFormat = "0.0%";
mergeFormula(dashboard, "L76:Q76", `=${analysisSheet}!$S$3`, { fill: colors.white, font: { bold: true, color: colors.ink } }).format.numberFormat = "#,##0";
mergeFormula(dashboard, "L77:Q77", `=${analysisSheet}!$S$6`, { fill: colors.lightAmber, font: { bold: true, color: colors.ink } }).format.numberFormat = "0.0%";
stylePanel(dashboard.getRange("J73:Q77"), colors.white);
dashboard.getRange("J73:K77").format.fill = colors.panel;
dashboard.getRange("J73:K77").format.font = { bold: true, color: colors.navy };
mergeFormula(dashboard, "J80:Q80", `="Selected reporting window: ${REPORTING_WINDOW_LABEL}"`, { fill: colors.lightBlue, font: { bold: true, color: colors.ink }, wrapText: true });
mergeFormula(dashboard, "J82:Q82", `="Trend compares each week's total, closed, and open walk-ins across the latest 12 weeks."`, { fill: colors.white, font: { color: colors.muted }, wrapText: true });

for (const col of ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q"]) {
  setColumnWidth(dashboard, col, 12);
}
setColumnWidth(dashboard, "A", 26);
setColumnWidth(dashboard, "B", 11);
setColumnWidth(dashboard, "C", 11);
setColumnWidth(dashboard, "D", 12);
setColumnWidth(dashboard, "E", 13);
setColumnWidth(dashboard, "F", 11);
setColumnWidth(dashboard, "J", 22);
setColumnWidth(dashboard, "K", 11);
setColumnWidth(dashboard, "L", 11);
setColumnWidth(dashboard, "M", 11);
setColumnWidth(dashboard, "N", 13);
setColumnWidth(dashboard, "P", 22);
setColumnWidth(dashboard, "Q", 12);
dashboard.getRange(DASHBOARD_MAIN_RANGE).format.wrapText = true;
dashboard.getRange("A4:Q8").format.rowHeight = 26;
dashboard.getRange("A45:Q61").format.rowHeight = 26;
dashboard.getRange("A64:Q90").format.rowHeight = 26;
dashboard.freezePanes.freezeRows(8);

// Compact visual polish.
dashboard.getRange(DASHBOARD_MAIN_RANGE).format.borders = {
  preset: "inside",
  style: "thin",
  color: "#EEF2F6",
};
analysis.getRange("A1:T260").format.borders = {
  preset: "inside",
  style: "thin",
  color: "#EEF2F6",
};

// Verification outputs
await fs.mkdir(previewDir, { recursive: true });
const inspection = await workbook.inspect({
  kind: "table",
  range: "Dashboard!A1:Q90",
  include: "values,formulas",
  tableMaxRows: 20,
  tableMaxCols: 12,
  maxChars: 8000,
});
console.log("DASHBOARD_INSPECT_START");
console.log(inspection.ndjson);
console.log("DASHBOARD_INSPECT_END");

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "final formula error scan",
});
console.log("ERROR_SCAN_START");
console.log(errors.ndjson);
console.log("ERROR_SCAN_END");

const renderJobs = [
  { sheetName: "Dashboard", range: "A1:Q90", scale: 1 },
  { sheetName: "Incident Tracker 4.0", range: "A1:K32", scale: 1 },
  { sheetName: "Analysis", range: "A1:T35", scale: 0.9 },
  { sheetName: "Analysis", range: "A270:P290", scale: 0.9, suffix: "_chart_helpers" },
  { sheetName: "Setup", range: "A1:H28", scale: 1 },
];

for (const job of renderJobs) {
  const preview = await workbook.render({
    sheetName: job.sheetName,
    range: job.range,
    scale: job.scale,
    format: "png",
  });
  await fs.writeFile(
    path.join(previewDir, `${job.sheetName.replace(/[^A-Za-z0-9]+/g, "_")}${job.suffix ?? ""}.png`),
    new Uint8Array(await preview.arrayBuffer()),
  );
}

await fs.mkdir(outputDir, { recursive: true });
const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(outputPath);
console.log(`OUTPUT=${outputPath}`);
