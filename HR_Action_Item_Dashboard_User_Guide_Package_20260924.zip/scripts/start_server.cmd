@echo off
setlocal
cd /d "%~dp0.."
if not exist logs mkdir logs
set "BUNDLED_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if exist "%BUNDLED_NODE%" (
  set "NODE_EXE=%BUNDLED_NODE%"
) else (
  set "NODE_EXE=node"
)
"%NODE_EXE%" server.mjs > logs\server.out.log 2> logs\server.err.log
