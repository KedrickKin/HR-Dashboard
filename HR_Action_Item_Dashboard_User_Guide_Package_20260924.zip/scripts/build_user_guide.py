from pathlib import Path
from datetime import date

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
ASSET_DIR = ROOT / "guide_assets"
DOCX_PATH = ROOT / "HR_Action_Item_Dashboard_User_Guide.docx"
ASSET_DIR.mkdir(exist_ok=True)

NAVY = "17324D"
INK = "182331"
MUTED = "506274"
TEAL = "1F8192"
GREEN = "2F8F64"
AMBER = "C28725"
RED = "BC3C3C"
PALE_BLUE = "EAF2F6"
PALE_GREEN = "E8F4EE"
PALE_AMBER = "FFF3DE"
PALE_RED = "FBE9E9"
LINE = "CFDCE5"


def rgb(hex_value):
    return tuple(int(hex_value[i:i + 2], 16) for i in (0, 2, 4))


def font(size, bold=False):
    candidates = [
        Path("C:/Windows/Fonts/segoeui.ttf"),
        Path("C:/Windows/Fonts/arial.ttf"),
        Path("C:/Windows/Fonts/calibri.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


def text_center(draw, box, text, fnt, fill=INK, spacing=4):
    x1, y1, x2, y2 = box
    bbox = draw.multiline_textbbox((0, 0), text, font=fnt, spacing=spacing, align="center")
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    draw.multiline_text(((x1 + x2 - tw) / 2, (y1 + y2 - th) / 2), text, font=fnt, fill=fill, spacing=spacing, align="center")


def rounded(draw, box, fill, outline=LINE, radius=18, width=2):
    draw.rounded_rectangle(box, radius=radius, fill=rgb(fill), outline=rgb(outline), width=width)


def arrow(draw, start, end, fill=TEAL, width=7, head=20):
    draw.line([start, end], fill=rgb(fill), width=width)
    x1, y1 = start
    x2, y2 = end
    if abs(x2 - x1) >= abs(y2 - y1):
        sign = 1 if x2 >= x1 else -1
        points = [(x2, y2), (x2 - sign * head, y2 - head // 2), (x2 - sign * head, y2 + head // 2)]
    else:
        sign = 1 if y2 >= y1 else -1
        points = [(x2, y2), (x2 - head // 2, y2 - sign * head), (x2 + head // 2, y2 - sign * head)]
    draw.polygon(points, fill=rgb(fill))


def pill(draw, box, text, fill, text_fill="FFFFFF", size=25):
    rounded(draw, box, fill, outline=fill, radius=22, width=1)
    text_center(draw, box, text, font(size, True), rgb(text_fill))


def save_startup_illustration():
    img = Image.new("RGB", (1600, 760), rgb("F7FAFC"))
    draw = ImageDraw.Draw(img)
    draw.text((60, 34), "Choose a startup path", font=font(42, True), fill=rgb(NAVY))
    draw.text((60, 92), "The recommended path keeps conflict-aware sync available.", font=font(25), fill=rgb(MUTED))

    boxes = [
        (70, 180, 440, 390, "1", "Double-click", "Start HR Dashboard.cmd", PALE_BLUE, NAVY),
        (585, 180, 1015, 390, "2", "Local server", "127.0.0.1:5177", PALE_GREEN, GREEN),
        (1160, 180, 1530, 390, "3", "Open", "Dashboard in browser", PALE_AMBER, AMBER),
    ]
    for x1, y1, x2, y2, number, title, body, fill, accent in boxes:
        rounded(draw, (x1, y1, x2, y2), fill, outline=accent, radius=22, width=3)
        draw.ellipse((x1 + 24, y1 + 24, x1 + 82, y1 + 82), fill=rgb(accent))
        text_center(draw, (x1 + 24, y1 + 24, x1 + 82, y1 + 82), number, font(28, True), rgb("FFFFFF"))
        text_center(draw, (x1 + 22, y1 + 96, x2 - 22, y1 + 150), title, font(28, True), rgb(NAVY))
        text_center(draw, (x1 + 28, y1 + 156, x2 - 28, y2 - 24), body, font(27, True), rgb(INK))
    arrow(draw, (445, 285), (575, 285))
    arrow(draw, (1020, 285), (1150, 285))

    draw.text((70, 465), "If you open index.html directly", font=font(31, True), fill=rgb(NAVY))
    rounded(draw, (70, 535, 610, 680), PALE_BLUE, outline=TEAL, radius=18, width=2)
    text_center(draw, (95, 555, 585, 625), "Server found", font(26, True), rgb(NAVY))
    text_center(draw, (95, 620, 585, 665), "opens synced mode", font(24), rgb(MUTED))
    rounded(draw, (990, 535, 1530, 680), PALE_AMBER, outline=AMBER, radius=18, width=2)
    text_center(draw, (1015, 555, 1505, 625), "Server unavailable", font(26, True), rgb(NAVY))
    text_center(draw, (1015, 620, 1505, 665), "offers local-only mode", font(24), rgb(MUTED))
    draw.line([(800, 455), (800, 535)], fill=rgb(LINE), width=4)
    draw.line([(610, 607), (990, 607)], fill=rgb(LINE), width=4)
    img.save(ASSET_DIR / "startup_modes.png")


def save_controls_illustration():
    img = Image.new("RGB", (1600, 760), rgb("F7FAFC"))
    draw = ImageDraw.Draw(img)
    draw.text((60, 34), "The controls you will use most", font=font(42, True), fill=rgb(NAVY))
    draw.text((60, 92), "The top bar shows sync state and the main data actions.", font=font(25), fill=rgb(MUTED))

    rounded(draw, (60, 165, 1540, 355), NAVY, outline=NAVY, radius=18, width=1)
    draw.text((95, 194), "HR Action Item Dashboard", font=font(29, True), fill=rgb("FFFFFF"))
    draw.text((95, 244), "Linked • Last synced just now", font=font(22), fill=rgb("D9EAF4"))
    button_specs = [
        (750, 205, 850, 295, "Refresh", TEAL, "1"),
        (875, 205, 1075, 295, "Export Backup", "2A6579", "2"),
        (1100, 205, 1300, 295, "Import Excel", "466B7E", "3"),
        (1325, 205, 1505, 295, "Export Excel", GREEN, "4"),
    ]
    for x1, y1, x2, y2, label, fill, number in button_specs:
        rounded(draw, (x1, y1, x2, y2), fill, outline=fill, radius=10, width=1)
        draw.ellipse((x1 + 8, y1 + 8, x1 + 42, y1 + 42), fill=rgb(AMBER))
        text_center(draw, (x1 + 8, y1 + 8, x1 + 42, y1 + 42), number, font(15, True), rgb("FFFFFF"))
        label_size = 18 if label == "Refresh" else 20
        text_center(draw, (x1 + 5, y1 + 39, x2 - 5, y2 - 5), label, font(label_size, True), rgb("FFFFFF"))

    tab_y = 400
    tabs = ["Dashboard", "Executive Summary", "Add Walk-In", "Search & Edit", "Open Walk-ins", "Activity History"]
    x = 60
    widths = [180, 250, 190, 205, 210, 250]
    for index, (tab, width) in enumerate(zip(tabs, widths), start=1):
        fill = PALE_BLUE if index != 1 else "D8EEF0"
        rounded(draw, (x, tab_y, x + width, tab_y + 86), fill, outline=LINE, radius=8, width=2)
        draw.ellipse((x + 8, tab_y + 8, x + 42, tab_y + 42), fill=rgb(TEAL))
        text_center(draw, (x + 8, tab_y + 8, x + 42, tab_y + 42), str(index + 4), font(14, True), rgb("FFFFFF"))
        text_center(draw, (x + 8, tab_y + 39, x + width - 8, tab_y + 80), tab, font(20, True), rgb(NAVY))
        x += width + 12

    rounded(draw, (60, 565, 1540, 690), "FFFFFF", outline=LINE, radius=14, width=2)
    draw.text((90, 592), "Use the tabs to move between summary, entry, search, open work, and history.", font=font(24, True), fill=rgb(INK))
    draw.text((90, 636), "The sync badge is the first place to look when a save needs attention.", font=font(22), fill=rgb(MUTED))
    img.save(ASSET_DIR / "controls_map.png")


def save_edit_illustration():
    img = Image.new("RGB", (1600, 760), rgb("F7FAFC"))
    draw = ImageDraw.Draw(img)
    draw.text((60, 34), "Everyday record workflow", font=font(42, True), fill=rgb(NAVY))
    draw.text((60, 92), "Add a record, update it, or focus on unresolved work.", font=font(25), fill=rgb(MUTED))

    cards = [
        (60, 180, 470, 610, "Add Walk-In", "1", PALE_BLUE, TEAL, ["Open the tab", "Complete the fields", "Press Append Row"]),
        (595, 180, 1005, 610, "Search & Edit", "2", PALE_GREEN, GREEN, ["Filter or search", "Press Edit", "Press Save or Delete"]),
        (1130, 180, 1540, 610, "Open Walk-ins", "3", PALE_AMBER, AMBER, ["Filter open work", "Click a row", "Save when complete"]),
    ]
    for x1, y1, x2, y2, title, number, fill, accent, steps in cards:
        rounded(draw, (x1, y1, x2, y2), fill, outline=accent, radius=22, width=3)
        draw.ellipse((x1 + 24, y1 + 24, x1 + 78, y1 + 78), fill=rgb(accent))
        text_center(draw, (x1 + 24, y1 + 24, x1 + 78, y1 + 78), number, font(26, True), rgb("FFFFFF"))
        draw.text((x1 + 95, y1 + 33), title, font=font(29, True), fill=rgb(NAVY))
        y = y1 + 140
        for step_no, step in enumerate(steps, start=1):
            draw.ellipse((x1 + 42, y, x1 + 80, y + 38), fill=rgb("FFFFFF"), outline=rgb(accent), width=2)
            text_center(draw, (x1 + 42, y, x1 + 80, y + 38), str(step_no), font(17, True), rgb(accent))
            draw.text((x1 + 100, y + 4), step, font=font(21, True), fill=rgb(INK))
            y += 82
    arrow(draw, (485, 395), (580, 395), fill=TEAL)
    arrow(draw, (1020, 395), (1115, 395), fill=TEAL)
    rounded(draw, (60, 650, 1540, 710), "FFFFFF", outline=LINE, radius=10, width=2)
    text_center(draw, (90, 658, 1510, 702), "All record changes pass through the sync check before they are shared.", font(22, True), rgb(NAVY))
    img.save(ASSET_DIR / "edit_flow.png")


def save_sync_illustration():
    img = Image.new("RGB", (1600, 900), rgb("F7FAFC"))
    draw = ImageDraw.Draw(img)
    draw.text((60, 30), "How conflict-aware sync protects changes", font=font(40, True), fill=rgb(NAVY))
    draw.text((60, 85), "Before a save, the app compares the last baseline, your local version, and the latest shared version.", font=font(23), fill=rgb(MUTED))

    cols = [
        (60, 150, 485, 370, "Saved baseline", "The last shared version", PALE_BLUE, NAVY),
        (590, 150, 1015, 370, "Your local version", "Edits made in this browser", PALE_GREEN, GREEN),
        (1120, 150, 1545, 370, "Shared destination", "Latest server data", PALE_AMBER, AMBER),
    ]
    for x1, y1, x2, y2, title, body, fill, accent in cols:
        rounded(draw, (x1, y1, x2, y2), fill, outline=accent, radius=20, width=3)
        text_center(draw, (x1 + 20, y1 + 28, x2 - 20, y1 + 84), title, font(27, True), rgb(NAVY))
        text_center(draw, (x1 + 24, y1 + 100, x2 - 24, y2 - 24), body, font(23), rgb(INK))
    arrow(draw, (495, 260), (575, 260), fill=TEAL)
    arrow(draw, (1030, 260), (1105, 260), fill=TEAL)

    rounded(draw, (350, 430, 1250, 570), "FFFFFF", outline=TEAL, radius=20, width=3)
    text_center(draw, (380, 447, 1220, 500), "Three-way merge before save", font(31, True), rgb(NAVY))
    text_center(draw, (390, 505, 1210, 550), "Independent changes can be combined safely.", font(23), rgb(MUTED))
    arrow(draw, (800, 375), (800, 420), fill=TEAL)

    rounded(draw, (90, 650, 740, 830), PALE_GREEN, outline=GREEN, radius=18, width=3)
    text_center(draw, (120, 670, 710, 720), "Independent changes", font(27, True), rgb(GREEN))
    text_center(draw, (125, 730, 705, 800), "Merge and save\nRefresh the baseline after success", font(23), rgb(INK))
    rounded(draw, (860, 650, 1510, 830), PALE_RED, outline=RED, radius=18, width=3)
    text_center(draw, (890, 670, 1480, 720), "Overlap or edit versus delete", font(27, True), rgb(RED))
    text_center(draw, (895, 725, 1475, 797), "Pause with Conflict\nExport Backup, then choose a resolution", font(23), rgb(INK))
    draw.line([(800, 570), (800, 620)], fill=rgb(LINE), width=4)
    draw.line([(800, 620), (415, 620), (415, 650)], fill=rgb(LINE), width=4)
    draw.line([(800, 620), (1185, 620), (1185, 650)], fill=rgb(LINE), width=4)
    img.save(ASSET_DIR / "sync_three_way.png")


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_border(cell, color=LINE, size="8"):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = "w:" + edge
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), color)


def set_cell_text(cell, text, bold=False, color=INK, size=9.3):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(text)
    run.bold = bold
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor.from_string(color)
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_table(doc, headers, rows, widths=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    header_pr = table.rows[0]._tr.get_or_add_trPr()
    header_marker = OxmlElement("w:tblHeader")
    header_marker.set(qn("w:val"), "true")
    header_pr.append(header_marker)
    if widths:
        for cell, width in zip(table.rows[0].cells, widths):
            cell.width = Inches(width)
    for cell, header in zip(table.rows[0].cells, headers):
        set_cell_shading(cell, NAVY)
        set_cell_border(cell, color=NAVY, size="10")
        set_cell_text(cell, header, bold=True, color="FFFFFF", size=9.5)
    for row in rows:
        cells = table.add_row().cells
        for index, (cell, value) in enumerate(zip(cells, row)):
            if widths:
                cell.width = Inches(widths[index])
            set_cell_shading(cell, "FFFFFF" if len(table.rows) % 2 else "F5F8FA")
            set_cell_border(cell)
            set_cell_text(cell, str(value), size=9.2)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def add_picture(doc, path, width=6.7, caption=None, alt_text=None):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(3)
    picture_run = p.add_run()
    picture_run.add_picture(str(path), width=Inches(width))
    if alt_text:
        for doc_pr in picture_run._element.iter(qn("wp:docPr")):
            doc_pr.set("descr", alt_text)
            doc_pr.set("title", alt_text)
    if caption:
        cp = doc.add_paragraph()
        cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cp.paragraph_format.space_after = Pt(8)
        r = cp.add_run(caption)
        r.italic = True
        r.font.size = Pt(8.5)
        r.font.color.rgb = RGBColor.from_string(MUTED)


def add_step(doc, number, title, body):
    p = doc.add_paragraph(style="Normal")
    p.paragraph_format.left_indent = Inches(0.05)
    p.paragraph_format.space_after = Pt(5)
    n = p.add_run(f"{number}. {title}  ")
    n.bold = True
    n.font.color.rgb = RGBColor.from_string(NAVY)
    p.add_run(body)


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(3)
    p.add_run(text)
    return p


def add_inline_lead(doc, lead, text):
    p = doc.add_paragraph(style="Normal")
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(lead)
    r.bold = True
    r.font.color.rgb = RGBColor.from_string(NAVY)
    p.add_run(text)
    return p


def set_run_font(run, name="Arial", size=None, color=None, bold=None):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    if size:
        run.font.size = Pt(size)
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold


def remove_paragraph_borders(paragraph):
    p_pr = paragraph._p.get_or_add_pPr()
    borders = p_pr.find(qn("w:pBdr"))
    if borders is not None:
        p_pr.remove(borders)


def remove_style_paragraph_borders(style):
    p_pr = style._element.find(qn("w:pPr"))
    if p_pr is None:
        return
    borders = p_pr.find(qn("w:pBdr"))
    if borders is not None:
        p_pr.remove(borders)


def build_docx():
    save_startup_illustration()
    save_controls_illustration()
    save_edit_illustration()
    save_sync_illustration()

    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.63)
    section.bottom_margin = Inches(0.58)
    section.left_margin = Inches(0.72)
    section.right_margin = Inches(0.72)
    settings = doc.settings.element
    for even_odd in settings.findall(qn("w:evenAndOddHeaders")):
        settings.remove(even_odd)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
    normal.font.size = Pt(10.2)
    normal.font.color.rgb = RGBColor.from_string(INK)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.08
    for name, size in (("Title", 27), ("Heading 1", 18), ("Heading 2", 12.5)):
        style = styles[name]
        remove_style_paragraph_borders(style)
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(NAVY if name != "Heading 1" else INK)
        style.paragraph_format.space_before = Pt(8 if name == "Heading 1" else 4)
        style.paragraph_format.space_after = Pt(6)
        style.paragraph_format.keep_with_next = True

    header = section.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    hr = hp.add_run("HR Action Item Dashboard  |  User Guide")
    set_run_font(hr, size=8.5, color=MUTED)
    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr = fp.add_run("Local dashboard guide  |  Generated 2026-09-24")
    set_run_font(fr, size=8, color=MUTED)

    title = doc.add_paragraph(style="Title")
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    title.paragraph_format.space_before = Pt(20)
    title.paragraph_format.space_after = Pt(5)
    remove_paragraph_borders(title)
    title.add_run("HR Action Item Dashboard User Guide")
    subtitle = doc.add_paragraph()
    subtitle.paragraph_format.space_after = Pt(16)
    sr = subtitle.add_run("How to start, use, and sync the local HR tracker")
    set_run_font(sr, size=14, color=TEAL, bold=True)

    intro = doc.add_paragraph()
    intro.paragraph_format.space_after = Pt(10)
    intro.add_run("Purpose. ").bold = True
    intro.add_run("This guide explains what to press in the HR Action Item Dashboard, how records move from entry to completion, and how the conflict-aware sync protects changes when more than one version exists.")

    add_table(doc, ["Start here", "What it means"], [
        ("Recommended", "Double-click Start HR Dashboard.cmd. It starts the local server when needed and opens the synced dashboard."),
        ("Direct launcher", "Double-click index.html. It opens synced mode when the local server is available and offers a local-only fallback when it is not."),
        ("First screen", "The dashboard starts with the project's current data. This project is intentionally shipped without sample employee records."),
    ], widths=[1.35, 5.25])

    doc.add_paragraph().add_run()
    h = doc.add_paragraph(style="Heading 2")
    h.add_run("The short version")
    add_step(doc, "1", "Start", "Double-click Start HR Dashboard.cmd and wait for the browser to open.")
    add_step(doc, "2", "Work", "Use Dashboard, Add Walk-In, Search & Edit, and Open Walk-ins for day-to-day work.")
    add_step(doc, "3", "Save safely", "Watch the sync status. Export a backup before resolving a conflict or replacing a version.")
    add_step(doc, "4", "Finish", "Use Activity History to confirm imports, edits, deletes, and sync activity.")

    doc.add_page_break()
    doc.add_paragraph("1  Start the dashboard", style="Heading 1")
    add_inline_lead(doc, "Recommended. ", "Double-click Start HR Dashboard.cmd in the project folder. It checks whether the local server is running, starts it if necessary, waits for a response, and opens the dashboard.")
    add_inline_lead(doc, "If the browser does not open. ", "Open http://127.0.0.1:5177/ manually after the launcher finishes. The server is local to this computer.")
    add_picture(doc, ASSET_DIR / "startup_modes.png", width=6.75, caption="Startup illustration: the command file is the recommended entry point; index.html can launch synced or local-only mode.", alt_text="Diagram showing Start HR Dashboard cmd leading to the local server and browser, with index html branching to synced or local only mode.")
    add_table(doc, ["Mode", "What happens", "Use it when"], [
        ("Synced server mode", "The dashboard reads and writes the local shared destination through the Node server and runs conflict checks before saving.", "Normal work, shared project folder, or when you need the strongest sync protection available."),
        ("Local-only mode", "The browser uses local storage. Changes remain in that browser until you reconnect and refresh.", "The server is unavailable or Node.js cannot be started."),
    ], widths=[1.35, 3.2, 2.05])
    add_inline_lead(doc, "Internet note. ", "The dashboard uses localhost and local project files. It does not make external internet requests. OneDrive may still synchronize the folder according to its own settings.")

    doc.add_page_break()
    doc.add_paragraph("2  Understand the screen", style="Heading 1")
    add_inline_lead(doc, "Start with the top bar. ", "It contains the sync state and the actions that affect files. Use the tabs below it to change views; switching tabs does not save or delete data by itself.")
    add_picture(doc, ASSET_DIR / "controls_map.png", width=6.75, caption="Control map: numbered callouts match the action table below.", alt_text="Illustrated dashboard top bar with numbered controls for Refresh, Export Backup, Import Excel, Export Excel, and six navigation tabs.")
    add_table(doc, ["Press", "What it does"], [
        ("1  Refresh data", "Reads the latest destination data, updates the saved baseline, and attempts to reconnect after local-only mode."),
        ("2  Export Backup", "Downloads a JSON snapshot of local records, the baseline, and conflict details. Use it before conflict resolution."),
        ("3  Import Excel", "Validates a workbook or compatible file, skips duplicates, reports invalid rows, and keeps existing records when columns are missing or renamed."),
        ("4  Export Excel", "Creates an Excel-compatible snapshot of the current tracker data."),
        ("Dashboard / Executive Summary", "Review totals, completion, open work, trends, reminders, and data quality signals."),
        ("Add Walk-In / Search & Edit / Open Walk-ins", "Add a record, find and edit records, or focus on unresolved work."),
        ("Activity History", "Review create, update, delete, import, and sync events."),
    ], widths=[2.2, 4.4])
    add_inline_lead(doc, "Sync status labels. ", "Loading means the first read is in progress. Linked means server mode is active. Last synced shows the latest successful save or refresh. Saving appears during a write. Local-only, Error, and Conflict require attention before relying on shared data.")

    doc.add_page_break()
    doc.add_paragraph("3  Add, edit, and complete work", style="Heading 1")
    add_inline_lead(doc, "Use the narrowest workflow that matches the task. ", "Adding a new record is different from correcting an existing record, and Open Walk-ins is designed for unresolved work that needs follow-up.")
    add_picture(doc, ASSET_DIR / "edit_flow.png", width=6.75, caption="Record workflow illustration: each path ends with an explicit save action that passes through sync checks.", alt_text="Three-column workflow diagram for Add Walk In, Search and Edit, and Open Walk Ins, each ending with a save action.")
    add_step(doc, "1", "Add a new record", "Click Add Walk-In, complete the fields, and press Append Row. The dashboard shows the new record after the save finishes.")
    add_step(doc, "2", "Find an existing record", "Click Search & Edit, enter a name or use the filters, and press Show Matches. Use the Edit button on the row you need.")
    add_step(doc, "3", "Save or delete", "After editing, press Save. To remove a record, press Delete and confirm. A delete is treated as a real data change and can conflict with another person's edit.")
    add_step(doc, "4", "Work open items", "Click Open Walk-ins to filter unresolved work. Click a row to edit it or mark it completed, then press Save.")
    add_step(doc, "5", "Review outcomes", "Return to Dashboard or Executive Summary for totals and trends. Activity History is the audit trail for actions taken in the app.")
    add_inline_lead(doc, "Good habit. ", "After a meaningful batch of changes, wait for the status to return to Linked and check Activity History before closing the browser.")

    doc.add_page_break()
    doc.add_paragraph("4  Sync and resolve conflicts", style="Heading 1")
    add_inline_lead(doc, "The sync check happens before a shared save. ", "The app rereads the latest destination data and compares three versions: the saved baseline, your local version, and the latest destination version.")
    add_picture(doc, ASSET_DIR / "sync_three_way.png", width=6.75, caption="Three-way merge illustration: independent changes can merge; overlapping changes pause the save.", alt_text="Three-way sync diagram comparing saved baseline, local version, and shared destination, leading to merge or conflict resolution.")
    add_inline_lead(doc, "Normal save. ", "If only one side changed a record or field, the app merges that change and saves the result. The baseline refreshes only after the save succeeds.")
    add_inline_lead(doc, "Conflict. ", "If both sides changed the same record or field, or one side deleted while the other edited, the save pauses. The status becomes Conflict and neither version is silently overwritten.")
    add_step(doc, "1", "Export Backup", "Press Export Backup and keep the downloaded JSON file before choosing a resolution.")
    add_step(doc, "2", "Review the conflict", "Compare the local and shared values. Decide which version should be retained for the affected record or field.")
    add_step(doc, "3", "Choose a resolution", "Press Keep Local to replace the shared version with your local version, or Use Shared to discard the local version and adopt the shared data.")
    add_step(doc, "4", "Confirm", "Wait for the status to return to Linked. If it stays in Conflict, refresh and review again rather than repeating a blind save.")
    add_inline_lead(doc, "Concurrency limitation. ", "A local file and browser-based sync cannot provide a transactional guarantee when two people write at exactly the same time or when cloud file synchronization is delayed. The app provides the strongest practical checks available in this file-based design; guaranteed multi-user consistency would require an approved shared backend with transactional versioning.")

    doc.add_page_break()
    doc.add_paragraph("5  Import, export, and backups", style="Heading 1")
    add_step(doc, "1", "Import", "Press Import Excel and select the workbook or compatible file. The app validates recognized columns, reports invalid rows, and skips duplicates without destroying existing records.")
    add_step(doc, "2", "Check the result", "Read the completion message and open Activity History. If columns were renamed or missing, correct the source file or add the affected data through Add Walk-In.")
    add_step(doc, "3", "Export", "Press Export Excel for a spreadsheet snapshot. Use Export Backup when you need the local records, baseline, and conflict context together.")
    add_table(doc, ["File or action", "Purpose", "When to use"], [
        ("Export Backup", "JSON backup of local records, baseline, and conflict details.", "Before conflict resolution, imports, or a large cleanup."),
        ("Export Excel", "Human-readable spreadsheet snapshot.", "Reporting, review, or sharing a point-in-time copy."),
        ("Activity History", "In-app record of changes and sync events.", "Confirm what happened after a save or import."),
        ("data/incidents.json", "Server destination for tracker records.", "Usually leave it to the app; make a backup before manual recovery."),
        ("data/audit.json", "Server-side audit entries.", "Keep with the project when moving or backing up the dashboard."),
    ], widths=[1.65, 2.75, 2.2])

    doc.add_paragraph("6  Privacy and offline behavior", style="Heading 1")
    add_bullet(doc, "The dashboard's normal server mode uses the local address http://127.0.0.1:5177/ and local project files.")
    add_bullet(doc, "There is no built-in external API, analytics service, or internet data connection in this project.")
    add_bullet(doc, "If the project folder is inside OneDrive, OneDrive can synchronize files independently of the dashboard. That cloud sync is not the same as a transactional database.")
    add_bullet(doc, "When the server is unavailable, local-only browser storage keeps work in that browser. Reconnect by starting the server and pressing Refresh data.")
    add_inline_lead(doc, "Keep backups separate. ", "Store important exported JSON or Excel backups outside the project folder when you need protection from folder-level replacement or cloud sync issues.")

    doc.add_page_break()
    doc.add_paragraph("7  Troubleshooting", style="Heading 1")
    add_table(doc, ["What you see", "What to press or check"], [
        ("The browser does not open", "Open http://127.0.0.1:5177/ manually. If needed, run Start HR Dashboard.cmd again."),
        ("Status says Local-only", "Start the server, then press Refresh data. Do not assume local-only changes are shared until the status says Linked."),
        ("Status says Conflict", "Press Export Backup, review the local and shared versions, then choose Keep Local or Use Shared."),
        ("The dashboard is blank", "Confirm the page is the dashboard at 127.0.0.1:5177, press Refresh data, and check that the data folder is present."),
        ("Import reports invalid rows", "Review required columns and date/value formats. Fix the source file and import again; existing records are retained."),
        ("Server will not start", "Close another process using port 5177, then run Start HR Dashboard.cmd again. The server log is in logs/server.err.log."),
    ], widths=[2.05, 4.55])
    doc.add_paragraph("Daily close-out checklist", style="Heading 2")
    add_bullet(doc, "Wait for Linked or a current Last synced timestamp.")
    add_bullet(doc, "Check Activity History after imports, edits, or deletes.")
    add_bullet(doc, "Export Backup before resolving a conflict or performing a major cleanup.")
    add_bullet(doc, "Close the browser only after any Saving state has finished.")
    doc.add_paragraph("Project reference", style="Heading 2")
    add_table(doc, ["Item", "Role"], [
        ("Start HR Dashboard.cmd", "One-click Windows launcher for the local server and browser."),
        ("index.html", "Launcher page that opens synced mode when the server is available and provides a local-only fallback."),
        ("README.md", "Technical setup, sync behavior, privacy notes, and developer reference."),
        ("public/", "Dashboard UI, styles, and browser logic."),
        ("server.mjs and sync-service.mjs", "Local server and file-backed persistence endpoints."),
        ("sync-utils.mjs and tests/", "Merge logic and focused sync tests."),
    ], widths=[2.45, 4.15])
    add_inline_lead(doc, "You are ready. ", "Start with Start HR Dashboard.cmd, watch the sync status, and use Export Backup before resolving any conflict.")

    doc.core_properties.title = "HR Action Item Dashboard User Guide"
    doc.core_properties.subject = "How to start, use, and sync the local HR action item dashboard"
    doc.core_properties.author = "OpenAI"
    doc.core_properties.keywords = "HR dashboard, user guide, conflict-aware sync, local dashboard"
    doc.save(DOCX_PATH)
    print(DOCX_PATH)


if __name__ == "__main__":
    build_docx()
