import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dataPath = path.join(projectDir, "data", "incidents.json");
const outputPath = path.join(projectDir, "public", "standalone-data.js");

const records = JSON.parse(await fs.readFile(dataPath, "utf8"));
const uniqueSorted = (values) => [...new Set(values.filter(Boolean).map(String))].sort((a, b) => a.localeCompare(b));
const categories = uniqueSorted(records.map((record) => record.summary));
const supervisors = uniqueSorted(records.map((record) => record.supervisor));
const hrPeople = uniqueSorted(records.map((record) => record.hrPerson));
const followUpOwners = uniqueSorted(records.map((record) => record.followUpOwner));
const dates = records.map((record) => record.date).filter(Boolean).sort();

const meta = {
  categories,
  supervisors,
  hrPeople,
  followUpOwners,
  startDate: dates[0] ?? "",
};

const output = `window.__HR_STANDALONE_DATA__ = ${JSON.stringify({ records, meta })};\n`;
await fs.writeFile(outputPath, output, "utf8");
console.log(`Wrote ${records.length} records to ${outputPath}`);
