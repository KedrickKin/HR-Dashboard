const isStandalone = window.location.protocol === "file:";
const STANDALONE_RECORDS_KEY = "hr-action-item-records-v2";
const STANDALONE_AUDIT_KEY = "hr-action-item-audit-v2";
const SYNC_BASELINE_KEY = "hr-action-item-sync-baseline-v1";
const SYNC_LAST_SYNC_KEY = "hr-action-item-sync-last-v1";
const LEGACY_STANDALONE_RECORDS_KEY = "hr-action-item-records-v1";
const LEGACY_STANDALONE_AUDIT_KEY = "hr-action-item-audit-v1";

if (isStandalone) {
  try {
    localStorage.removeItem(LEGACY_STANDALONE_RECORDS_KEY);
    localStorage.removeItem(LEGACY_STANDALONE_AUDIT_KEY);
  } catch {
    // Browser storage may be unavailable in restricted file contexts.
  }
}
const SAVED_VIEWS_KEY = "hr-action-item-views-v1";

const state = {
  records: [],
  meta: { categories: [], supervisors: [], hrPeople: [], startDate: "2025-01-09" },
  audit: [],
  savedViews: [],
  reportingDays: 90,
  sync: {
    status: "loading",
    detail: "",
    baselineRecords: null,
    destinationRecords: null,
    conflicts: [],
    lastSyncedAt: readLocalJson(SYNC_LAST_SYNC_KEY, null),
    queue: Promise.resolve(),
  },
  lastSearch: "",
  searchFilters: {
    query: "",
    employeeId: "",
    supervisor: "",
    category: "",
    status: "",
    ageBucket: "",
    followUp: "",
    dateFrom: "",
    dateTo: "",
  },
  openFilters: {
    query: "",
    employeeId: "",
    supervisor: "",
    category: "",
    ageBucket: "",
    followUp: "",
    dateFrom: "",
    dateTo: "",
  },
  editingIds: new Set(),
  searchRecords: [],
  searchRenderFrame: 0,
  openRecords: [],
  openRenderFrame: 0,
};

const els = {
  statusLine: document.querySelector("#statusLine"),
  refreshButton: document.querySelector("#refreshButton"),
  backupButton: document.querySelector("#backupButton"),
  keepLocalButton: document.querySelector("#keepLocalButton"),
  useDestinationButton: document.querySelector("#useDestinationButton"),
  importButton: document.querySelector("#importButton"),
  importInput: document.querySelector("#importInput"),
  exportButton: document.querySelector("#exportButton"),
  reportingWindow: document.querySelector("#reportingWindow"),
  executiveWindowText: document.querySelector("#executiveWindowText"),
  executiveTrendNote: document.querySelector("#executiveTrendNote"),
  executiveTrend: document.querySelector("#executiveTrend"),
  executiveReadout: document.querySelector("#executiveReadout"),
  executiveOpenCategories: document.querySelector("#executiveOpenCategories"),
  executiveWeekRows: document.querySelector("#executiveWeekRows"),
  execTotal: document.querySelector("#execTotal"),
  execOpen: document.querySelector("#execOpen"),
  execClosed: document.querySelector("#execClosed"),
  execRate: document.querySelector("#execRate"),
  execOpenBar: document.querySelector("#execOpenBar"),
  execClosedBar: document.querySelector("#execClosedBar"),
  execOpenShare: document.querySelector("#execOpenShare"),
  execClosedShare: document.querySelector("#execClosedShare"),
  reminderSummary: document.querySelector("#reminderSummary"),
  reminderRows: document.querySelector("#reminderRows"),
  qualitySummary: document.querySelector("#qualitySummary"),
  qualityList: document.querySelector("#qualityList"),
  addForm: document.querySelector("#addForm"),
  addDate: document.querySelector("#addDate"),
  addSummary: document.querySelector("#addSummary"),
  searchForm: document.querySelector("#searchForm"),
  searchInput: document.querySelector("#searchInput"),
  searchEmployeeId: document.querySelector("#searchEmployeeId"),
  searchSupervisorFilter: document.querySelector("#searchSupervisorFilter"),
  searchCategoryFilter: document.querySelector("#searchCategoryFilter"),
  searchStatusFilter: document.querySelector("#searchStatusFilter"),
  searchAgeFilter: document.querySelector("#searchAgeFilter"),
  searchFollowUpFilter: document.querySelector("#searchFollowUpFilter"),
  searchDateFrom: document.querySelector("#searchDateFrom"),
  searchDateTo: document.querySelector("#searchDateTo"),
  clearSearchFilters: document.querySelector("#clearSearchFilters"),
  savedViewSelect: document.querySelector("#savedViewSelect"),
  newViewName: document.querySelector("#newViewName"),
  saveViewButton: document.querySelector("#saveViewButton"),
  deleteViewButton: document.querySelector("#deleteViewButton"),
  searchSummary: document.querySelector("#searchSummary"),
  searchResults: document.querySelector("#searchResults"),
  editWrap: document.querySelector("#searchTab .edit-wrap"),
  openFilterForm: document.querySelector("#openFilterForm"),
  openSearchInput: document.querySelector("#openSearchInput"),
  openEmployeeId: document.querySelector("#openEmployeeId"),
  openSupervisorFilter: document.querySelector("#openSupervisorFilter"),
  openCategoryFilter: document.querySelector("#openCategoryFilter"),
  openAgeFilter: document.querySelector("#openAgeFilter"),
  openFollowUpFilter: document.querySelector("#openFollowUpFilter"),
  openDateFrom: document.querySelector("#openDateFrom"),
  openDateTo: document.querySelector("#openDateTo"),
  clearOpenFilters: document.querySelector("#clearOpenFilters"),
  openSummary: document.querySelector("#openSummary"),
  openResults: document.querySelector("#openResults"),
  openWrap: document.querySelector("#openTab .open-wrap"),
  historySummary: document.querySelector("#historySummary"),
  historyRows: document.querySelector("#historyRows"),
  categoryTable: document.querySelector("#categoryTable"),
  supervisorTable: document.querySelector("#supervisorTable"),
  supervisorList: document.querySelector("#supervisorList"),
  hrPersonList: document.querySelector("#hrPersonList"),
  followUpOwnerList: document.querySelector("#followUpOwnerList"),
  toast: document.querySelector("#toast"),
};

const SEARCH_ROW_HEIGHT = 54;
const SEARCH_OVERSCAN_ROWS = 12;
const SEARCH_MIN_RENDERED_ROWS = 45;
const RECENT_KPI_DAYS = 90;
const AGE_BUCKETS = [
  { value: "0-30", label: "0-30 days" },
  { value: "31-60", label: "31-60 days" },
  { value: "61-90", label: "61-90 days" },
  { value: "90+", label: "90+ days" },
];
const REPORTING_WINDOWS = [30, 60, 90, 180, 365];

function normalizeReportingDays(value) {
  const days = Number(value);
  return Number.isFinite(days) ? Math.min(365, Math.max(30, Math.round(days))) : 90;
}

const chartColors = {
  blue: "#1f6f91",
  orange: "#e76f38",
  green: "#2f855a",
  red: "#b83232",
  grid: "#d9e2ec",
  ink: "#1f2933",
  muted: "#607080",
};

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function formatNumber(value, digits = 0) {
  return Number(value || 0).toLocaleString(undefined, {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

function formatPercent(value) {
  return `${formatNumber((value || 0) * 100, 1)}%`;
}

function formatSigned(value) {
  const number = Number(value || 0);
  return number > 0 ? `+${formatNumber(number)}` : formatNumber(number);
}

function todayIso() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseLocalDate(value) {
  const text = String(value ?? "").trim();
  let parts = null;
  if (/^\d+(?:\.\d+)?$/.test(text)) {
    const serial = Number(text);
    if (Number.isFinite(serial) && serial >= 1 && serial <= 100000) {
      const date = new Date(1899, 11, 30);
      date.setDate(date.getDate() + Math.floor(serial));
      parts = [date.getFullYear(), date.getMonth() + 1, date.getDate()];
    }
  }
  const compactMatch = text.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (!parts && compactMatch) parts = compactMatch.slice(1).map(Number);
  const isoMatch = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (!parts && isoMatch) parts = isoMatch.slice(1).map(Number);
  const yearFirstMatch = text.match(/^(\d{4})[\/\.\-](\d{1,2})[\/\.\-](\d{1,2})(?:\s|$)/);
  if (!parts && yearFirstMatch) parts = yearFirstMatch.slice(1).map(Number);
  const numericMatch = text.match(/^(\d{1,4})[\/\.\-](\d{1,2})[\/\.\-](\d{2}|\d{4})(?:\s|$)/);
  if (!parts && numericMatch) {
    const first = Number(numericMatch[1]);
    const second = Number(numericMatch[2]);
    const year = Number(numericMatch[3]) < 100 ? 2000 + Number(numericMatch[3]) : Number(numericMatch[3]);
    parts = [year, first > 12 ? second : first, first > 12 ? first : second];
  }
  if (!parts) {
    const parsedText = new Date(text);
    if (!Number.isNaN(parsedText.getTime())) parts = [parsedText.getFullYear(), parsedText.getMonth() + 1, parsedText.getDate()];
  }
  if (!parts) return null;
  const [year, month, day] = parts;
  if (!year || !month || !day) return null;
  const date = new Date(year, month - 1, day);
  if (Number.isNaN(date.getTime())) return null;
  return date.getFullYear() === year && date.getMonth() + 1 === month && date.getDate() === day ? date : null;
}

function normalizeDateValue(value) {
  const date = parseLocalDate(value);
  if (!date) return "";
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function ageDays(record) {
  const date = parseLocalDate(record.date);
  if (!date) return 0;
  const today = parseLocalDate(todayIso());
  return Math.max(0, Math.floor((today - date) / 86400000));
}

function ageBucket(record) {
  const age = ageDays(record);
  if (age <= 30) return "0-30";
  if (age <= 60) return "31-60";
  if (age <= 90) return "61-90";
  return "90+";
}

function followUpStatus(record) {
  if (!record.followUpDueDate) return "none";
  if (record.completed === "X") return "completed";
  const dueDate = parseLocalDate(record.followUpDueDate);
  const today = parseLocalDate(todayIso());
  if (!dueDate || !today) return "none";
  if (dueDate < today) return "overdue";
  if (dueDate.getTime() === today.getTime()) return "due";
  return "scheduled";
}

function matchesFollowUpFilter(record, filter) {
  if (!filter) return true;
  const status = followUpStatus(record);
  if (filter === "due") return status === "due" || status === "overdue";
  return status === filter;
}

const FALLBACK_CATEGORIES = [
  "info request",
  "day force related",
  "benefit questions",
  "policy clarifications",
  "performance management",
  "health and safety incidents",
  "employee referrals",
  "employee grievances",
  "supplies/merchandise",
  "UKG related",
  "W-2 request",
  "food pantry",
  "escalation",
  "case management",
];

function categoryKey(value) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function canonicalCategory(value) {
  const key = categoryKey(value);
  const configured = [...new Set([...FALLBACK_CATEGORIES, ...(state.meta.categories ?? [])])];
  return configured.find((category) => categoryKey(category) === key) ?? String(value ?? "").trim();
}

function readLocalJson(key, fallback) {
  try {
    const parsed = JSON.parse(localStorage.getItem(key) || "null");
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}

function writeLocalJson(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    toast("Browser storage is unavailable. Changes will not persist after this tab closes.");
  }
}

const SYNC_FIELDS = [
  "date",
  "employeeName",
  "batchNumber",
  "supervisor",
  "hrPerson",
  "followUpOwner",
  "followUpDueDate",
  "information",
  "summary",
  "completed",
];

function cloneRecords(records) {
  return JSON.parse(JSON.stringify(records ?? []));
}

function persistedRecords(records) {
  return (records ?? []).map((record) => {
    const { rowNumber, week, ...stored } = normalizeClientRecord(record);
    return stored;
  });
}

function syncComparableRecord(record) {
  if (!record) return null;
  return {
    id: String(record.id ?? ""),
    ...Object.fromEntries(SYNC_FIELDS.map((field) => [field, String(record[field] ?? "")])),
  };
}

function syncRecordsMatch(first, second) {
  const normalize = (records) => (records ?? []).map(syncComparableRecord)
    .sort((left, right) => left.id.localeCompare(right.id));
  return JSON.stringify(normalize(first)) === JSON.stringify(normalize(second));
}

function readSavedRecords() {
  const stored = readLocalJson(STANDALONE_RECORDS_KEY, null);
  return Array.isArray(stored) ? stored.map(normalizeClientRecord) : null;
}

function readSavedBaseline() {
  const stored = readLocalJson(SYNC_BASELINE_KEY, null);
  return Array.isArray(stored) ? stored.map(normalizeClientRecord) : null;
}

function persistLocalRecords(records) {
  const normalized = persistedRecords(records).map(normalizeClientRecord);
  writeLocalJson(STANDALONE_RECORDS_KEY, persistedRecords(normalized));
  return normalized;
}

function persistSyncBaseline(records) {
  const normalized = records == null ? null : persistedRecords(records);
  writeLocalJson(SYNC_BASELINE_KEY, normalized);
  state.sync.baselineRecords = normalized?.map(normalizeClientRecord) ?? null;
}

function formatLastSynced(value) {
  if (!value) return "";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "" : `Last synced ${date.toLocaleString()}`;
}

function updateSyncUi() {
  if (!els.statusLine) return;
  const labels = {
    loading: "Loading sync state",
    linked: "Linked",
    saving: "Saving",
    "local-only": "Local-only",
    error: "Sync error",
    conflict: "Conflict",
  };
  const label = labels[state.sync.status] || state.sync.status;
  const lastSynced = formatLastSynced(state.sync.lastSyncedAt);
  const details = state.sync.detail ? `: ${state.sync.detail}` : "";
  els.statusLine.textContent = `${formatNumber(state.records.length)} tracker rows loaded • ${label}${lastSynced ? ` • ${lastSynced}` : ""}${details}`;
  if (els.keepLocalButton) els.keepLocalButton.hidden = state.sync.status !== "conflict";
  if (els.useDestinationButton) els.useDestinationButton.hidden = state.sync.status !== "conflict";
}

function setSyncStatus(status, detail = "") {
  state.sync.status = status;
  state.sync.detail = detail;
  updateSyncUi();
}

function nextLocalRecordId(records) {
  const negativeIds = (records ?? [])
    .map((record) => Number(record.id))
    .filter((id) => Number.isFinite(id) && id < 0);
  return negativeIds.length ? Math.min(...negativeIds) - 1 : -1;
}

function localRecordValidation(payload, existing = {}) {
  return standaloneRecordValidation(payload, existing);
}

function rememberSuccessfulSync(records) {
  const normalized = persistLocalRecords(records);
  persistSyncBaseline(normalized);
  state.sync.destinationRecords = null;
  state.sync.conflicts = [];
  state.sync.lastSyncedAt = new Date().toISOString();
  writeLocalJson(SYNC_LAST_SYNC_KEY, state.sync.lastSyncedAt);
  setSyncStatus("linked");
  return normalized;
}

function saveLocalSnapshot(records) {
  state.records = persistLocalRecords(records);
  renderMeta();
  renderDashboard();
  renderExecutiveSummary();
  renderHistory();
  if (isSearchTabActive()) renderSearchGrid();
  if (isOpenTabActive()) renderOpenGrid();
  return state.records;
}

async function syncSnapshotToServer(snapshot, resolution = "") {
  const normalizedSnapshot = persistedRecords(snapshot).map(normalizeClientRecord);
  saveLocalSnapshot(normalizedSnapshot);

  if (isStandalone) {
    setSyncStatus("local-only", "Saved in this browser");
    return { ok: true, records: normalizedSnapshot, written: true };
  }

  const operation = state.sync.queue.catch(() => {}).then(async () => {
    setSyncStatus("saving");
    try {
      const result = await fetchJson("/api/sync", {
        method: "POST",
        body: JSON.stringify({
          baselineRecords: state.sync.baselineRecords == null ? null : persistedRecords(state.sync.baselineRecords),
          localRecords: persistedRecords(normalizedSnapshot),
          resolution,
        }),
      });
      const saved = result.records.map(normalizeClientRecord);
      state.records = rememberSuccessfulSync(saved);
      renderMeta();
      renderDashboard();
      renderExecutiveSummary();
      renderHistory();
      if (isSearchTabActive()) renderSearchGrid();
      if (isOpenTabActive()) renderOpenGrid();
      return { ...result, ok: true, records: state.records };
    } catch (error) {
      const conflictPayload = error.payload?.destinationRecords;
      if (error.status === 409 && Array.isArray(conflictPayload)) {
        state.sync.destinationRecords = conflictPayload.map(normalizeClientRecord);
        state.sync.conflicts = error.payload.conflicts ?? [];
        persistLocalRecords(normalizedSnapshot);
        setSyncStatus("conflict", `${state.sync.conflicts.length} change${state.sync.conflicts.length === 1 ? "" : "s"} needs a decision`);
        return { ok: false, conflict: true, error };
      }

      persistLocalRecords(normalizedSnapshot);
      setSyncStatus(isStandalone ? "local-only" : "local-only", "Shared destination unavailable; browser changes are saved locally");
      return { ok: false, unavailable: true, error };
    }
  });
  state.sync.queue = operation.then(() => undefined, () => undefined);
  return operation;
}

async function resolveSyncConflict(resolution) {
  if (!state.sync.destinationRecords?.length && state.sync.destinationRecords?.length !== 0) {
    toast("The latest shared version is unavailable. Refresh and try again.");
    return;
  }
  const backupConfirmed = window.confirm(
    "Before resolving this conflict, export a local backup if you need to preserve both versions. Continue?"
  );
  if (!backupConfirmed) return;

  if (resolution === "destination") {
    state.records = persistLocalRecords(state.sync.destinationRecords);
    persistSyncBaseline(state.sync.destinationRecords);
    state.sync.destinationRecords = null;
    state.sync.conflicts = [];
    setSyncStatus("linked", "Using the shared version");
    renderMeta();
    renderDashboard();
    renderExecutiveSummary();
    renderHistory();
    if (isSearchTabActive()) renderSearchGrid();
    if (isOpenTabActive()) renderOpenGrid();
    toast("Local records replaced with the shared version.");
    return;
  }

  const result = await syncSnapshotToServer(state.records, "local");
  if (result.ok) toast("Local changes were saved after conflict resolution.");
}

function exportLocalBackup() {
  const payload = {
    exportedAt: new Date().toISOString(),
    records: persistedRecords(state.records),
    baselineRecords: state.sync.baselineRecords ? persistedRecords(state.sync.baselineRecords) : null,
    conflicts: state.sync.conflicts,
  };
  downloadBlob(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }), "hr-action-item-local-backup.json");
  toast("Local backup exported.");
}

function normalizeClientRecord(raw, index = 0) {
  return {
    id: Number.isFinite(Number(raw.id)) ? Number(raw.id) : index + 1,
    rowNumber: index + 2,
    week: Number(raw.week) || weekFromDate(raw.date),
    date: normalizeDateValue(raw.date),
    employeeName: String(raw.employeeName ?? "").trim(),
    batchNumber: String(raw.batchNumber ?? "").trim(),
    supervisor: String(raw.supervisor ?? "").trim(),
    hrPerson: String(raw.hrPerson ?? "").trim(),
    followUpOwner: String(raw.followUpOwner ?? "").trim(),
    followUpDueDate: normalizeDateValue(raw.followUpDueDate),
    information: String(raw.information ?? "").trim(),
    summary: canonicalCategory(raw.summary),
    completed: String(raw.completed ?? "").trim().toUpperCase() === "X" ? "X" : "",
  };
}

function weekFromDate(value) {
  const date = parseLocalDate(value);
  const start = parseLocalDate("2025-01-09");
  if (!date || !start) return 0;
  return Math.max(1, Math.floor((date - start) / 604800000) + 1);
}

function standaloneRecords() {
  const embedded = window.__HR_STANDALONE_DATA__?.records;
  const stored = readLocalJson(STANDALONE_RECORDS_KEY, null);
  const source = Array.isArray(stored) ? stored : Array.isArray(embedded) ? embedded : [];
  return source.map(normalizeClientRecord);
}

function standaloneMeta(records) {
  const embeddedMeta = window.__HR_STANDALONE_DATA__?.meta ?? {};
  const supervisors = [...new Set(records.map((record) => record.supervisor).filter(Boolean))].sort();
  const hrPeople = [...new Set([...(embeddedMeta.hrPeople ?? []), ...records.map((record) => record.hrPerson).filter(Boolean)])].sort();
  const followUpOwners = [...new Set([
    ...supervisors,
    ...hrPeople,
    ...records.map((record) => record.followUpOwner).filter(Boolean),
  ])].sort();
  return {
    categories: embeddedMeta.categories?.length ? embeddedMeta.categories : FALLBACK_CATEGORIES,
    supervisors,
    hrPeople,
    followUpOwners,
    startDate: "2025-01-09",
  };
}

function standaloneAudit() {
  return readLocalJson(STANDALONE_AUDIT_KEY, []);
}

function incidentFingerprint(record) {
  return [record.date, record.employeeName, record.batchNumber, record.supervisor, record.summary, record.information]
    .map((value) => String(value ?? "").trim().toLowerCase())
    .join("|");
}

function persistStandaloneRecords(records) {
  const normalized = records.map(normalizeClientRecord);
  writeLocalJson(STANDALONE_RECORDS_KEY, normalized.map(({ rowNumber, week, ...record }) => record));
  if (window.__HR_STANDALONE_DATA__) window.__HR_STANDALONE_DATA__.records = normalized;
  return normalized;
}

function persistStandaloneAudit(entry) {
  const entries = [
    ...standaloneAudit(),
    { timestamp: new Date().toISOString(), actor: "Local user", ...entry },
  ].slice(-500);
  writeLocalJson(STANDALONE_AUDIT_KEY, entries);
  state.audit = entries;
}

function standaloneRecordValidation(payload, existing = {}) {
  const merged = normalizeClientRecord({ ...existing, ...payload });
  if (!merged.employeeName) throw new Error("Employee name is required.");
  if (!parseLocalDate(merged.date)) throw new Error("A valid date is required.");
  if (!state.meta.categories.includes(merged.summary)) throw new Error("Summary must be one of the configured categories.");
  if (merged.followUpDueDate && !parseLocalDate(merged.followUpDueDate)) {
    throw new Error("Follow-up due date must be a valid date.");
  }
  return merged;
}

function decodeStandaloneFile(contentBase64) {
  const binary = atob(String(contentBase64 ?? ""));
  const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

function parseStandaloneCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (quoted) {
      if (character === '"' && text[index + 1] === '"') {
        field += '"';
        index += 1;
      } else if (character === '"') {
        quoted = false;
      } else {
        field += character;
      }
    } else if (character === '"') {
      quoted = true;
    } else if (character === ",") {
      row.push(field);
      field = "";
    } else if (character === "\n") {
      row.push(field.replace(/\r$/, ""));
      if (row.some((value) => value.trim())) rows.push(row);
      row = [];
      field = "";
    } else {
      field += character;
    }
  }
  row.push(field.replace(/\r$/, ""));
  if (row.some((value) => value.trim())) rows.push(row);
  return rows;
}

function standaloneImportRecords(filename, contentBase64) {
  const extension = String(filename).toLowerCase().split(".").pop();
  if (extension === "xlsx" || extension === "xls") {
    throw new Error("Direct HTML mode supports CSV or JSON import. Use the running dashboard for formatted Excel import.");
  }
  const text = decodeStandaloneFile(contentBase64);
  if (extension === "json") {
    const parsed = JSON.parse(text);
    const records = Array.isArray(parsed) ? parsed : parsed.records;
    return Array.isArray(records) ? records : [];
  }
  const rows = parseStandaloneCsv(text);
  if (!rows.length) return [];
  const headers = rows[0].map((header) => String(header).trim().toLowerCase().replace(/[^a-z0-9]+/g, " ").trim());
  const indexOf = (aliases) => headers.findIndex((header) => aliases.includes(header));
  const columns = {
    date: indexOf(["date"]),
    employeeName: indexOf(["employee name", "employee"]),
    batchNumber: indexOf(["employee id", "batch number"]),
    supervisor: indexOf(["supervisor"]),
    hrPerson: indexOf(["hr person"]),
    followUpOwner: indexOf(["follow up owner"]),
    followUpDueDate: indexOf(["follow up due", "follow up due date"]),
    information: indexOf(["information"]),
    summary: indexOf(["summary", "category"]),
    completed: indexOf(["completed", "done"]),
  };
  return rows.slice(1).map((row) => Object.fromEntries(Object.entries(columns).map(([key, index]) => [key, index >= 0 ? row[index] : ""])))
    .filter((record) => Object.values(record).some((value) => String(value ?? "").trim()));
}

async function fetchStandaloneJson(url, options = {}) {
  const method = String(options.method ?? "GET").toUpperCase();
  let payload = {};
  if (options.body) payload = typeof options.body === "string" ? JSON.parse(options.body) : options.body;
  const records = standaloneRecords();
  if (url === "/api/meta" && method === "GET") return standaloneMeta(records);
  if (url === "/api/audit" && method === "GET") return { entries: standaloneAudit().slice().reverse() };
  if (url === "/api/incidents" && method === "GET") {
    const query = String(new URLSearchParams(options.query ?? {}).get("employeeName") ?? "").toLowerCase();
    const filtered = query ? records.filter((record) => record.employeeName.toLowerCase().includes(query)) : records;
    return { records: filtered, total: records.length };
  }
  if (url === "/api/incidents" && method === "POST") {
    const nextId = records.reduce((max, record) => Math.max(max, Number(record.id) || 0), 0) + 1;
    const record = standaloneRecordValidation({ ...payload, id: nextId });
    records.push(record);
    const saved = persistStandaloneRecords(records);
    persistStandaloneAudit({ action: "created", recordId: record.id, employeeName: record.employeeName, details: "New walk-in added." });
    return { record: saved[saved.length - 1], total: saved.length };
  }
  const updateMatch = url.match(/^\/api\/incidents\/(\d+)$/);
  if (updateMatch && method === "PUT") {
    const id = Number(updateMatch[1]);
    const index = records.findIndex((record) => Number(record.id) === id);
    if (index === -1) throw new Error("Incident not found.");
    const updated = standaloneRecordValidation({ ...records[index], ...payload, id }, records[index]);
    const saved = persistStandaloneRecords(records.map((record, recordIndex) => recordIndex === index ? updated : record));
    persistStandaloneAudit({ action: "updated", recordId: id, employeeName: updated.employeeName, details: "Record updated." });
    return { record: saved[index], total: saved.length };
  }
  if (updateMatch && method === "DELETE") {
    const id = Number(updateMatch[1]);
    const index = records.findIndex((record) => Number(record.id) === id);
    if (index === -1) throw new Error("Incident not found.");
    const [deleted] = records.splice(index, 1);
    const saved = persistStandaloneRecords(records);
    persistStandaloneAudit({ action: "deleted", recordId: deleted.id, employeeName: deleted.employeeName, details: "Walk-in deleted after confirmation." });
    return { record: deleted, total: saved.length };
  }
  if (url === "/api/import" && method === "POST") {
    const imported = standaloneImportRecords(payload.filename, payload.contentBase64);
    const existingKeys = new Set(records.map(incidentFingerprint));
    let nextId = records.reduce((max, record) => Math.max(max, Number(record.id) || 0), 0) + 1;
    let duplicates = 0;
    let added = 0;
    const invalid = [];
    for (const [index, candidate] of imported.entries()) {
      try {
        const normalized = standaloneRecordValidation({ ...candidate, id: nextId });
        const fingerprint = incidentFingerprint(normalized);
        if (existingKeys.has(fingerprint)) {
          duplicates += 1;
          continue;
        }
        existingKeys.add(fingerprint);
        records.push(normalized);
        nextId += 1;
        added += 1;
      } catch (error) {
        invalid.push({ row: index + 2, reason: error.message });
      }
    }
    const saved = persistStandaloneRecords(records);
    persistStandaloneAudit({ action: "imported", employeeName: `${added} records from ${payload.filename || "import"}`, details: `${duplicates} duplicates skipped; ${invalid.length} invalid rows skipped.` });
    return { added, duplicates, invalid, total: saved.length };
  }
  throw new Error("This feature requires the running dashboard server.");
}

function isRecentRecord(record, days = state.reportingDays || RECENT_KPI_DAYS) {
  const date = parseLocalDate(record.date);
  const today = parseLocalDate(todayIso());
  if (!date || !today) return false;
  const cutoff = new Date(today);
  cutoff.setDate(cutoff.getDate() - days);
  return date >= cutoff && date <= today;
}

async function fetchJson(url, options = {}) {
  if (isStandalone) return fetchStandaloneJson(url, options);
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const payload = await response.json();
  if (!response.ok) {
    const error = new Error(payload.error || "Request failed.");
    error.status = response.status;
    error.payload = payload;
    throw error;
  }
  return payload;
}

function toast(message) {
  els.toast.textContent = message;
  els.toast.classList.add("show");
  window.clearTimeout(toast.timer);
  toast.timer = window.setTimeout(() => els.toast.classList.remove("show"), 2600);
}

function setBusy(button, busy, label) {
  button.disabled = busy;
  if (busy && label) {
    button.dataset.idleText ||= button.textContent;
    button.textContent = label;
  }
  if (!busy && button.dataset.idleText) {
    button.textContent = button.dataset.idleText;
  }
}

function categoryOptions(selected = "") {
  return state.meta.categories
    .map((category) => {
      const isSelected = category === selected ? " selected" : "";
      return `<option value="${escapeHtml(category)}"${isSelected}>${escapeHtml(category)}</option>`;
    })
    .join("");
}

function filterOptions(values, placeholder, selected = "") {
  return [
    `<option value="">${escapeHtml(placeholder)}</option>`,
    ...values.map((value) => {
      const isSelected = value === selected ? " selected" : "";
      return `<option value="${escapeHtml(value)}"${isSelected}>${escapeHtml(value)}</option>`;
    }),
  ].join("");
}

function ageFilterOptions(selected = "") {
  return [
    `<option value="">All age buckets</option>`,
    ...AGE_BUCKETS.map((bucket) => {
      const isSelected = bucket.value === selected ? " selected" : "";
      return `<option value="${bucket.value}"${isSelected}>${bucket.label}</option>`;
    }),
  ].join("");
}

function followUpFilterOptions(selected = "") {
  const options = [
    ["", "All follow-ups"],
    ["due", "Due or overdue"],
    ["scheduled", "Scheduled"],
    ["none", "No due date"],
  ];
  return options
    .map(([value, label]) => `<option value="${value}"${value === selected ? " selected" : ""}>${label}</option>`)
    .join("");
}

function bindTabs() {
  document.querySelectorAll(".tab").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((tab) => tab.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach((panel) => panel.classList.remove("active"));
      button.classList.add("active");
      document.querySelector(`#${button.dataset.tab}Tab`).classList.add("active");
      if (button.dataset.tab === "search") {
        renderSearchGrid();
      }
      if (button.dataset.tab === "open") {
        renderOpenGrid();
      }
      if (button.dataset.tab === "executive") {
        renderExecutiveSummary();
      }
    });
  });
}

function isSearchTabActive() {
  return document.querySelector("#searchTab")?.classList.contains("active");
}

function isOpenTabActive() {
  return document.querySelector("#openTab")?.classList.contains("active");
}

function renderAllData() {
  renderMeta();
  renderSavedViews();
  renderDashboard();
  renderExecutiveSummary();
  renderHistory();
  if (isSearchTabActive()) renderSearchGrid();
  if (isOpenTabActive()) renderOpenGrid();
}

async function loadData() {
  setSyncStatus("loading");
  try {
    const [meta, incidents, audit] = await Promise.all([
      fetchJson("/api/meta"),
      fetchJson("/api/incidents"),
      fetchJson("/api/audit"),
    ]);
    state.meta = meta;
    state.audit = audit.entries ?? [];
    state.savedViews = readLocalJson(SAVED_VIEWS_KEY, []);
    state.reportingDays = normalizeReportingDays(readLocalJson("hr-action-item-reporting-days", 90));
    els.reportingWindow.value = String(state.reportingDays);

    const destinationRecords = incidents.records.map(normalizeClientRecord);
    if (isStandalone) {
      state.records = destinationRecords;
      setSyncStatus("local-only", "Saved in this browser");
    } else {
      const savedRecords = readSavedRecords();
      const savedBaseline = readSavedBaseline();
      state.sync.baselineRecords = savedBaseline;
      if (!savedRecords) {
        state.records = persistLocalRecords(destinationRecords);
        persistSyncBaseline(destinationRecords);
        setSyncStatus("linked");
      } else if (!savedBaseline) {
        state.records = savedRecords;
        if (syncRecordsMatch(savedRecords, destinationRecords)) {
          persistSyncBaseline(destinationRecords);
          setSyncStatus("linked");
        } else {
          state.sync.destinationRecords = destinationRecords;
          state.sync.conflicts = [{ id: "__baseline__", kind: "missing-baseline", fields: [] }];
          setSyncStatus("conflict", "Saved baseline is missing; export a backup before choosing a version");
        }
      } else {
        state.records = savedRecords;
        await syncSnapshotToServer(savedRecords);
      }
    }
    renderAllData();
  } catch (error) {
    if (isStandalone) throw error;
    const savedRecords = readSavedRecords() ?? [];
    state.records = savedRecords;
    state.meta = standaloneMeta(savedRecords);
    state.audit = standaloneAudit().slice().reverse();
    setSyncStatus("local-only", "Shared destination unavailable; browser changes are saved locally");
    renderAllData();
  }
}

function renderMeta() {
  els.addSummary.innerHTML = `<option value="">Select a category</option>${categoryOptions()}`;
  els.supervisorList.innerHTML = state.meta.supervisors
    .map((supervisor) => `<option value="${escapeHtml(supervisor)}"></option>`)
    .join("");
  els.hrPersonList.innerHTML = state.meta.hrPeople
    .map((hrPerson) => `<option value="${escapeHtml(hrPerson)}"></option>`)
    .join("");
  const followUpOwners = state.meta.followUpOwners ?? [
    ...new Set([...state.meta.supervisors, ...state.meta.hrPeople]),
  ].sort();
  els.followUpOwnerList.innerHTML = followUpOwners
    .map((owner) => `<option value="${escapeHtml(owner)}"></option>`)
    .join("");
  els.searchSupervisorFilter.innerHTML = filterOptions(state.meta.supervisors, "All supervisors", state.searchFilters.supervisor);
  els.searchCategoryFilter.innerHTML = filterOptions(state.meta.categories, "All categories", state.searchFilters.category);
  els.searchAgeFilter.innerHTML = ageFilterOptions(state.searchFilters.ageBucket);
  els.searchFollowUpFilter.innerHTML = followUpFilterOptions(state.searchFilters.followUp);
  els.openSupervisorFilter.innerHTML = filterOptions(state.meta.supervisors, "All supervisors", state.openFilters.supervisor);
  els.openCategoryFilter.innerHTML = filterOptions(state.meta.categories, "All categories", state.openFilters.category);
  els.openAgeFilter.innerHTML = ageFilterOptions(state.openFilters.ageBucket);
  els.openFollowUpFilter.innerHTML = followUpFilterOptions(state.openFilters.followUp);
  els.searchStatusFilter.value = state.searchFilters.status;
  document.querySelector("#loadedRows").textContent = formatNumber(state.records.length);
  document.querySelector("#nextRow").textContent = formatNumber(state.records.length + 2);
  updateSyncUi();
}

function getDashboardData() {
  const total = state.records.length;
  const completed = state.records.filter((record) => record.completed === "X").length;
  const open = total - completed;
  const recentRecords = state.records.filter((record) => isRecentRecord(record));
  const recentCompleted = recentRecords.filter((record) => record.completed === "X").length;
  const weeks = new Map();
  const recentWeeks = new Map();
  const categories = new Map();
  const supervisors = new Map();
  let oldestOpen = 0;
  let agedOpen = 0;

  for (const category of state.meta.categories) {
    categories.set(category, { category, total: 0, completed: 0, open: 0 });
  }

  for (const record of state.records) {
    const week = Number(record.week) || 0;
    if (!weeks.has(week)) {
      weeks.set(week, { week, total: 0, completed: 0, open: 0 });
    }
    const weekRow = weeks.get(week);
    weekRow.total += 1;
    if (record.completed === "X") weekRow.completed += 1;
    else weekRow.open += 1;

    if (isRecentRecord(record)) {
      if (!recentWeeks.has(week)) {
        recentWeeks.set(week, { week, total: 0, completed: 0, open: 0 });
      }
      const recentWeekRow = recentWeeks.get(week);
      recentWeekRow.total += 1;
      if (record.completed === "X") recentWeekRow.completed += 1;
      else recentWeekRow.open += 1;
    }

    if (!categories.has(record.summary)) {
      categories.set(record.summary, { category: record.summary || "(blank)", total: 0, completed: 0, open: 0 });
    }
    const categoryRow = categories.get(record.summary);
    categoryRow.total += 1;
    if (record.completed === "X") categoryRow.completed += 1;
    else categoryRow.open += 1;

    if (record.supervisor) {
      if (!supervisors.has(record.supervisor)) {
        supervisors.set(record.supervisor, { supervisor: record.supervisor, total: 0, completed: 0, open: 0 });
      }
      const supervisorRow = supervisors.get(record.supervisor);
      supervisorRow.total += 1;
      if (record.completed === "X") supervisorRow.completed += 1;
      else supervisorRow.open += 1;
    }

    if (record.completed !== "X") {
      const age = ageDays(record);
      oldestOpen = Math.max(oldestOpen, age);
      if (age > 30) agedOpen += 1;
    }
  }

  const weekly = Array.from(weeks.values()).sort((a, b) => a.week - b.week);
  const recentWeekly = Array.from(recentWeeks.values()).sort((a, b) => a.week - b.week);
  const latestWeek = weekly.length ? weekly[weekly.length - 1].week : 0;
  const latest = weeks.get(latestWeek)?.total ?? 0;
  const latestRecentWeek = recentWeekly.length ? recentWeekly[recentWeekly.length - 1].week : 0;
  const latestRecent = recentWeeks.get(latestRecentWeek)?.total ?? 0;
  const priorRecent = recentWeeks.get(latestRecentWeek - 1)?.total ?? 0;
  const change = priorRecent ? (latestRecent - priorRecent) / priorRecent : 0;
  const peak = weekly.reduce((best, row) => (row.total > best.total ? row : best), { week: 0, total: 0 });
  const activeWeeks = weekly.filter((row) => row.total > 0).length;
  const categoryRows = Array.from(categories.values()).filter((row) => row.category);
  const topCategory = categoryRows.reduce((best, row) => (row.total > best.total ? row : best), {
    category: "-",
    total: 0,
  });
  const supervisorRows = Array.from(supervisors.values())
    .sort((a, b) => b.total - a.total || a.supervisor.localeCompare(b.supervisor))
    .slice(0, 10);
  const last12 = [];
  for (let week = Math.max(1, latestWeek - 11); week <= latestWeek; week += 1) {
    last12.push(weeks.get(week) ?? { week, total: 0, completed: 0, open: 0 });
  }
  const openAge = [
    { label: "0-30 days", value: 0 },
    { label: "31-60 days", value: 0 },
    { label: "61-90 days", value: 0 },
    { label: "90+ days", value: 0 },
  ];
  state.records
    .filter((record) => record.completed !== "X")
    .forEach((record) => {
      const age = ageDays(record);
      if (age <= 30) openAge[0].value += 1;
      else if (age <= 60) openAge[1].value += 1;
      else if (age <= 90) openAge[2].value += 1;
      else openAge[3].value += 1;
    });

  const today = parseLocalDate(todayIso());
  const reminderCutoff = new Date(today);
  reminderCutoff.setDate(reminderCutoff.getDate() + 7);
  const reminders = state.records
    .filter((record) => {
      if (!isOpenCase(record) || !record.followUpDueDate) return false;
      const dueDate = parseLocalDate(record.followUpDueDate);
      return dueDate && dueDate <= reminderCutoff;
    })
    .sort((a, b) => {
      const dueDelta = parseLocalDate(a.followUpDueDate) - parseLocalDate(b.followUpDueDate);
      return dueDelta || ageDays(b) - ageDays(a);
    })
    .slice(0, 10);
  const dataQuality = [
    { label: "Missing Employee ID", value: state.records.filter((record) => !record.batchNumber).length },
    { label: "Missing Supervisor", value: state.records.filter((record) => !record.supervisor).length },
    { label: "Missing Category", value: state.records.filter((record) => !record.summary).length },
    { label: "Due date without owner", value: state.records.filter((record) => isOpenCase(record) && record.followUpDueDate && !record.followUpOwner).length },
  ];

  return {
    total,
    completed,
    open,
    latest,
    change,
    recentTotal: recentRecords.length,
    recentCompleted,
    recentOpen: recentRecords.length - recentCompleted,
    completionRate: recentRecords.length ? recentCompleted / recentRecords.length : 0,
    average: activeWeeks ? total / activeWeeks : 0,
    peak,
    topCategory,
    oldestOpen,
    agedOpen,
    categoryRows,
    supervisorRows,
    last12,
    openAge,
    reminders,
    dataQuality,
    reportingDays: state.reportingDays,
  };
}

function renderDashboard() {
  const data = getDashboardData();
  document.querySelector("#kpiTotal").textContent = formatNumber(data.total);
  document.querySelector("#kpiLatest").textContent = formatNumber(data.latest);
  document.querySelector("#kpiChange").textContent = formatPercent(data.change);
  document.querySelector("#kpiCompletion").textContent = formatPercent(data.completionRate);
  document.querySelector("#kpiOpen").textContent = formatNumber(data.open);
  document.querySelector("#kpiAverage").textContent = formatNumber(data.average, 1);
  document.querySelector("#signalPeak").textContent = data.peak.week;
  document.querySelector("#signalCategory").textContent = data.topCategory.category;
  document.querySelector("#signalOldest").textContent = formatNumber(data.oldestOpen);
  document.querySelector("#signalAged").textContent = formatNumber(data.agedOpen);
  document.querySelector("#kpiChangeLabel").textContent = `${data.reportingDays}-Day Week Change`;
  document.querySelector("#kpiCompletionLabel").textContent = `${data.reportingDays}-Day Completion`;

  renderCategoryTable(data);
  renderSupervisorTable(data);
  renderReminders(data);
  renderQuality(data);
  drawLineChart(document.querySelector("#weeklyLine"), data.last12);
  drawWeeklyBars(document.querySelector("#weeklyBars"), data.last12);
  drawCategoryBars(document.querySelector("#categoryBars"), data.categoryRows);
  drawAgeBars(document.querySelector("#ageBars"), data.openAge);
}

function renderExecutiveSummary(data = getDashboardData()) {
  const closeRate = data.total ? data.completed / data.total : 0;
  const openShare = data.total ? data.open / data.total : 0;
  const closedShare = data.total ? data.completed / data.total : 0;
  const latestWeek = data.last12[data.last12.length - 1] ?? { week: 0, total: 0, completed: 0, open: 0 };
  const priorWeek = data.last12[data.last12.length - 2] ?? { total: 0, completed: 0, open: 0 };
  const netChange = latestWeek.total - priorWeek.total;
  const openChange = latestWeek.open - priorWeek.open;
  const closedChange = latestWeek.completed - priorWeek.completed;
  const changePhrase = netChange === 0
    ? "flat"
    : `${netChange > 0 ? "up" : "down"} ${formatNumber(Math.abs(netChange))}`;

  els.executiveWindowText.textContent = `All tracker activity. Recent movement uses the selected ${data.reportingDays}-day reporting window.`;
  els.execTotal.textContent = formatNumber(data.total);
  els.execOpen.textContent = formatNumber(data.open);
  els.execClosed.textContent = formatNumber(data.completed);
  els.execRate.textContent = formatPercent(closeRate);
  els.execOpenShare.textContent = formatPercent(openShare);
  els.execClosedShare.textContent = formatPercent(closedShare);
  els.execOpenBar.style.width = `${openShare * 100}%`;
  els.execClosedBar.style.width = `${closedShare * 100}%`;
  els.executiveTrendNote.textContent = `Weekly open and closed walk-ins for the latest ${data.last12.length || 0} weeks. Latest week ${latestWeek.week || "-"} is ${changePhrase} versus the prior week.`;
  els.executiveReadout.innerHTML = `
    <p><strong>${formatNumber(data.open)}</strong> walk-ins remain open and <strong>${formatNumber(data.completed)}</strong> are closed, for an overall close rate of <strong>${formatPercent(closeRate)}</strong>.</p>
    <p>In the selected ${data.reportingDays}-day window, <strong>${formatNumber(data.recentTotal)}</strong> walk-ins were recorded and <strong>${formatNumber(data.recentCompleted)}</strong> were closed.</p>
    <p>Week ${latestWeek.week || "-"} changed by <strong>${formatSigned(netChange)}</strong> total walk-ins, with open activity ${formatSigned(openChange)} and closed activity ${formatSigned(closedChange)} versus the prior week.</p>
  `;

  const openCategories = data.categoryRows
    .filter((row) => row.open > 0)
    .sort((a, b) => b.open - a.open || a.category.localeCompare(b.category))
    .slice(0, 8);
  els.executiveOpenCategories.innerHTML = openCategories.length
    ? openCategories.map((row) => `
        <tr>
          <td>${escapeHtml(row.category)}</td>
          <td class="number">${formatNumber(row.open)}</td>
          <td class="number">${formatPercent(data.open ? row.open / data.open : 0)}</td>
        </tr>
      `).join("")
    : `<tr class="empty-row"><td colspan="3">No open walk-ins.</td></tr>`;

  const snapshot = data.last12.slice(-6);
  const snapshotStart = Math.max(0, data.last12.length - snapshot.length);
  els.executiveWeekRows.innerHTML = snapshot.length
    ? snapshot.map((row, index) => {
      const previous = data.last12[snapshotStart + index - 1] ?? { total: 0 };
      return `
        <tr>
          <td>Week ${escapeHtml(row.week)}</td>
          <td class="number">${formatNumber(row.total)}</td>
          <td class="number ${row.total - previous.total >= 0 ? "trend-positive" : "trend-negative"}">${formatSigned(row.total - previous.total)}</td>
          <td class="number">${formatNumber(row.open)}</td>
          <td class="number">${formatNumber(row.completed)}</td>
        </tr>
      `;
    }).join("")
    : `<tr class="empty-row"><td colspan="5">No weekly activity.</td></tr>`;

  if (els.executiveTrend.getBoundingClientRect().width > 0) drawExecutiveTrend(els.executiveTrend, data.last12);
}

function daysUntil(dateValue) {
  const dueDate = parseLocalDate(dateValue);
  const today = parseLocalDate(todayIso());
  return dueDate && today ? Math.round((dueDate - today) / 86400000) : 0;
}

function reminderStatusLabel(record) {
  const days = daysUntil(record.followUpDueDate);
  if (days < 0) return `${Math.abs(days)}d overdue`;
  if (days === 0) return "Due today";
  return `Due in ${days}d`;
}

function renderReminders(data) {
  const openWithDueDate = state.records.filter((record) => isOpenCase(record) && record.followUpDueDate).length;
  const overdue = state.records.filter((record) => isOpenCase(record) && followUpStatus(record) === "overdue").length;
  els.reminderSummary.textContent = openWithDueDate
    ? `${formatNumber(overdue)} overdue. Showing open follow-ups due within 7 days.`
    : "No follow-up due dates have been entered yet.";
  els.reminderRows.innerHTML = data.reminders.length
    ? data.reminders.map((record) => `
        <tr class="reminder-row" data-id="${record.id}" title="Click to edit this walk-in">
          <td class="reminder-status ${followUpStatus(record)}">${escapeHtml(reminderStatusLabel(record))}</td>
          <td>${escapeHtml(record.followUpDueDate)}</td>
          <td>${escapeHtml(record.employeeName)}</td>
          <td>${escapeHtml(record.followUpOwner || "-")}</td>
          <td>${escapeHtml(record.summary)}</td>
          <td class="age-cell">${formatNumber(ageDays(record))}d</td>
        </tr>
      `).join("")
    : `<tr class="empty-row"><td colspan="6">Nothing due in the next 7 days.</td></tr>`;
}

function renderQuality(data) {
  const issueCount = data.dataQuality.reduce((sum, item) => sum + item.value, 0);
  els.qualitySummary.textContent = issueCount
    ? `${formatNumber(issueCount)} data-quality item${issueCount === 1 ? "" : "s"} need attention.`
    : "No data-quality issues found.";
  els.qualityList.innerHTML = issueCount
    ? data.dataQuality
      .filter((item) => item.value > 0)
      .map((item) => `<li><span>${escapeHtml(item.label)}</span><strong>${formatNumber(item.value)}</strong></li>`)
      .join("")
    : `<li class="quality-ok"><span>All tracked fields are populated.</span><strong>OK</strong></li>`;
}

function renderHistory() {
  const entries = state.audit ?? [];
  els.historySummary.textContent = entries.length
    ? `${formatNumber(entries.length)} recent activit${entries.length === 1 ? "y" : "ies"} recorded.`
    : "No activity recorded yet.";
  els.historyRows.innerHTML = entries.length
    ? entries.map((entry) => {
      const date = new Date(entry.timestamp);
      const timestamp = Number.isNaN(date.getTime()) ? entry.timestamp : date.toLocaleString();
      return `
        <tr>
          <td>${escapeHtml(timestamp)}</td>
          <td class="history-action">${escapeHtml(entry.action)}</td>
          <td>${escapeHtml(entry.employeeName || "-")}</td>
          <td>${escapeHtml(entry.details || "-")}</td>
        </tr>
      `;
    }).join("")
    : `<tr class="empty-row"><td colspan="4">No activity recorded yet.</td></tr>`;
}

function renderSavedViews(selected = els.savedViewSelect.value) {
  els.savedViewSelect.innerHTML = state.savedViews.length
    ? `<option value="">Select a saved view</option>${state.savedViews.map((view) => `<option value="${escapeHtml(view.name)}">${escapeHtml(view.name)}</option>`).join("")}`
    : `<option value="">No saved views</option>`;
  if (state.savedViews.some((view) => view.name === selected)) els.savedViewSelect.value = selected;
}

function currentSearchView() {
  syncSearchFilters();
  return { name: els.newViewName.value.trim(), filters: { ...state.searchFilters } };
}

function saveSearchView() {
  const view = currentSearchView();
  if (!view.name) {
    toast("Enter a view name first.");
    els.newViewName.focus();
    return;
  }
  const existing = state.savedViews.find((saved) => saved.name.toLowerCase() === view.name.toLowerCase());
  if (existing) existing.filters = view.filters;
  else state.savedViews.push(view);
  state.savedViews.sort((a, b) => a.name.localeCompare(b.name));
  writeLocalJson(SAVED_VIEWS_KEY, state.savedViews);
  renderSavedViews(view.name);
  toast(`Saved view "${view.name}".`);
}

function applySavedView() {
  const name = els.savedViewSelect.value;
  const view = state.savedViews.find((saved) => saved.name === name);
  if (!view) return;
  const filters = view.filters;
  els.searchInput.value = filters.query ?? "";
  els.searchEmployeeId.value = filters.employeeId ?? "";
  els.searchSupervisorFilter.value = filters.supervisor ?? "";
  els.searchCategoryFilter.value = filters.category ?? "";
  els.searchStatusFilter.value = filters.status ?? "";
  els.searchAgeFilter.value = filters.ageBucket ?? "";
  els.searchFollowUpFilter.value = filters.followUp ?? "";
  els.searchDateFrom.value = filters.dateFrom ?? "";
  els.searchDateTo.value = filters.dateTo ?? "";
  syncSearchFilters();
  renderSearchGrid({ resetScroll: true });
  toast(`Applied view "${name}".`);
}

function deleteSavedView() {
  const name = els.savedViewSelect.value;
  if (!name) return;
  state.savedViews = state.savedViews.filter((view) => view.name !== name);
  writeLocalJson(SAVED_VIEWS_KEY, state.savedViews);
  renderSavedViews();
  toast(`Deleted view "${name}".`);
}

function activateTab(name) {
  document.querySelector(`.tab[data-tab="${name}"]`)?.click();
}

function clearSearchControls() {
  els.searchForm.reset();
  els.searchSupervisorFilter.value = "";
  els.searchCategoryFilter.value = "";
  els.searchStatusFilter.value = "";
  els.searchAgeFilter.value = "";
  els.searchFollowUpFilter.value = "";
  els.searchDateFrom.value = "";
  els.searchDateTo.value = "";
  syncSearchFilters();
}

function clearOpenControls() {
  els.openFilterForm.reset();
  syncOpenFilters();
}

function dateDaysAgo(days) {
  const date = parseLocalDate(todayIso());
  date.setDate(date.getDate() - days);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function applyKpiFilter(kpi) {
  if (kpi === "open") {
    clearOpenControls();
    activateTab("open");
    return;
  }
  clearSearchControls();
  if (kpi === "window" || kpi === "completed" || kpi === "average") {
    els.searchDateFrom.value = dateDaysAgo(state.reportingDays);
    els.searchDateTo.value = todayIso();
  }
  if (kpi === "completed") els.searchStatusFilter.value = "completed";
  if (kpi === "latest") {
    const latestWeek = Math.max(...state.records.map((record) => Number(record.week) || 0), 0);
    const latestRecords = state.records.filter((record) => Number(record.week) === latestWeek);
    els.searchDateFrom.value = latestRecords.reduce((date, record) => (!date || record.date < date ? record.date : date), "");
    els.searchDateTo.value = latestRecords.reduce((date, record) => (!date || record.date > date ? record.date : date), "");
  }
  syncSearchFilters();
  activateTab("search");
  renderSearchGrid({ resetScroll: true });
}

function applyExecutiveAction(action) {
  if (action === "open") {
    applyKpiFilter("open");
    return;
  }
  clearSearchControls();
  if (action === "closed") els.searchStatusFilter.value = "completed";
  syncSearchFilters();
  activateTab("search");
  renderSearchGrid({ resetScroll: true });
}

function renderCategoryTable(data) {
  els.categoryTable.innerHTML = data.categoryRows
    .map((row) => {
      const completion = row.total ? row.completed / row.total : 0;
      const share = data.total ? row.total / data.total : 0;
      return `
        <tr>
          <td>${escapeHtml(row.category)}</td>
          <td class="number">${formatNumber(row.total)}</td>
          <td class="number">${formatNumber(row.open)}</td>
          <td class="number">${formatNumber(row.completed)}</td>
          <td class="number">${formatPercent(completion)}</td>
          <td class="number">${formatPercent(share)}</td>
        </tr>
      `;
    })
    .join("");
}

function renderSupervisorTable(data) {
  els.supervisorTable.innerHTML = data.supervisorRows
    .map((row) => {
      const completion = row.total ? row.completed / row.total : 0;
      return `
        <tr>
          <td>${escapeHtml(row.supervisor)}</td>
          <td class="number">${formatNumber(row.total)}</td>
          <td class="number">${formatNumber(row.open)}</td>
          <td class="number">${formatNumber(row.completed)}</td>
          <td class="number">${formatPercent(completion)}</td>
        </tr>
      `;
    })
    .join("");
}

function canvasContext(canvas) {
  const ratio = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.max(1, Math.floor(rect.width * ratio));
  canvas.height = Math.max(1, Math.floor(rect.height * ratio));
  const ctx = canvas.getContext("2d");
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  return { ctx, width: rect.width, height: rect.height };
}

function drawFrame(ctx, width, height, maxValue) {
  const left = 42;
  const top = 18;
  const right = width - 16;
  const bottom = height - 34;
  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = chartColors.grid;
  ctx.lineWidth = 1;
  ctx.fillStyle = chartColors.muted;
  ctx.font = "11px Segoe UI, Arial";
  const steps = 4;
  for (let i = 0; i <= steps; i += 1) {
    const y = bottom - ((bottom - top) * i) / steps;
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(right, y);
    ctx.stroke();
    ctx.fillText(formatNumber((maxValue * i) / steps), 6, y + 4);
  }
  return { left, top, right, bottom };
}

function drawLineChart(canvas, rows) {
  const { ctx, width, height } = canvasContext(canvas);
  const maxValue = Math.max(1, ...rows.map((row) => row.total));
  const frame = drawFrame(ctx, width, height, maxValue);
  const span = Math.max(1, rows.length - 1);
  ctx.strokeStyle = chartColors.blue;
  ctx.lineWidth = 3;
  ctx.beginPath();
  rows.forEach((row, index) => {
    const x = frame.left + ((frame.right - frame.left) * index) / span;
    const y = frame.bottom - ((frame.bottom - frame.top) * row.total) / maxValue;
    if (index === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();
  ctx.fillStyle = chartColors.muted;
  rows.forEach((row, index) => {
    const x = frame.left + ((frame.right - frame.left) * index) / span;
    ctx.fillText(row.week, x - 7, frame.bottom + 20);
  });
}

function drawExecutiveTrend(canvas, rows) {
  const { ctx, width, height } = canvasContext(canvas);
  const maxValue = Math.max(1, ...rows.flatMap((row) => [row.open, row.completed]));
  const frame = drawFrame(ctx, width, height, maxValue);
  const span = Math.max(1, rows.length - 1);
  const series = [
    ["open", chartColors.red, "Open"],
    ["completed", chartColors.green, "Closed"],
  ];
  series.forEach(([key, color]) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.beginPath();
    rows.forEach((row, index) => {
      const x = frame.left + ((frame.right - frame.left) * index) / span;
      const y = frame.bottom - ((frame.bottom - frame.top) * row[key]) / maxValue;
      if (index === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  });
  ctx.fillStyle = chartColors.muted;
  rows.forEach((row, index) => {
    const x = frame.left + ((frame.right - frame.left) * index) / span;
    ctx.fillText(row.week, x - 7, frame.bottom + 20);
  });
  drawLegend(ctx, frame.right - 125, 16, [
    ["Open", chartColors.red],
    ["Closed", chartColors.green],
  ]);
}

function drawWeeklyBars(canvas, rows) {
  const { ctx, width, height } = canvasContext(canvas);
  const maxValue = Math.max(1, ...rows.flatMap((row) => [row.total, row.completed, row.open]));
  const frame = drawFrame(ctx, width, height, maxValue);
  const groupWidth = (frame.right - frame.left) / Math.max(1, rows.length);
  const barWidth = Math.max(4, groupWidth / 5);
  rows.forEach((row, index) => {
    const x = frame.left + groupWidth * index + groupWidth / 4;
    [
      [row.total, chartColors.blue],
      [row.completed, chartColors.orange],
      [row.open, chartColors.green],
    ].forEach(([value, color], offset) => {
      const heightPx = ((frame.bottom - frame.top) * value) / maxValue;
      ctx.fillStyle = color;
      ctx.fillRect(x + barWidth * offset, frame.bottom - heightPx, barWidth, heightPx);
    });
    ctx.fillStyle = chartColors.muted;
    ctx.fillText(row.week, x, frame.bottom + 20);
  });
  drawLegend(ctx, frame.right - 190, 16, [
    ["Total", chartColors.blue],
    ["Completed", chartColors.orange],
    ["Open", chartColors.green],
  ]);
}

function drawCategoryBars(canvas, rows) {
  const { ctx, width, height } = canvasContext(canvas);
  const sorted = [...rows].sort((a, b) => b.total - a.total);
  const maxValue = Math.max(1, ...sorted.map((row) => row.total));
  const frame = drawFrame(ctx, width, height, maxValue);
  const barWidth = (frame.right - frame.left) / Math.max(1, sorted.length);
  sorted.forEach((row, index) => {
    const h = ((frame.bottom - frame.top) * row.total) / maxValue;
    const x = frame.left + index * barWidth + 6;
    ctx.fillStyle = chartColors.blue;
    ctx.fillRect(x, frame.bottom - h, Math.max(5, barWidth - 12), h);
    ctx.save();
    ctx.translate(x + 4, frame.bottom + 22);
    ctx.rotate(-0.38);
    ctx.fillStyle = chartColors.muted;
    ctx.fillText(row.category.slice(0, 14), 0, 0);
    ctx.restore();
  });
}

function drawAgeBars(canvas, rows) {
  const { ctx, width, height } = canvasContext(canvas);
  const maxValue = Math.max(1, ...rows.map((row) => row.value));
  const frame = drawFrame(ctx, width, height, maxValue);
  const barWidth = (frame.right - frame.left) / Math.max(1, rows.length);
  rows.forEach((row, index) => {
    const h = ((frame.bottom - frame.top) * row.value) / maxValue;
    const x = frame.left + index * barWidth + barWidth * 0.25;
    ctx.fillStyle = chartColors.blue;
    ctx.fillRect(x, frame.bottom - h, barWidth * 0.5, h);
    ctx.fillStyle = chartColors.muted;
    ctx.fillText(row.label, x - 8, frame.bottom + 20);
  });
}

function drawLegend(ctx, x, y, items) {
  ctx.font = "11px Segoe UI, Arial";
  items.forEach(([label, color], index) => {
    const itemX = x + index * 70;
    ctx.fillStyle = color;
    ctx.fillRect(itemX, y, 10, 10);
    ctx.fillStyle = chartColors.muted;
    ctx.fillText(label, itemX + 14, y + 9);
  });
}

function readAddForm() {
  const form = new FormData(els.addForm);
  return {
    date: form.get("date"),
    employeeName: form.get("employeeName"),
    batchNumber: form.get("batchNumber"),
    supervisor: form.get("supervisor"),
    hrPerson: form.get("hrPerson"),
    followUpOwner: form.get("followUpOwner"),
    followUpDueDate: form.get("followUpDueDate"),
    information: form.get("information"),
    summary: form.get("summary"),
    completed: els.addForm.elements.completed.checked ? "X" : "",
  };
}

async function appendIncident(event) {
  event.preventDefault();
  const submit = els.addForm.querySelector("[type='submit']");
  setBusy(submit, true, "Appending...");
  try {
    const payload = readAddForm();
    const record = localRecordValidation({ ...payload, id: nextLocalRecordId(state.records) });
    const result = await syncSnapshotToServer([...state.records, record]);
    if (!result.ok && !result.unavailable && !result.conflict) throw result.error || new Error("The record could not be saved.");
    els.addForm.reset();
    els.addDate.value = todayIso();
    renderAllData();
    toast(result.conflict ? "Record saved locally; sync is paused for conflict resolution." : `Added ${record.employeeName}.`);
  } catch (error) {
    toast(error.message);
  } finally {
    setBusy(submit, false);
  }
}

async function runSearch(event, announce = true) {
  event?.preventDefault();
  syncSearchFilters();
  const matches = filteredSearchRecords();
  renderSearchRows(matches, { resetScroll: true });
  if (announce && hasActiveFilters(state.searchFilters)) {
    toast(`Filtered to ${matches.length} incident${matches.length === 1 ? "" : "s"}.`);
  }
}

function newestFirst(records) {
  return [...records].sort((a, b) => {
    const rowDelta = (Number(b.rowNumber) || 0) - (Number(a.rowNumber) || 0);
    if (rowDelta) return rowDelta;
    const dateDelta = Date.parse(b.date || "") - Date.parse(a.date || "");
    if (dateDelta) return dateDelta;
    return String(b.id).localeCompare(String(a.id), undefined, { numeric: true });
  });
}

function isOpenCase(record) {
  return record.completed !== "X";
}

function hasActiveFilters(filters) {
  return Object.values(filters).some(Boolean);
}

function matchesRecordFilters(record, filters, openOnly = false) {
  if (openOnly && !isOpenCase(record)) return false;
  const query = String(filters.query ?? "").toLowerCase();
  if (query && !record.employeeName.toLowerCase().includes(query)) return false;
  const employeeId = String(filters.employeeId ?? "").toLowerCase();
  if (employeeId && !record.batchNumber.toLowerCase().includes(employeeId)) return false;
  if (filters.supervisor && record.supervisor !== filters.supervisor) return false;
  if (filters.category && record.summary !== filters.category) return false;
  if (filters.status === "open" && !isOpenCase(record)) return false;
  if (filters.status === "completed" && isOpenCase(record)) return false;
  if (filters.ageBucket && ageBucket(record) !== filters.ageBucket) return false;
  if (!matchesFollowUpFilter(record, filters.followUp)) return false;
  if (filters.dateFrom && record.date < filters.dateFrom) return false;
  if (filters.dateTo && record.date > filters.dateTo) return false;
  return true;
}

function syncSearchFilters() {
  state.lastSearch = els.searchInput.value.trim();
  state.searchFilters = {
    query: state.lastSearch,
    employeeId: els.searchEmployeeId.value.trim(),
    supervisor: els.searchSupervisorFilter.value,
    category: els.searchCategoryFilter.value,
    status: els.searchStatusFilter.value,
    ageBucket: els.searchAgeFilter.value,
    followUp: els.searchFollowUpFilter.value,
    dateFrom: els.searchDateFrom.value,
    dateTo: els.searchDateTo.value,
  };
}

function syncOpenFilters() {
  state.openFilters = {
    query: els.openSearchInput.value.trim(),
    employeeId: els.openEmployeeId.value.trim(),
    supervisor: els.openSupervisorFilter.value,
    category: els.openCategoryFilter.value,
    ageBucket: els.openAgeFilter.value,
    followUp: els.openFollowUpFilter.value,
    dateFrom: els.openDateFrom.value,
    dateTo: els.openDateTo.value,
  };
}

function filteredSearchRecords() {
  return newestFirst(state.records.filter((record) => matchesRecordFilters(record, state.searchFilters)));
}

function filteredOpenRecords() {
  return newestFirst(state.records.filter((record) => matchesRecordFilters(record, state.openFilters, true)));
}

function renderSearchGrid(options = {}) {
  renderSearchRows(filteredSearchRecords(), options);
}

function renderSearchRows(records, options = {}) {
  const query = state.searchFilters.query.trim();
  const activeFilters = hasActiveFilters(state.searchFilters);
  let summary = query
    ? `${formatNumber(records.length)} incident${records.length === 1 ? "" : "s"} found for "${query}"`
    : activeFilters
      ? `${formatNumber(records.length)} tracker entr${records.length === 1 ? "y" : "ies"} match the selected filters`
      : `${formatNumber(state.records.length)} tracker entries loaded`;
  if (!activeFilters) {
    summary += ". Type an employee name to filter, scroll to browse, or click any row to edit";
  }
  els.searchSummary.textContent = `${summary}. Add a new entry on the empty bottom row.`;
  state.searchRecords = records;
  if (options.resetScroll && els.editWrap) {
    els.editWrap.scrollTop = 0;
  }
  renderSearchWindow();
}

function visibleSearchWindow(total) {
  const viewportHeight = Math.max(SEARCH_ROW_HEIGHT, els.editWrap?.clientHeight || SEARCH_ROW_HEIGHT * 12);
  const scrollTop = els.editWrap?.scrollTop || 0;
  const renderedCount = Math.max(
    SEARCH_MIN_RENDERED_ROWS,
    Math.ceil(viewportHeight / SEARCH_ROW_HEIGHT) + SEARCH_OVERSCAN_ROWS * 2
  );
  const start = Math.max(0, Math.floor(scrollTop / SEARCH_ROW_HEIGHT) - SEARCH_OVERSCAN_ROWS);
  return {
    start,
    end: Math.min(total, start + renderedCount),
  };
}

function renderSearchWindow() {
  const records = state.searchRecords || [];
  const { start, end } = visibleSearchWindow(records.length);
  const visibleRecords = records.slice(start, end);
  const topSpacer = start * SEARCH_ROW_HEIGHT;
  const bottomSpacer = Math.max(0, records.length - end) * SEARCH_ROW_HEIGHT;
  els.searchResults.innerHTML = [
    renderSearchSpacer(topSpacer),
    visibleRecords.map((record) => renderSearchRecordRow(record)).join(""),
    renderSearchSpacer(bottomSpacer),
    renderNewEntryRow(),
  ].join("");
}

function renderSearchSpacer(height) {
  if (height <= 0) return "";
  return `<tr class="virtual-spacer" aria-hidden="true"><td colspan="14" style="height: ${Math.round(height)}px"></td></tr>`;
}

function renderOpenGrid(options = {}) {
  renderOpenRows(filteredOpenRecords(), options);
}

function renderOpenRows(records, options = {}) {
  const oldestOpen = records.reduce((oldest, record) => Math.max(oldest, ageDays(record)), 0);
  const dueFollowUps = records.filter((record) => {
    const status = followUpStatus(record);
    return status === "due" || status === "overdue";
  }).length;
  els.openSummary.textContent =
    `${formatNumber(records.length)} open walk-in${records.length === 1 ? "" : "s"} loaded. ` +
    `Follow-ups due or overdue: ${formatNumber(dueFollowUps)}. ` +
    `Oldest open walk-in: ${formatNumber(oldestOpen)} day${oldestOpen === 1 ? "" : "s"}. Click any row to edit or mark completed.`;
  state.openRecords = records;
  if (options.resetScroll && els.openWrap) {
    els.openWrap.scrollTop = 0;
  }
  renderOpenWindow();
}

function visibleOpenWindow(total) {
  const viewportHeight = Math.max(SEARCH_ROW_HEIGHT, els.openWrap?.clientHeight || SEARCH_ROW_HEIGHT * 12);
  const scrollTop = els.openWrap?.scrollTop || 0;
  const renderedCount = Math.max(
    SEARCH_MIN_RENDERED_ROWS,
    Math.ceil(viewportHeight / SEARCH_ROW_HEIGHT) + SEARCH_OVERSCAN_ROWS * 2
  );
  const start = Math.max(0, Math.floor(scrollTop / SEARCH_ROW_HEIGHT) - SEARCH_OVERSCAN_ROWS);
  return {
    start,
    end: Math.min(total, start + renderedCount),
  };
}

function renderOpenWindow() {
  const records = state.openRecords || [];
  if (!records.length) {
    els.openResults.innerHTML = `<tr class="empty-row"><td colspan="14">No open walk-ins match the selected filters.</td></tr>`;
    return;
  }
  const { start, end } = visibleOpenWindow(records.length);
  const visibleRecords = records.slice(start, end);
  const topSpacer = start * SEARCH_ROW_HEIGHT;
  const bottomSpacer = Math.max(0, records.length - end) * SEARCH_ROW_HEIGHT;
  els.openResults.innerHTML = [
    renderSearchSpacer(topSpacer),
    visibleRecords.map((record) => renderSearchRecordRow(record)).join(""),
    renderSearchSpacer(bottomSpacer),
  ].join("");
}

function renderSearchRecordRow(record) {
  return state.editingIds.has(String(record.id)) ? renderEditableRow(record) : renderReadOnlyRow(record);
}

function renderReadOnlyRow(record) {
  return `
    <tr class="view-row" data-id="${record.id}" title="Click to edit this row">
      <td class="row-cell">${record.rowNumber}</td>
      <td class="row-cell">${record.week}</td>
      <td>${escapeHtml(record.date)}</td>
      <td class="age-cell" title="${escapeHtml(AGE_BUCKETS.find((bucket) => bucket.value === ageBucket(record))?.label ?? "Age not available")}">${formatNumber(ageDays(record))}d</td>
      <td>${escapeHtml(record.employeeName)}</td>
      <td>${escapeHtml(record.batchNumber)}</td>
      <td>${escapeHtml(record.supervisor)}</td>
      <td>${escapeHtml(record.hrPerson)}</td>
      <td>${escapeHtml(record.followUpOwner)}</td>
      <td class="due-cell ${followUpStatus(record)}">${escapeHtml(record.followUpDueDate || "-")}</td>
      <td>${escapeHtml(record.summary)}</td>
      <td class="info-cell" title="${escapeHtml(record.information)}">${escapeHtml(record.information)}</td>
      <td class="done-cell">${record.completed === "X" ? "X" : ""}</td>
      <td><div class="row-actions"><button class="edit-row-button" type="button">Edit</button><button class="delete-row-button" type="button">Delete</button></div></td>
    </tr>
  `;
}

function renderEditableRow(record) {
  return `
    <tr class="editing-row" data-id="${record.id}">
      <td class="row-cell">${record.rowNumber}</td>
      <td class="row-cell">${record.week}</td>
      <td><input data-field="date" type="date" value="${escapeHtml(record.date)}" /></td>
      <td class="age-cell" title="${escapeHtml(AGE_BUCKETS.find((bucket) => bucket.value === ageBucket(record))?.label ?? "Age not available")}">${formatNumber(ageDays(record))}d</td>
      <td><input data-field="employeeName" value="${escapeHtml(record.employeeName)}" /></td>
      <td><input data-field="batchNumber" value="${escapeHtml(record.batchNumber)}" /></td>
      <td><input data-field="supervisor" list="supervisorList" value="${escapeHtml(record.supervisor)}" /></td>
      <td><input data-field="hrPerson" list="hrPersonList" value="${escapeHtml(record.hrPerson)}" /></td>
      <td><input data-field="followUpOwner" list="followUpOwnerList" value="${escapeHtml(record.followUpOwner)}" /></td>
      <td><input data-field="followUpDueDate" type="date" value="${escapeHtml(record.followUpDueDate)}" /></td>
      <td><select data-field="summary">${categoryOptions(record.summary)}</select></td>
      <td><textarea data-field="information">${escapeHtml(record.information)}</textarea></td>
      <td><input data-field="completed" type="checkbox" ${record.completed === "X" ? "checked" : ""} /></td>
      <td><div class="row-actions"><button class="save-button" type="button">Save</button><button class="delete-row-button" type="button">Delete</button></div></td>
    </tr>
  `;
}

function renderNewEntryRow() {
  return `
    <tr class="new-row" data-new-row="true">
      <td class="row-cell">New</td>
      <td class="row-cell"></td>
      <td><input data-field="date" type="date" value="${todayIso()}" /></td>
      <td class="age-cell">-</td>
      <td><input data-field="employeeName" value="${escapeHtml(state.lastSearch)}" /></td>
      <td><input data-field="batchNumber" placeholder="Employee ID" /></td>
      <td><input data-field="supervisor" list="supervisorList" placeholder="Supervisor" /></td>
      <td><input data-field="hrPerson" list="hrPersonList" placeholder="HR person" /></td>
      <td><input data-field="followUpOwner" list="followUpOwnerList" placeholder="Owner" /></td>
      <td><input data-field="followUpDueDate" type="date" /></td>
      <td><select data-field="summary"><option value="">Select</option>${categoryOptions()}</select></td>
      <td><textarea data-field="information" placeholder="Information"></textarea></td>
      <td><input data-field="completed" type="checkbox" /></td>
      <td><button class="add-row-button" type="button">Add Row</button></td>
    </tr>
  `;
}

function rowPayload(row) {
  const payload = {};
  row.querySelectorAll("[data-field]").forEach((field) => {
    payload[field.dataset.field] = field.type === "checkbox" ? (field.checked ? "X" : "") : field.value;
  });
  return payload;
}

async function saveSearchRow(button) {
  const row = button.closest("tr");
  const id = row.dataset.id;
  const payload = rowPayload(row);
  setBusy(button, true, "Saving...");
  try {
    const existing = state.records.find((record) => String(record.id) === String(id));
    if (!existing) throw new Error("That walk-in is no longer available.");
    const updated = localRecordValidation({ ...existing, ...payload, id: existing.id }, existing);
    const result = await syncSnapshotToServer(state.records.map((record) => (
      String(record.id) === String(id) ? updated : record
    )));
    state.editingIds.delete(String(id));
    renderAllData();
    toast(result.conflict ? "Saved locally; sync is paused for conflict resolution." : "Incident saved.");
  } catch (error) {
    toast(error.message);
  } finally {
    setBusy(button, false);
  }
}

async function deleteRow(button) {
  const row = button.closest("tr");
  const id = row?.dataset.id;
  const record = state.records.find((item) => String(item.id) === String(id));
  if (!record) {
    toast("That walk-in is no longer available.");
    return;
  }
  const description = `${record.employeeName || "this walk-in"}${record.date ? ` dated ${record.date}` : ""}`;
  if (!window.confirm(`Delete ${description}? This cannot be undone.`)) return;
  setBusy(button, true, "Deleting...");
  try {
    const result = await syncSnapshotToServer(state.records.filter((item) => String(item.id) !== String(id)));
    state.editingIds.delete(String(id));
    renderAllData();
    toast(result.conflict ? "Deletion saved locally; sync is paused for conflict resolution." : "Walk-in deleted.");
  } catch (error) {
    toast(error.message);
  } finally {
    setBusy(button, false);
  }
}

async function addSearchRow(button) {
  const row = button.closest("tr");
  const payload = rowPayload(row);
  setBusy(button, true, "Adding...");
  try {
    const record = localRecordValidation({ ...payload, id: nextLocalRecordId(state.records) });
    const result = await syncSnapshotToServer([...state.records, record]);
    renderSearchGrid({ resetScroll: true });
    toast(result.conflict ? "Record saved locally; sync is paused for conflict resolution." : `Added ${record.employeeName}.`);
  } catch (error) {
    toast(error.message);
  } finally {
    setBusy(button, false);
  }
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function standaloneWorkbookHtml() {
  const rows = state.records.map((record) => [
    record.week,
    record.date,
    record.employeeName,
    record.batchNumber,
    record.supervisor,
    record.hrPerson,
    record.followUpOwner,
    record.followUpDueDate,
    record.information,
    record.summary,
    record.completed,
  ]);
  const headers = ["Week", "Date", "Employee Name", "Employee ID", "Supervisor", "HR Person", "Follow-up Owner", "Follow-up Due", "Information", "Summary", "Completed"];
  const tableRow = (cells, header = false) => `<tr>${cells.map((cell) => `<${header ? "th" : "td"}>${escapeHtml(cell)}</${header ? "th" : "td"}>`).join("")}</tr>`;
  return `<!doctype html><html><head><meta charset="utf-8"><style>table{border-collapse:collapse;font-family:Arial;font-size:10pt}th{background:#17324d;color:#fff;text-align:left}th,td{border:1px solid #d9e2ec;padding:5px;vertical-align:top}td:nth-child(1),td:nth-child(2),td:nth-child(11){text-align:right}</style></head><body><table>${tableRow(headers, true)}${rows.map((row) => tableRow(row)).join("")}</table></body></html>`;
}

function exportStandaloneWorkbook() {
  const blob = new Blob([standaloneWorkbookHtml()], { type: "application/vnd.ms-excel" });
  downloadBlob(blob, "HR_Action_Item_Dashboard.xls");
  toast("Excel-compatible workbook downloaded.");
}

async function exportWorkbook() {
  setBusy(els.exportButton, true, "Preparing Excel...");
  toast("Preparing Excel workbook...");
  try {
    if (isStandalone) {
      exportStandaloneWorkbook();
      return;
    }
    const result = await fetchJson("/api/export", {
      method: "POST",
      body: JSON.stringify({ reportingDays: state.reportingDays }),
    });
    const response = await fetch(result.downloadUrl, { cache: "no-store" });
    if (!response.ok) {
      let message = "Workbook download failed.";
      try {
        const payload = await response.json();
        message = payload.error || message;
      } catch {
        // Keep the generic download message when the response is not JSON.
      }
      throw new Error(message);
    }
    downloadBlob(await response.blob(), result.filename || "HR_Action_Item_Dashboard.xlsx");
    toast("Excel workbook downloaded.");
  } catch (error) {
    toast(error.message);
  } finally {
    setBusy(els.exportButton, false);
  }
}

async function fileToBase64(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary = "";
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

async function importLocally(file) {
  const imported = standaloneImportRecords(file.name, await fileToBase64(file));
  const existingKeys = new Set(state.records.map(incidentFingerprint));
  let nextId = nextLocalRecordId(state.records);
  let added = 0;
  let duplicates = 0;
  const invalid = [];
  const records = [...state.records];

  for (const [index, candidate] of imported.entries()) {
    try {
      const normalized = localRecordValidation({ ...candidate, id: nextId });
      const fingerprint = incidentFingerprint(normalized);
      if (existingKeys.has(fingerprint)) {
        duplicates += 1;
        continue;
      }
      existingKeys.add(fingerprint);
      records.push(normalized);
      nextId -= 1;
      added += 1;
    } catch (error) {
      invalid.push({ row: index + 2, reason: error.message });
    }
  }

  const syncResult = await syncSnapshotToServer(records);
  return { added, duplicates, invalid, syncResult };
}

async function importFile() {
  const file = els.importInput.files?.[0];
  if (!file) return;
  setBusy(els.importButton, true, "Importing...");
  toast(`Importing ${file.name}...`);
  try {
    const result = await fetchJson("/api/import", {
      method: "POST",
      body: JSON.stringify({
        filename: file.name,
        contentBase64: await fileToBase64(file),
        baselineRecords: state.sync.baselineRecords ? persistedRecords(state.sync.baselineRecords) : null,
      }),
    });
    await loadData();
    const invalidText = result.invalid?.length ? ` ${result.invalid.length} invalid row${result.invalid.length === 1 ? "" : "s"} skipped.` : "";
    const reason = result.invalid?.[0]?.reason ? ` First issue: ${result.invalid[0].reason}` : "";
    toast(`Imported ${result.added} row${result.added === 1 ? "" : "s"}; ${result.duplicates} duplicate${result.duplicates === 1 ? "" : "s"} skipped.${invalidText}${reason}`);
  } catch (error) {
    if (error.status === 409 && Array.isArray(error.payload?.destinationRecords)) {
      state.sync.destinationRecords = error.payload.destinationRecords.map(normalizeClientRecord);
      state.sync.conflicts = [{ id: "__import__", kind: "import-destination-changed", fields: [] }];
      setSyncStatus("conflict", "Import paused because the shared destination changed");
      renderAllData();
      toast("Import paused. Refresh before importing again.");
    } else if (!isStandalone && !error.status && /\.(csv|json)$/i.test(file.name)) {
      try {
        const localResult = await importLocally(file);
        const invalidText = localResult.invalid.length ? ` ${localResult.invalid.length} invalid row${localResult.invalid.length === 1 ? "" : "s"} skipped.` : "";
        toast(`Imported ${localResult.added} row${localResult.added === 1 ? "" : "s"} locally; ${localResult.duplicates} duplicate${localResult.duplicates === 1 ? "" : "s"} skipped.${invalidText}`);
      } catch (localError) {
        toast(localError.message);
      }
    } else {
      toast(error.message);
    }
  } finally {
    els.importInput.value = "";
    setBusy(els.importButton, false);
  }
}

function bindEvents() {
  bindTabs();
  els.refreshButton.addEventListener("click", () => loadData().then(() => toast("Data refreshed.")));
  els.backupButton.addEventListener("click", exportLocalBackup);
  els.keepLocalButton.addEventListener("click", () => resolveSyncConflict("local"));
  els.useDestinationButton.addEventListener("click", () => resolveSyncConflict("destination"));
  els.importButton.addEventListener("click", () => els.importInput.click());
  els.importInput.addEventListener("change", importFile);
  els.exportButton.addEventListener("click", exportWorkbook);
  els.reportingWindow.addEventListener("change", () => {
    state.reportingDays = normalizeReportingDays(els.reportingWindow.value);
    writeLocalJson("hr-action-item-reporting-days", state.reportingDays);
    renderDashboard();
    renderExecutiveSummary();
    toast(`Reporting window set to ${state.reportingDays} days.`);
  });
  document.querySelectorAll(".kpi-button").forEach((button) => {
    button.addEventListener("click", () => applyKpiFilter(button.dataset.kpi));
  });
  document.querySelectorAll("[data-executive-action]").forEach((button) => {
    button.addEventListener("click", () => applyExecutiveAction(button.dataset.executiveAction));
  });
  els.addForm.addEventListener("submit", appendIncident);
  els.searchForm.addEventListener("submit", runSearch);
  els.openFilterForm.addEventListener("submit", (event) => {
    event.preventDefault();
    syncOpenFilters();
    renderOpenGrid({ resetScroll: true });
  });
  els.searchInput.addEventListener("input", () => {
    syncSearchFilters();
    state.editingIds.clear();
    renderSearchGrid({ resetScroll: true });
  });
  els.searchEmployeeId.addEventListener("input", () => {
    syncSearchFilters();
    state.editingIds.clear();
    renderSearchGrid({ resetScroll: true });
  });
  els.openSearchInput.addEventListener("input", () => {
    syncOpenFilters();
    state.editingIds.clear();
    renderOpenGrid({ resetScroll: true });
  });
  els.openEmployeeId.addEventListener("input", () => {
    syncOpenFilters();
    state.editingIds.clear();
    renderOpenGrid({ resetScroll: true });
  });
  [
    els.searchSupervisorFilter,
    els.searchCategoryFilter,
    els.searchStatusFilter,
    els.searchAgeFilter,
    els.searchFollowUpFilter,
    els.searchDateFrom,
    els.searchDateTo,
  ].forEach((control) => {
    control.addEventListener("change", () => {
      syncSearchFilters();
      state.editingIds.clear();
      renderSearchGrid({ resetScroll: true });
    });
  });
  [
    els.openSupervisorFilter,
    els.openCategoryFilter,
    els.openAgeFilter,
    els.openFollowUpFilter,
    els.openDateFrom,
    els.openDateTo,
  ].forEach((control) => {
    control.addEventListener("change", () => {
      syncOpenFilters();
      state.editingIds.clear();
      renderOpenGrid({ resetScroll: true });
    });
  });
  els.clearSearchFilters.addEventListener("click", () => {
    clearSearchControls();
    state.editingIds.clear();
    renderSearchGrid({ resetScroll: true });
  });
  els.clearOpenFilters.addEventListener("click", () => {
    clearOpenControls();
    state.editingIds.clear();
    renderOpenGrid({ resetScroll: true });
  });
  els.saveViewButton.addEventListener("click", saveSearchView);
  els.deleteViewButton.addEventListener("click", deleteSavedView);
  els.savedViewSelect.addEventListener("change", applySavedView);
  els.reminderRows.addEventListener("click", (event) => {
    const row = event.target.closest("tr[data-id]");
    if (!row) return;
    const record = state.records.find((item) => String(item.id) === row.dataset.id);
    if (!record) return;
    clearSearchControls();
    els.searchInput.value = record.employeeName;
    syncSearchFilters();
    activateTab("search");
    renderSearchGrid({ resetScroll: true });
  });
  els.editWrap.addEventListener("scroll", () => {
    if (!isSearchTabActive()) return;
    window.cancelAnimationFrame(state.searchRenderFrame);
    state.searchRenderFrame = window.requestAnimationFrame(renderSearchWindow);
  });
  els.openWrap.addEventListener("scroll", () => {
    if (!isOpenTabActive()) return;
    window.cancelAnimationFrame(state.openRenderFrame);
    state.openRenderFrame = window.requestAnimationFrame(renderOpenWindow);
  });
  els.searchResults.addEventListener("click", (event) => {
    if (event.target.matches(".delete-row-button")) {
      deleteRow(event.target);
      return;
    }
    if (event.target.matches(".save-button")) {
      saveSearchRow(event.target);
      return;
    }
    if (event.target.matches(".add-row-button")) {
      addSearchRow(event.target);
      return;
    }
    const readOnlyRow = event.target.closest("tr.view-row");
    if (readOnlyRow) {
      state.editingIds.add(String(readOnlyRow.dataset.id));
      renderSearchGrid();
    }
  });
  els.openResults.addEventListener("click", (event) => {
    if (event.target.matches(".delete-row-button")) {
      deleteRow(event.target);
      return;
    }
    if (event.target.matches(".save-button")) {
      saveSearchRow(event.target);
      return;
    }
    const readOnlyRow = event.target.closest("tr.view-row");
    if (readOnlyRow) {
      state.editingIds.add(String(readOnlyRow.dataset.id));
      renderOpenGrid();
    }
  });
  window.addEventListener("resize", () => {
    renderDashboard();
    if (document.querySelector("#executiveTab")?.classList.contains("active")) renderExecutiveSummary();
    if (isSearchTabActive()) renderSearchWindow();
    if (isOpenTabActive()) renderOpenWindow();
  });
}

async function init() {
  bindEvents();
  els.addDate.value = todayIso();
  try {
    await loadData();
  } catch (error) {
    setSyncStatus("error", error.message);
    toast(error.message);
  }
}

init();
