export const SYNC_FIELDS = [
  "date",
  "employeeName",
  "batchNumber",
  "supervisor",
  "hrPerson",
  "followUpOwner",
  "followUpDueDate",
  "information",
  "summary",
  "completed",
];

function comparableValue(value) {
  return String(value ?? "");
}

export function recordKey(record) {
  return String(record?.id ?? "").trim();
}

export function cloneRecord(record) {
  return record ? JSON.parse(JSON.stringify(record)) : record;
}

export function comparableRecord(record) {
  if (!record) return null;
  return {
    id: recordKey(record),
    ...Object.fromEntries(SYNC_FIELDS.map((field) => [field, comparableValue(record[field])])),
  };
}

export function recordsEqual(first, second) {
  const a = (first ?? []).map(comparableRecord).sort((left, right) => left.id.localeCompare(right.id));
  const b = (second ?? []).map(comparableRecord).sort((left, right) => left.id.localeCompare(right.id));
  return JSON.stringify(a) === JSON.stringify(b);
}

function recordFieldChanged(base, changed, field) {
  return comparableValue(base?.[field]) !== comparableValue(changed?.[field]);
}

function changedFields(base, changed) {
  return SYNC_FIELDS.filter((field) => recordFieldChanged(base, changed, field));
}

function mergedRecord(base, local, destination, resolution) {
  const output = cloneRecord(base || local || destination) || {};
  output.id = (local || destination || base).id;

  for (const field of SYNC_FIELDS) {
    const localChanged = recordFieldChanged(base, local, field);
    const destinationChanged = recordFieldChanged(base, destination, field);
    if (localChanged && destinationChanged) {
      output[field] = comparableValue(local[field]) === comparableValue(destination[field])
        ? local[field]
        : (resolution === "destination" ? destination[field] : local[field]);
    } else if (localChanged) {
      output[field] = local[field];
    } else if (destinationChanged) {
      output[field] = destination[field];
    } else if (base) {
      output[field] = base[field];
    }
  }

  return output;
}

function conflictFor(id, kind, base, local, destination, fields) {
  return {
    id,
    kind,
    fields,
    base: cloneRecord(base),
    local: cloneRecord(local),
    destination: cloneRecord(destination),
  };
}

export function mergeRecords(baselineRecords, localRecords, destinationRecords, resolution = "") {
  const baseline = new Map((baselineRecords ?? []).map((record) => [recordKey(record), record]));
  const local = new Map((localRecords ?? []).map((record) => [recordKey(record), record]));
  const destination = new Map((destinationRecords ?? []).map((record) => [recordKey(record), record]));
  const merged = new Map();
  const conflicts = [];
  const ids = new Set([
    ...(localRecords ?? []).map(recordKey),
    ...(destinationRecords ?? []).map(recordKey),
    ...(baselineRecords ?? []).map(recordKey),
  ]);

  for (const id of ids) {
    if (!id) continue;
    const base = baseline.get(id);
    const localRecord = local.get(id);
    const destinationRecord = destination.get(id);

    if (!base) {
      if (localRecord && destinationRecord && !recordsEqual([localRecord], [destinationRecord])) {
        const fields = SYNC_FIELDS.filter((field) => comparableValue(localRecord[field]) !== comparableValue(destinationRecord[field]));
        if (!resolution) {
          conflicts.push(conflictFor(id, "add-add", null, localRecord, destinationRecord, fields));
        } else {
          merged.set(id, cloneRecord(resolution === "destination" ? destinationRecord : localRecord));
        }
      } else if (localRecord || destinationRecord) {
        merged.set(id, cloneRecord(localRecord || destinationRecord));
      }
      continue;
    }

    if (!localRecord && !destinationRecord) continue;

    if (!localRecord || !destinationRecord) {
      const changedSide = localRecord || destinationRecord;
      const sideChanged = !recordsEqual([changedSide], [base]);
      if (!sideChanged) continue;
      if (!resolution) {
        conflicts.push(conflictFor(
          id,
          "delete-edit",
          base,
          localRecord,
          destinationRecord,
          changedFields(base, changedSide),
        ));
      } else if (resolution === "destination" && destinationRecord) {
        merged.set(id, cloneRecord(destinationRecord));
      } else if (resolution === "local" && localRecord) {
        merged.set(id, cloneRecord(localRecord));
      }
      continue;
    }

    if (recordsEqual([localRecord], [destinationRecord])) {
      merged.set(id, cloneRecord(localRecord));
      continue;
    }

    const localChanges = new Set(changedFields(base, localRecord));
    const destinationChanges = new Set(changedFields(base, destinationRecord));
    const overlappingChanges = [...localChanges].filter(
      (field) => destinationChanges.has(field) && comparableValue(localRecord[field]) !== comparableValue(destinationRecord[field]),
    );

    if (overlappingChanges.length && !resolution) {
      conflicts.push(conflictFor(id, "overlapping-edit", base, localRecord, destinationRecord, overlappingChanges));
      continue;
    }

    merged.set(id, mergedRecord(base, localRecord, destinationRecord, resolution));
  }

  const order = [
    ...(localRecords ?? []).map(recordKey),
    ...(destinationRecords ?? []).map(recordKey),
    ...(baselineRecords ?? []).map(recordKey),
  ];
  const records = [];
  const added = new Set();
  for (const id of order) {
    if (!added.has(id) && merged.has(id)) {
      added.add(id);
      records.push(merged.get(id));
    }
  }

  return { records, conflicts };
}

