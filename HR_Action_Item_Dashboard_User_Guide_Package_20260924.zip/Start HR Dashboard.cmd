@echo off
setlocal

cd /d "%~dp0"
set "DASHBOARD_URL=http://127.0.0.1:5177/"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$listener = Get-NetTCPConnection -LocalPort 5177 -State Listen -ErrorAction SilentlyContinue; if (-not $listener) { Start-Process -FilePath '%ComSpec%' -ArgumentList '/c', 'call "%~dp0scripts\start_server.cmd"' -WindowStyle Hidden }"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$deadline = (Get-Date).AddSeconds(15); do { try { Invoke-WebRequest -Uri '%DASHBOARD_URL%' -UseBasicParsing -TimeoutSec 1 | Out-Null; exit 0 } catch { Start-Sleep -Milliseconds 250 } } while ((Get-Date) -lt $deadline); exit 1"
if errorlevel 1 (
  echo The HR Dashboard server did not start within 15 seconds.
  echo Run node server.mjs manually to see the startup error.
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference = 'SilentlyContinue'; Start-Process -FilePath '%DASHBOARD_URL%'"
exit /b 0
