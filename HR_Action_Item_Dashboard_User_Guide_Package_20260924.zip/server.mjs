import http from "node:http";
import fs from "node:fs/promises";
import fsSync from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { recordsEqual } from "./sync-utils.mjs";
import { synchronizeRecords } from "./sync-service.mjs";

const __filename = fileURLToPath(import.meta.url);
const rootDir = path.dirname(__filename);
const dataDir = path.join(rootDir, "data");
const dataPath = path.join(dataDir, "incidents.json");
const auditPath = path.join(dataDir, "audit.json");
const publicDir = path.join(rootDir, "public");
const standaloneDataPath = path.join(publicDir, "standalone-data.js");
const outputWorkbookPath = path.join(
  rootDir,
  "outputs",
  "hr_action_item_dashboard_20260702",
  "HR_Action_Item_Dashboard.xlsx",
);
const builderPath = path.join(rootDir, "scripts", "build_hr_action_dashboard.mjs");
const port = Number(process.env.PORT || 5177);
const startDate = new Date(2025, 0, 9);
let syncSaveQueue = Promise.resolve();

const auditFieldLabels = {
  date: "Date",
  employeeName: "Employee Name",
  batchNumber: "Employee ID",
  supervisor: "Supervisor",
  hrPerson: "HR Person",
  followUpOwner: "Follow-up Owner",
  followUpDueDate: "Follow-up Due",
  information: "Information",
  summary: "Summary",
  completed: "Completed",
};

const categories = [
  "info request",
  "day force related",
  "benefit questions",
  "policy clarifications",
  "performance management",
  "health and safety incidents",
  "employee referrals",
  "employee grievances",
  "supplies/merchandise",
  "UKG related",
  "W-2 request",
  "food pantry",
  "escalation",
  "case management",
];

function categoryKey(value) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function canonicalCategory(value) {
  const key = categoryKey(value);
  return categories.find((category) => categoryKey(category) === key) ?? String(value ?? "").trim();
}

const defaultHrPeople = [
  "Pat Morgan",
  "Shawn Reed",
  "Leslie Carter",
  "Maria Torres",
  "Jordan Blake",
  "Ari Kim",
];

function buildMeta(records) {
  const supervisors = Array.from(new Set(records.map((record) => record.supervisor).filter(Boolean))).sort();
  const hrPeople = Array.from(
    new Set([...defaultHrPeople, ...records.map((record) => record.hrPerson).filter(Boolean)]),
  ).sort();
  const followUpOwners = Array.from(
    new Set([
      ...supervisors,
      ...hrPeople,
      ...records.map((record) => record.followUpOwner).filter(Boolean),
    ]),
  ).sort();
  return { categories, supervisors, hrPeople, followUpOwners, startDate: "2025-01-09" };
}

async function readAudit() {
  try {
    const text = await fs.readFile(auditPath, "utf8");
    const parsed = JSON.parse(text);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function writeAudit(entry) {
  const entries = await readAudit();
  entries.push({
    timestamp: new Date().toISOString(),
    actor: "Local user",
    ...entry,
  });
  await fs.mkdir(dataDir, { recursive: true });
  await fs.writeFile(auditPath, `${JSON.stringify(entries.slice(-500), null, 2)}\n`, "utf8");
}

async function writeStandaloneData(records) {
  const payload = { records, meta: buildMeta(records) };
  await fs.writeFile(
    standaloneDataPath,
    `window.__HR_STANDALONE_DATA__ = ${JSON.stringify(payload)};\n`,
    "utf8",
  );
}

function normalizeReportingDays(value) {
  const days = Number(value);
  if (!Number.isFinite(days)) return 90;
  return Math.min(365, Math.max(30, Math.round(days)));
}

const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
};

function isoDateLocal(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function normalizedDateParts(value) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return [value.getFullYear(), value.getMonth() + 1, value.getDate()];
  }
  if (typeof value === "number" && Number.isFinite(value)) {
    const date = new Date(1899, 11, 30);
    date.setDate(date.getDate() + Math.floor(value));
    return [date.getFullYear(), date.getMonth() + 1, date.getDate()];
  }
  const text = String(value ?? "").trim();
  if (/^\d+(?:\.\d+)?$/.test(text)) {
    const serial = Number(text);
    if (Number.isFinite(serial) && serial >= 1 && serial <= 100000) {
      const date = new Date(1899, 11, 30);
      date.setDate(date.getDate() + Math.floor(serial));
      return [date.getFullYear(), date.getMonth() + 1, date.getDate()];
    }
  }
  const compactMatch = text.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (compactMatch) return compactMatch.slice(1).map(Number);
  const isoMatch = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (isoMatch) return isoMatch.slice(1).map(Number);
  const yearFirstMatch = text.match(/^(\d{4})[\/\.\-](\d{1,2})[\/\.\-](\d{1,2})(?:\s|$)/);
  if (yearFirstMatch) return yearFirstMatch.slice(1).map(Number);
  const numericMatch = text.match(/^(\d{1,4})[\/\.\-](\d{1,2})[\/\.\-](\d{2}|\d{4})(?:\s|$)/);
  if (numericMatch) {
    const first = Number(numericMatch[1]);
    const second = Number(numericMatch[2]);
    const year = Number(numericMatch[3]) < 100 ? 2000 + Number(numericMatch[3]) : Number(numericMatch[3]);
    return [year, first > 12 ? second : first, first > 12 ? first : second];
  }
  const parsed = new Date(text);
  return Number.isNaN(parsed.getTime())
    ? null
    : [parsed.getFullYear(), parsed.getMonth() + 1, parsed.getDate()];
}

function parseDate(value) {
  const parts = normalizedDateParts(value);
  if (!parts) return null;
  const [year, month, day] = parts;
  if (!year || !month || !day) return null;
  const parsed = new Date(year, month - 1, day);
  if (Number.isNaN(parsed.getTime())) return null;
  return parsed.getFullYear() === year && parsed.getMonth() + 1 === month && parsed.getDate() === day
    ? parsed
    : null;
}

function weekFromDate(value) {
  const parsed = parseDate(value);
  if (!parsed) return "";
  return Math.max(1, Math.floor((parsed - startDate) / (7 * 24 * 60 * 60 * 1000)) + 1);
}

function cleanCompleted(value) {
  return String(value ?? "").trim().toUpperCase() === "X" ? "X" : "";
}

function normalizeIncident(raw, index = 0) {
  const fallbackDate = isoDateLocal(new Date());
  const date = parseDate(raw.date) ? excelDateToIso(raw.date) : fallbackDate;
  const followUpDueDate = String(raw.followUpDueDate ?? "").trim();
  return {
    id: Number.isFinite(Number(raw.id)) ? Number(raw.id) : index + 1,
    date,
    employeeName: String(raw.employeeName ?? "").trim(),
    batchNumber: String(raw.batchNumber ?? "").trim(),
    supervisor: String(raw.supervisor ?? "").trim(),
    hrPerson: String(raw.hrPerson ?? "").trim(),
    followUpOwner: String(raw.followUpOwner ?? "").trim(),
    followUpDueDate: followUpDueDate && parseDate(followUpDueDate) ? excelDateToIso(followUpDueDate) : "",
    information: String(raw.information ?? "").trim(),
    summary: canonicalCategory(raw.summary),
    completed: cleanCompleted(raw.completed),
  };
}

function withComputedFields(records) {
  return records.map((record, index) => ({
    rowNumber: index + 2,
    week: weekFromDate(record.date),
    ...record,
  }));
}

function withComputedField(record, index) {
  return {
    rowNumber: index + 2,
    week: weekFromDate(record.date),
    ...record,
  };
}

async function readIncidents() {
  try {
    const text = await fs.readFile(dataPath, "utf8");
    const parsed = JSON.parse(text);
    if (Array.isArray(parsed)) {
      return parsed.map(normalizeIncident);
    }
  } catch {
    // Builder seeds this file. Return empty if the site starts first.
  }
  return [];
}

async function writeIncidents(records) {
  await fs.mkdir(dataDir, { recursive: true });
  const normalized = records.map(normalizeIncident);
  await fs.writeFile(dataPath, `${JSON.stringify(normalized, null, 2)}\n`, "utf8");
  try {
    await writeStandaloneData(normalized);
  } catch {
    // The server data remains authoritative if the standalone snapshot cannot be refreshed.
  }
  return normalized;
}

async function readBody(request) {
  const chunks = [];
  for await (const chunk of request) {
    chunks.push(chunk);
  }
  if (chunks.length === 0) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function sendJson(response, status, payload) {
  const body = JSON.stringify(payload);
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store",
  });
  response.end(body);
}

function sendError(response, status, message) {
  sendJson(response, status, { error: message });
}

function validateIncident(payload, existing = {}) {
  const requestedFollowUpDueDate = String(payload.followUpDueDate ?? existing.followUpDueDate ?? "").trim();
  if (requestedFollowUpDueDate && !parseDate(requestedFollowUpDueDate)) {
    throw new Error("Follow-up due date must be a valid date.");
  }
  const merged = normalizeIncident({ ...existing, ...payload });
  if (!merged.employeeName) {
    throw new Error("Employee name is required.");
  }
  if (!parseDate(merged.date)) {
    throw new Error("A valid date is required.");
  }
  if (!categories.includes(merged.summary)) {
    throw new Error("Summary must be one of the configured categories.");
  }
  return merged;
}

function changedFields(before, after) {
  return Object.keys(auditFieldLabels)
    .filter((field) => String(before[field] ?? "") !== String(after[field] ?? ""))
    .map((field) => auditFieldLabels[field]);
}

function incidentFingerprint(record) {
  return [
    record.date,
    record.employeeName,
    record.batchNumber,
    record.supervisor,
    record.summary,
    record.information,
  ]
    .map((value) => String(value ?? "").trim().toLowerCase())
    .join("|");
}

function normalizeHeader(value) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (quoted) {
      if (character === '"' && text[index + 1] === '"') {
        field += '"';
        index += 1;
      } else if (character === '"') {
        quoted = false;
      } else {
        field += character;
      }
    } else if (character === '"') {
      quoted = true;
    } else if (character === ",") {
      row.push(field);
      field = "";
    } else if (character === "\n") {
      row.push(field.replace(/\r$/, ""));
      if (row.some((value) => value.trim())) rows.push(row);
      row = [];
      field = "";
    } else {
      field += character;
    }
  }
  row.push(field.replace(/\r$/, ""));
  if (row.some((value) => value.trim())) rows.push(row);
  return rows;
}

function excelDateToIso(value) {
  const date = parseDate(value);
  return date ? isoDateLocal(date) : "";
}

function objectValue(raw, keys) {
  const entries = Object.entries(raw).map(([key, value]) => [normalizeHeader(key), value]);
  for (const key of keys) {
    const match = entries.find(([normalized]) => normalized === normalizeHeader(key));
    if (match) return match[1];
  }
  return "";
}

function importedRecordFromObject(raw) {
  return {
    date: excelDateToIso(objectValue(raw, ["date"])),
    employeeName: objectValue(raw, ["employee name", "employee", "employeeName"]),
    batchNumber: objectValue(raw, ["employee id", "batch number", "employeeId", "batchNumber"]),
    supervisor: objectValue(raw, ["supervisor"]),
    hrPerson: objectValue(raw, ["hr person", "hrPerson"]),
    followUpOwner: objectValue(raw, ["follow up owner", "followUpOwner"]),
    followUpDueDate: excelDateToIso(objectValue(raw, ["follow up due", "follow up due date", "followUpDueDate"])),
    information: objectValue(raw, ["information"]),
    summary: objectValue(raw, ["summary", "category"]),
    completed: objectValue(raw, ["completed", "done"]),
  };
}

function rowsToImportedRecords(rows) {
  if (!rows.length) return [];
  if (!Array.isArray(rows[0])) return rows.map(importedRecordFromObject);
  const headers = rows[0].map(normalizeHeader);
  const column = (aliases) => headers.findIndex((header) => aliases.includes(header));
  const columns = {
    date: column(["date"]),
    employeeName: column(["employee name", "employee"]),
    batchNumber: column(["employee id", "batch number"]),
    supervisor: column(["supervisor"]),
    hrPerson: column(["hr person"]),
    followUpOwner: column(["follow up owner"]),
    followUpDueDate: column(["follow up due", "follow up due date"]),
    information: column(["information"]),
    summary: column(["summary", "category"]),
    completed: column(["completed", "done"]),
  };
  const valueAt = (row, key) => (columns[key] >= 0 ? row[columns[key]] : "");
  return rows.slice(1).map((row) => ({
    date: excelDateToIso(valueAt(row, "date")),
    employeeName: valueAt(row, "employeeName"),
    batchNumber: valueAt(row, "batchNumber"),
    supervisor: valueAt(row, "supervisor"),
    hrPerson: valueAt(row, "hrPerson"),
    followUpOwner: valueAt(row, "followUpOwner"),
    followUpDueDate: excelDateToIso(valueAt(row, "followUpDueDate")),
    information: valueAt(row, "information"),
    summary: valueAt(row, "summary"),
    completed: valueAt(row, "completed"),
  }));
}

async function readImportRecords(filename, contentBase64) {
  const extension = path.extname(filename).toLowerCase();
  const bytes = Buffer.from(String(contentBase64 ?? ""), "base64");
  if (extension === ".xlsx" || extension === ".xls") {
    const tempDir = await fs.mkdtemp(path.join(rootDir, ".hr-import-"));
    const tempPath = path.join(tempDir, path.basename(filename));
    try {
      await fs.writeFile(tempPath, bytes);
      const { FileBlob, SpreadsheetFile } = await import("@oai/artifact-tool");
      const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(tempPath));
      let sheet;
      try {
        sheet = workbook.worksheets.getItem("Incident Tracker 4.0");
      } catch {
        sheet = workbook.worksheets.getItemAt(0);
      }
      return rowsToImportedRecords(sheet.getUsedRange(true).values);
    } finally {
      await fs.rm(tempDir, { recursive: true, force: true });
    }
  }
  const text = bytes.toString("utf8");
  if (extension === ".json") {
    const parsed = JSON.parse(text);
    const records = Array.isArray(parsed) ? parsed : parsed.records;
    return Array.isArray(records) ? rowsToImportedRecords(records) : [];
  }
  return rowsToImportedRecords(parseCsv(text));
}

async function importIncidents(payload) {
  const imported = await readImportRecords(String(payload.filename ?? "import.csv"), payload.contentBase64);
  const records = await readIncidents();
  if (Array.isArray(payload.baselineRecords)) {
    const baselineRecords = normalizeSyncRecords(payload.baselineRecords, "Import baseline");
    if (!recordsEqual(baselineRecords, records)) {
      const error = new Error("The shared destination changed while the import was being prepared.");
      error.status = 409;
      error.payload = {
        error: "Import paused because the shared destination changed. Refresh, export a backup if needed, and import again.",
        destinationRecords: withComputedFields(records),
      };
      throw error;
    }
  }
  const keys = new Set(records.map(incidentFingerprint));
  let nextId = records.reduce((max, record) => Math.max(max, Number(record.id) || 0), 0) + 1;
  let duplicates = 0;
  const added = [];
  const invalid = [];

  imported.forEach((row, index) => {
    const candidate = {
      ...row,
      date: excelDateToIso(row.date),
      followUpDueDate: excelDateToIso(row.followUpDueDate),
      id: nextId,
    };
    candidate.summary = canonicalCategory(candidate.summary);
    const isBlank = !candidate.date && !String(candidate.employeeName ?? "").trim() && !String(candidate.summary ?? "").trim();
    if (isBlank) return;
    if (!parseDate(candidate.date)) {
      invalid.push({ row: index + 2, reason: "A valid date is required." });
      return;
    }
    if (!String(candidate.employeeName ?? "").trim()) {
      invalid.push({ row: index + 2, reason: "Employee name is required." });
      return;
    }
    if (!categories.includes(String(candidate.summary ?? "").trim())) {
      invalid.push({ row: index + 2, reason: "Summary must match a configured category." });
      return;
    }
    try {
      const normalized = validateIncident(candidate);
      const fingerprint = incidentFingerprint(normalized);
      if (keys.has(fingerprint)) {
        duplicates += 1;
        return;
      }
      keys.add(fingerprint);
      records.push(normalized);
      added.push(normalized);
      nextId += 1;
    } catch (error) {
      invalid.push({ row: index + 2, reason: error.message });
    }
  });

  if (added.length) await writeIncidents(records);
  await writeAudit({
    action: "imported",
    employeeName: `${added.length} records from ${path.basename(String(payload.filename ?? "import"))}`,
    details: `${duplicates} duplicate${duplicates === 1 ? "" : "s"} skipped; ${invalid.length} invalid row${invalid.length === 1 ? "" : "s"} skipped.`,
  });
  return { added: added.length, duplicates, invalid, total: records.length };
}

function normalizeSyncRecords(rawRecords, label) {
  if (!Array.isArray(rawRecords)) throw new Error(`${label} must be an array.`);
  const ids = new Set();
  return rawRecords.map((raw, index) => {
    const idText = String(raw?.id ?? "").trim();
    if (!idText || !Number.isFinite(Number(idText))) {
      throw new Error(`${label} contains a record without a stable numeric ID at position ${index + 1}.`);
    }
    const id = Number(idText);
    if (ids.has(id)) throw new Error(`${label} contains duplicate record ID ${id}.`);
    ids.add(id);
    return validateIncident({ ...raw, id });
  });
}

async function syncIncidents(payload) {
  const localRecords = normalizeSyncRecords(payload.localRecords, "Local records");
  const baselineRecords = payload.baselineRecords == null
    ? null
    : normalizeSyncRecords(payload.baselineRecords, "Sync baseline");
  const destinationRecords = await readIncidents();
  const resolution = String(payload.resolution ?? "").trim().toLowerCase();

  if (resolution && !["local", "destination"].includes(resolution)) {
    throw new Error("Sync resolution must be local or destination.");
  }
  return synchronizeRecords({
    baselineRecords,
    localRecords,
    destinationRecords,
    resolution,
    writeRecords: async (records) => {
      const normalizedMerged = normalizeSyncRecords(records, "Merged records");
      await writeIncidents(normalizedMerged);
      await writeAudit({
        action: "synced",
        employeeName: "",
        details: `${normalizedMerged.length} records synchronized${resolution ? ` with ${resolution} conflict resolution` : ""}.`,
      }).catch(() => {});
    },
  });
}

async function handleApi(request, response, url) {
  if (url.pathname === "/api/meta" && request.method === "GET") {
    const records = await readIncidents();
    sendJson(response, 200, buildMeta(records));
    return;
  }

  if (url.pathname === "/api/audit" && request.method === "GET") {
    const entries = await readAudit();
    sendJson(response, 200, { entries: entries.slice(-200).reverse() });
    return;
  }

  if (url.pathname === "/api/sync" && request.method === "POST") {
    try {
      const payload = await readBody(request);
      const operation = syncSaveQueue.catch(() => {}).then(() => syncIncidents(payload));
      syncSaveQueue = operation.then(() => undefined, () => undefined);
      const result = await operation;
      if (!result.ok) {
        sendJson(response, 409, {
          error: "Sync conflict. No shared data was overwritten.",
          conflicts: result.conflicts,
          destinationRecords: withComputedFields(result.destinationRecords ?? []),
        });
        return;
      }
      sendJson(response, 200, {
        records: withComputedFields(result.records),
        total: result.records.length,
        written: result.written,
        remoteChanged: result.remoteChanged,
      });
    } catch (error) {
      sendError(response, 400, error.message);
    }
    return;
  }

  if (url.pathname === "/api/incidents" && request.method === "GET") {
    const records = withComputedFields(await readIncidents());
    const employeeName = (url.searchParams.get("employeeName") ?? "").trim().toLowerCase();
    const filtered = employeeName
      ? records.filter((record) => record.employeeName.toLowerCase().includes(employeeName))
      : records;
    sendJson(response, 200, { records: filtered, total: records.length });
    return;
  }

  if (url.pathname === "/api/incidents" && request.method === "POST") {
    try {
      const payload = await readBody(request);
      const records = await readIncidents();
      const nextId = records.reduce((max, record) => Math.max(max, Number(record.id) || 0), 0) + 1;
      const incident = validateIncident({ ...payload, id: nextId });
      records.push(incident);
      await writeIncidents(records);
      await writeAudit({
        action: "created",
        recordId: incident.id,
        employeeName: incident.employeeName,
        details: "New walk-in added.",
      }).catch(() => {});
      sendJson(response, 201, { record: withComputedField(incident, records.length - 1), total: records.length });
    } catch (error) {
      sendError(response, 400, error.message);
    }
    return;
  }

  const updateMatch = url.pathname.match(/^\/api\/incidents\/(\d+)$/);
  if (updateMatch && request.method === "PUT") {
    try {
      const id = Number(updateMatch[1]);
      const payload = await readBody(request);
      const records = await readIncidents();
      const index = records.findIndex((record) => Number(record.id) === id);
      if (index === -1) {
        sendError(response, 404, "Incident not found.");
        return;
      }
      const updated = validateIncident({ ...payload, id }, records[index]);
      const changes = changedFields(records[index], updated);
      records[index] = updated;
      await writeIncidents(records);
      await writeAudit({
        action: "updated",
        recordId: updated.id,
        employeeName: updated.employeeName,
        details: changes.length ? `Changed: ${changes.join(", ")}.` : "Saved without field changes.",
      }).catch(() => {});
      sendJson(response, 200, { record: withComputedField(updated, index), total: records.length });
    } catch (error) {
      sendError(response, 400, error.message);
    }
    return;
  }

  const deleteMatch = url.pathname.match(/^\/api\/incidents\/(\d+)$/);
  if (deleteMatch && request.method === "DELETE") {
    try {
      const id = Number(deleteMatch[1]);
      const records = await readIncidents();
      const index = records.findIndex((record) => Number(record.id) === id);
      if (index === -1) {
        sendError(response, 404, "Incident not found.");
        return;
      }
      const [deleted] = records.splice(index, 1);
      await writeIncidents(records);
      await writeAudit({
        action: "deleted",
        recordId: deleted.id,
        employeeName: deleted.employeeName,
        details: "Walk-in deleted after confirmation.",
      }).catch(() => {});
      sendJson(response, 200, { record: withComputedField(deleted, index), total: records.length });
    } catch (error) {
      sendError(response, 400, error.message);
    }
    return;
  }

  if (url.pathname === "/api/import" && request.method === "POST") {
    try {
      const payload = await readBody(request);
      const result = await importIncidents(payload);
      sendJson(response, 200, result);
    } catch (error) {
      if (error.status === 409 && error.payload) sendJson(response, 409, error.payload);
      else sendError(response, 400, error.message);
    }
    return;
  }

  if (url.pathname === "/api/export" && request.method === "POST") {
    try {
      const payload = await readBody(request);
      await runBuilder(normalizeReportingDays(payload.reportingDays));
      const stat = await fs.stat(outputWorkbookPath);
      sendJson(response, 200, {
        path: outputWorkbookPath,
        downloadUrl: "/download/workbook",
        filename: "HR_Action_Item_Dashboard.xlsx",
        size: stat.size,
      });
    } catch (error) {
      sendError(response, 500, error.message);
    }
    return;
  }

  sendError(response, 404, "API route not found.");
}

function runBuilder(reportingDays = 90) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [builderPath, `--reporting-days=${normalizeReportingDays(reportingDays)}`], {
      cwd: rootDir,
      stdio: ["ignore", "pipe", "pipe"],
      windowsHide: true,
    });
    let stderr = "";
    child.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(stderr || `Workbook export failed with code ${code}.`));
      }
    });
  });
}

async function serveStatic(request, response, url) {
  if (url.pathname === "/download/workbook") {
    try {
      const stat = await fs.stat(outputWorkbookPath);
      response.writeHead(200, {
        "Content-Type": contentTypes[".xlsx"],
        "Content-Length": stat.size,
        "Content-Disposition": 'attachment; filename="HR_Action_Item_Dashboard.xlsx"',
        "Cache-Control": "no-store",
      });
      fsSync.createReadStream(outputWorkbookPath).pipe(response);
    } catch {
      sendError(response, 404, "Workbook has not been exported yet.");
    }
    return;
  }

  const requested = url.pathname === "/" ? "/index.html" : decodeURIComponent(url.pathname);
  const resolved = path.resolve(publicDir, `.${requested}`);
  const relativePath = path.relative(publicDir, resolved);
  if (relativePath.startsWith("..") || path.isAbsolute(relativePath)) {
    sendError(response, 403, "Forbidden.");
    return;
  }

  try {
    const stat = await fs.stat(resolved);
    if (!stat.isFile()) {
      sendError(response, 404, "Not found.");
      return;
    }
    const ext = path.extname(resolved);
    response.writeHead(200, {
      "Content-Type": contentTypes[ext] ?? "application/octet-stream",
      "Cache-Control": "no-store",
    });
    fsSync.createReadStream(resolved).pipe(response);
  } catch {
    sendError(response, 404, "Not found.");
  }
}

readIncidents().then(writeStandaloneData).catch(() => {});

const server = http.createServer(async (request, response) => {
  const url = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);
  try {
    if (url.pathname.startsWith("/api/")) {
      await handleApi(request, response, url);
    } else {
      await serveStatic(request, response, url);
    }
  } catch (error) {
    sendError(response, 500, error.message);
  }
});

server.listen(port, "127.0.0.1", () => {
  console.log(`HR action item dashboard running at http://127.0.0.1:${port}`);
});
