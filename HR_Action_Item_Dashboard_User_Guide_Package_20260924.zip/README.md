# HR Action Item Dashboard

The HR Action Item Dashboard is a local HR walk-in tracker. It includes operational dashboards, executive summaries, record entry and editing, filters, saved views, follow-up reminders, activity history, CSV/JSON import, and Excel-compatible export.

The project starts with no tracker records. Add or import your organization's data through the dashboard.

## Choose a launch mode

There are two ways to open the dashboard.

### Recommended: local server mode

Use server mode when you need the shared data file, conflict-aware sync, true Excel import/export, or multiple browser sessions on the same computer.

For one-click startup on Windows, double-click `Start HR Dashboard.cmd`. It starts the local server if it is not already running, waits for the dashboard to respond, and opens the synced dashboard in your browser.

1. Open PowerShell in this project folder.
2. Start the server:

   ```powershell
   node server.mjs
   ```

3. Open [http://127.0.0.1:5177/](http://127.0.0.1:5177/) in your browser.

Keep the PowerShell window open while using the dashboard. Stop the server with `Ctrl+C`.

### Direct index mode

Double-click `index.html`, or click the `Open synced dashboard` link inside it. The launcher checks for the local server and opens conflict-aware server mode automatically when it is running.

If the server is not running, the launcher offers `Open local-only dashboard`. Direct index mode is useful when Node.js is unavailable, but it runs entirely in the browser and saves changes in that browser's local storage. It does not connect to the shared `data/incidents.json` file, so it does not provide shared server sync.

## Server-mode data and sync

Server mode keeps the existing storage destination and schema:

- `data/incidents.json` stores tracker records.
- `data/audit.json` stores activity history.
- Browser local storage keeps a local mirror and the last successful sync baseline.

Before a server-mode save, the app rereads the latest destination data and compares three versions:

- Baseline: the last successful shared snapshot.
- Local: the changes in the current browser.
- Destination: the latest shared file.

Independent field changes are merged automatically. The save pauses when both sides changed the same field, or when one side deleted a record while the other side edited it. The app never silently overwrites either version in those cases.

When a conflict appears:

1. Click `Export Backup` if you need to preserve the local version.
2. Choose `Keep Local` to explicitly save the browser version.
3. Choose `Use Shared` to replace the browser version with the shared destination.

Saves are serialized inside the browser and inside the local server process. If the shared destination is unavailable, the browser continues saving locally and shows a `Local-only` status.

### Important concurrency limitation

This is file-based synchronization. It is not transactional across separate server processes, simultaneous writers, or delayed OneDrive/cloud synchronization. It provides practical conflict protection but cannot guarantee consistency when two people write at exactly the same time. Guaranteed multi-user consistency would require an approved transactional shared backend with compare-and-swap or equivalent concurrency control.

## Main workflows

- `Dashboard` shows totals, completion, open items, trends, reminders, and data quality.
- `Executive Summary` provides a management-level view of activity.
- `Add Walk-In` adds a new tracker record.
- `Search & Edit` supports filtered editing and record deletion.
- `Open Walk-ins` focuses on unresolved items.
- `Activity History` shows create, update, delete, import, and sync activity.
- `Export Backup` downloads the browser's local records, baseline, and conflict details as JSON.
- `Export Excel` creates an Excel workbook snapshot in server mode.

## Importing data

Excel imports should use a sheet named `Incident Tracker 4.0`. Required columns are:

- `Date`
- `Employee` or `Employee Name`
- `Summary` or `Category`

Supported optional columns include `Employee ID`, `Batch Number`, `Supervisor`, `Information`, `HR Person`, `Follow-up Owner`, `Follow-up Due`, and `Completed`.

The importer accepts common date formats, Excel serial dates, CSV, and JSON. `Completed` uses `X` for closed and blank for open. Missing or renamed optional columns do not delete existing records. Invalid rows are reported and skipped. If the shared destination changes while an import is being prepared, the import pauses so the data can be refreshed safely.

Direct index mode supports CSV and JSON imports. Server mode supports formatted `.xlsx` and `.xls` imports when the local Excel tooling dependency is available.

## Project layout

```text
index.html                    Direct-open entry point
Start HR Dashboard.cmd        One-click Windows server launcher
public/index.html             Dashboard markup
public/app.js                 Browser behavior and local sync state
public/styles.css             Dashboard styling
public/standalone-data.js     Direct-mode data snapshot
server.mjs                    Local HTTP server and API
sync-utils.mjs                Three-way merge and conflict detection
sync-service.mjs              Conflict-aware save service
data/incidents.json           Server-mode tracker records
data/audit.json               Server-mode activity history
tests/sync.test.mjs           Focused sync tests
scripts/                      Workbook and standalone-data builders
outputs/                      Generated workbooks and previews
```

## Refreshing direct index data

If `data/incidents.json` changes while using server mode, rebuild the direct-mode snapshot:

```powershell
node scripts/build_standalone_data.mjs
```

Then close and reopen `index.html`.

## Running tests

Run the focused sync tests with:

```powershell
node --test tests/sync.test.mjs
```

The test suite covers independent edits, overlapping edits, additions, deletions, delete-versus-edit conflicts, failed saves, and restored-baseline behavior.

## Internet and privacy

The dashboard itself does not connect to the internet or call external services. Server mode binds to `127.0.0.1:5177` and uses local project files. Direct index mode uses browser local storage.

If the project is stored inside OneDrive, the OneDrive application may independently synchronize project files to the cloud. That synchronization is outside the dashboard and is subject to the concurrency limitation described above.

## Troubleshooting

### The page does not load

Confirm that the server is running and open `http://127.0.0.1:5177/`. If port `5177` is already in use, stop the other local process or start the server with another port:

```powershell
$env:PORT = 5178
node server.mjs
```

Then open `http://127.0.0.1:5178/`.

### The dashboard shows Local-only

The browser could not reach the local server. Your changes remain in browser local storage. Start the server again and click the refresh button to reconnect and attempt a conflict-aware sync.

### A conflict appears

Export a backup first, then choose `Keep Local` or `Use Shared`. No shared data is overwritten until one of those explicit choices is made.
