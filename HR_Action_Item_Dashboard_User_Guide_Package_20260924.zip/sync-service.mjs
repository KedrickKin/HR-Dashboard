import { cloneRecord, mergeRecords, recordsEqual } from "./sync-utils.mjs";

export async function synchronizeRecords({
  baselineRecords,
  localRecords,
  destinationRecords,
  resolution = "",
  writeRecords = async () => {},
}) {
  if (!baselineRecords) {
    if (recordsEqual(localRecords, destinationRecords)) {
      return { ok: true, records: cloneRecord(destinationRecords), written: false, remoteChanged: false };
    }
    return {
      ok: false,
      conflicts: [{
        id: "__baseline__",
        kind: "missing-baseline",
        fields: [],
        base: null,
        local: cloneRecord(localRecords),
        destination: cloneRecord(destinationRecords),
      }],
      destinationRecords: cloneRecord(destinationRecords),
    };
  }

  const merged = mergeRecords(baselineRecords, localRecords, destinationRecords, resolution);
  if (merged.conflicts.length && !resolution) {
    return {
      ok: false,
      conflicts: merged.conflicts,
      destinationRecords: cloneRecord(destinationRecords),
    };
  }

  const remoteChanged = !recordsEqual(baselineRecords, destinationRecords);
  const written = !recordsEqual(merged.records, destinationRecords);
  if (written) await writeRecords(cloneRecord(merged.records));
  return {
    ok: true,
    records: cloneRecord(merged.records),
    written,
    remoteChanged,
  };
}

