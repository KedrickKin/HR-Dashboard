import assert from "node:assert/strict";
import test from "node:test";
import { mergeRecords } from "../sync-utils.mjs";
import { synchronizeRecords } from "../sync-service.mjs";

function record(id, overrides = {}) {
  return {
    id,
    date: "2026-09-24",
    employeeName: "Alex Morgan",
    batchNumber: "E-100",
    supervisor: "Jordan Blake",
    hrPerson: "Pat Morgan",
    followUpOwner: "Pat Morgan",
    followUpDueDate: "",
    information: "Asked about policy.",
    summary: "info request",
    completed: "",
    ...overrides,
  };
}

test("merges independent field edits", () => {
  const baseline = [record(1)];
  const local = [record(1, { employeeName: "Alexandra Morgan" })];
  const destination = [record(1, { information: "Asked about final pay." })];
  const result = mergeRecords(baseline, local, destination);

  assert.equal(result.conflicts.length, 0);
  assert.equal(result.records[0].employeeName, "Alexandra Morgan");
  assert.equal(result.records[0].information, "Asked about final pay.");
});

test("pauses overlapping edits with field-level conflict details", async () => {
  const baseline = [record(1)];
  const local = [record(1, { summary: "benefit questions" })];
  const destination = [record(1, { summary: "policy clarifications" })];
  let writes = 0;
  const result = await synchronizeRecords({
    baselineRecords: baseline,
    localRecords: local,
    destinationRecords: destination,
    writeRecords: async () => { writes += 1; },
  });

  assert.equal(result.ok, false);
  assert.equal(writes, 0);
  assert.deepEqual(result.conflicts[0].fields, ["summary"]);
  assert.equal(result.conflicts[0].kind, "overlapping-edit");
});

test("keeps independent additions and treats delete-versus-edit as a conflict", () => {
  const baseline = [record(1)];
  const local = [record(-1, { employeeName: "Local Addition" })];
  const destination = [record(1, { information: "Destination edit." }), record(2, { employeeName: "Shared Addition" })];
  const result = mergeRecords(baseline, local, destination);

  assert.equal(result.conflicts.length, 1);
  assert.equal(result.conflicts[0].kind, "delete-edit");
  assert.equal(result.records.some((item) => item.id === -1), true);
  assert.equal(result.records.some((item) => item.id === 2), true);

  const keepLocal = mergeRecords(baseline, [], destination, "local");
  const keepDestination = mergeRecords(baseline, [], destination, "destination");
  assert.equal(keepLocal.records.some((item) => item.id === 1), false);
  assert.equal(keepDestination.records.some((item) => item.id === 1), true);
});

test("surfaces failed saves without changing the destination snapshot", async () => {
  await assert.rejects(
    synchronizeRecords({
      baselineRecords: [record(1)],
      localRecords: [record(1, { completed: "X" })],
      destinationRecords: [record(1)],
      writeRecords: async () => { throw new Error("destination unavailable"); },
    }),
    /destination unavailable/,
  );
});

test("restored baselines merge remote changes once and become stable after reload", async () => {
  const baseline = [record(1)];
  const local = [record(1, { followUpOwner: "Leslie Carter" })];
  const destination = [record(1, { information: "Remote note." })];
  let writes = 0;
  const first = await synchronizeRecords({
    baselineRecords: baseline,
    localRecords: local,
    destinationRecords: destination,
    writeRecords: async () => { writes += 1; },
  });
  assert.equal(first.ok, true);
  assert.equal(first.written, true);
  assert.equal(first.records[0].followUpOwner, "Leslie Carter");
  assert.equal(first.records[0].information, "Remote note.");

  const second = await synchronizeRecords({
    baselineRecords: first.records,
    localRecords: first.records,
    destinationRecords: first.records,
    writeRecords: async () => { writes += 1; },
  });
  assert.equal(second.ok, true);
  assert.equal(second.written, false);
  assert.equal(writes, 1);
});

